package ComparedTimeSeriesMethod_Weka;

import ProposedTimeSeriesMethod_GP.Setting.DiverseSetting;
import weka.classifiers.functions.SMOreg;
import weka.classifiers.trees.REPTree;

public class Weka_SVR extends Weka_ProcessBasis
{

	public Weka_SVR(DiverseSetting diverseSetting) 
	{
		super(diverseSetting);
		
	}

	@Override
	protected void setWekaForecaster() 
	{
	   this.forecaster.setBaseForecaster(new SMOreg());
	}

}
