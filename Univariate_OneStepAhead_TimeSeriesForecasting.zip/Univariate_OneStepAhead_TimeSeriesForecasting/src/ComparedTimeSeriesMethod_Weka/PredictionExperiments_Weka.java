package ComparedTimeSeriesMethod_Weka;

import java.util.List;


import Utilities.CommonSetting.TimeSeriesIntervalsIndicesSet;
import Utilities.DataStructures.ForecastingOutcomeOfASegment;
import Utilities.DatasetProcessingModules.ObservationsAtOneTimePoint;
import Utilities.ForecastingAccuracyMeasures.DiverseErrorsOfASegment;
import Utilities.ForecastingAccuracyMeasures.DiverseMeasuringResultsOfASegment;
import Utilities.ForecastingCostMeasures.TimeCost;
import Utilities.PredictionExperimentsForComparedMethods.PredictionExperiments;

public class PredictionExperiments_Weka extends PredictionExperiments 
{
	
	
	public PredictionExperiments_Weka(List<List<ObservationsAtOneTimePoint>> timeSeries, int numberOfTimeseries,
			                         TimeSeriesIntervalsIndicesSet timeSeriesIntervalsIndicesSet,
			                     
			                         List<ForecastingOutcomeOfASegment[][]> outcomeOfDiverseMethods_ForecastingOutcomes,
			                         List<DiverseErrorsOfASegment[][]> outcomeOfDiverseMethods_DiverseErrors, 
                                     List<DiverseMeasuringResultsOfASegment[][]> outcomeOfDiverseMethods_AccuracyMeasures, 
                                     List<TimeCost[][]> outcomeOfDiverseMethods_TimeCosts
			                        )
    {
		super(timeSeries, numberOfTimeseries, timeSeriesIntervalsIndicesSet, 
				
			  outcomeOfDiverseMethods_ForecastingOutcomes, outcomeOfDiverseMethods_DiverseErrors,
			  outcomeOfDiverseMethods_AccuracyMeasures,  outcomeOfDiverseMethods_TimeCosts				
			 );
		
	
	}
	 
	
	@Override
	protected ForecastingOutcomeOfASegment invokeMethod(Object method, List<ObservationsAtOneTimePoint> timeSeries,
			                                            int[][] trainingDataIntervalsSet, int[][] testingDataIntervalsSet, ForecastingOutcomeOfASegment result) throws Exception 
	{
		Weka_ProcessBasis WekaMethod = (Weka_ProcessBasis) method;
		
	    result = WekaMethod.preidct_Mode1(timeSeries, trainingDataIntervalsSet, testingDataIntervalsSet, result);	
		
		return result;
	}
}
