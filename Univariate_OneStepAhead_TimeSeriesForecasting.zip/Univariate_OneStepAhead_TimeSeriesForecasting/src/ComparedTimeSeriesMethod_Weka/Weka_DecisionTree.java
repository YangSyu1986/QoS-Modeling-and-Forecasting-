package ComparedTimeSeriesMethod_Weka;

import ProposedTimeSeriesMethod_GP.Setting.DiverseSetting;
import weka.classifiers.trees.REPTree;

public class Weka_DecisionTree extends Weka_ProcessBasis
{

	public Weka_DecisionTree(DiverseSetting diverseSetting) 
	{
		super(diverseSetting);
		
	}

	@Override
	protected void setWekaForecaster() 
	{
	   this.forecaster.setBaseForecaster(new REPTree());
	}

}