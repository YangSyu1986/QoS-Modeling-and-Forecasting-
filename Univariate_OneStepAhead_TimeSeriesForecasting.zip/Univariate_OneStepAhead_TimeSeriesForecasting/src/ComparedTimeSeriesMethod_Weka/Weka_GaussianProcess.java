package ComparedTimeSeriesMethod_Weka;

import ProposedTimeSeriesMethod_GP.Setting.DiverseSetting;
import weka.classifiers.functions.GaussianProcesses;
import weka.classifiers.functions.LinearRegression;


public class Weka_GaussianProcess extends Weka_ProcessBasis
{

	public Weka_GaussianProcess(DiverseSetting diverseSetting) 
	{
		super(diverseSetting);
		
	}

	@Override
	protected void setWekaForecaster() 
	{
	   this.forecaster.setBaseForecaster(new GaussianProcesses());
	}

}