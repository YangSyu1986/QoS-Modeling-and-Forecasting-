package ComparedTimeSeriesMethod_Weka;

import java.io.BufferedReader;
import java.io.FileReader;
import java.lang.management.ManagementFactory;
import java.util.ArrayList;
import java.util.List;

import ProposedTimeSeriesMethod_GP.Setting.DiverseSetting;
import Utilities.DataStructures.ForecastingOutcomeOfASegment;
import Utilities.DatasetProcessingModules.ObservationsAtOneTimePoint;
import libsvm.svm_model;
import libsvm.svm_parameter;
import libsvm.svm_problem;
import weka.classifiers.evaluation.NumericPrediction;
import weka.classifiers.functions.GaussianProcesses;
import weka.classifiers.timeseries.WekaForecaster;
import weka.core.Attribute;
import weka.core.DenseInstance;
import weka.core.FastVector;
import weka.core.Instance;
import weka.core.Instances;
import weka.core.Option;
import weka.core.converters.ConverterUtils.DataSource;
import weka.filters.supervised.attribute.TSLagMaker.Periodicity;

public abstract class Weka_ProcessBasis 
{ 
	double[] trainingObservationsInArray;
	double[] testingObservationsInArray;
	 
	double[] trainingPredictions; 
	double[] testingPredictions; 
	
	
	WekaForecaster forecaster = new WekaForecaster();
	
	DiverseSetting diverseSetting;

	
	String targetAttributeName = "TS";
	
	
	
	public Weka_ProcessBasis(DiverseSetting diverseSetting)
	{
		this.diverseSetting = diverseSetting;
	}
	
	
	public ForecastingOutcomeOfASegment preidct_Mode1(List<ObservationsAtOneTimePoint> timeSeries, int[][] trainingDataIndeces, int[][] testingDataIndeces, ForecastingOutcomeOfASegment forecastingOutcomeOfASegment) throws Exception
	{  
	   //preparing training data (training observations)
	   this.trainingObservationsInArray = this.getDataInArray(timeSeries, trainingDataIndeces, 0);
       this.trainingPredictions = new double[this.trainingObservationsInArray.length];
		  
        
	   forecastingOutcomeOfASegment.setTrainingObservations(this.trainingObservationsInArray); 
	   
	   
	   //prepare training data for Weka
	   Instances trainingObservationsForWeka = this.transformAsDataFormatForWeka( this.trainingObservationsInArray);
			 
	   
	   //set the Weka forecaster used
	   this.setWekaForecaster();

	   
	   //configuration setting
	   this.forecaster.setFieldsToForecast(this.targetAttributeName);//set the attribute to predict
	   this.forecaster.getTSLagMaker().setAdjustForTrends(false);//set to not involve trend (do not include any time index as predictor variable)
	  
	   
	   this.forecaster.getTSLagMaker().setPeriodicity(Periodicity.UNKNOWN);
	   this.forecaster.getTSLagMaker().setMinLag(1);
	   this.forecaster.getTSLagMaker().setMaxLag(this.diverseSetting.getNumberOfPreviousTimePointsAllowedToUse());  
	   this.forecaster.getTSLagMaker().setAddMonthOfYear(false);
	   this.forecaster.getTSLagMaker().setAddQuarterOfYear(false);
	   this.forecaster.getTSLagMaker().setLagRange("1-" + this.diverseSetting.getNumberOfPreviousTimePointsAllowedToUse());

	   
	  // /**
	   //show the values of options (configuration setting)
	   String[] options =  this.forecaster.getTSLagMaker().getOptions();
      
	   for(String option:options)
       {
		   System.out.print(option + " ");
	   }
       
	   System.out.println("");
	   //*/
	   
	   /**
	   //show all option names and their description 
       java.util.Enumeration<Option> allOptions =  this.forecaster.getTSLagMaker().listOptions();
       while(allOptions.hasMoreElements())
       {
	     Option option = allOptions.nextElement();
	     
	     System.out.println(option.name() + "   " + option.description());
       }
       */
       
       
	       long predictorGenerationTime_start = ManagementFactory.getThreadMXBean( ).getCurrentThreadCpuTime();  
	   
	    // build the model
	   this.forecaster.buildForecaster(trainingObservationsForWeka, System.out);
	       
	       long predictorGenerationTime_end = ManagementFactory.getThreadMXBean( ).getCurrentThreadCpuTime();     
       
           long predictorGenerationTime = (predictorGenerationTime_end-predictorGenerationTime_start);
           
       //show the trained forecaster    
       System.out.println(this.forecaster.toString()); 
         
           
       forecastingOutcomeOfASegment.setPredictorProductionTime(predictorGenerationTime / 1000000000.0); 
	   
	    
       //use the generated predictor to produce forecasts (testing predictions) 
	   this.testingObservationsInArray = this.getDataInArray(timeSeries, testingDataIndeces, 0);
	      
	   
	   forecastingOutcomeOfASegment.setTestingObservations(this.testingObservationsInArray);
	      
		  
	   this.testingPredictions = new double[this.testingObservationsInArray.length];//for containing testing predictions
	      
	      
	      long forecastGenerationTime_start = ManagementFactory.getThreadMXBean( ).getCurrentThreadCpuTime();
	   
	    //generate the testing predictions
	   for(int i = 0 ; i < this.testingPredictions.length; i++)
	   {
		   double[] predictorInputsForTestingPredictions = this.getDataInArray(timeSeries, trainingDataIndeces, i);//prepare predictor inputs (incrementally)	
           
		   Instances predictorInputsForTestingPredictionsForWeka = this.transformAsDataFormatForWeka(predictorInputsForTestingPredictions);
		   
		   this.forecaster.primeForecaster(predictorInputsForTestingPredictionsForWeka);
		   
		   
		   List<List<NumericPrediction>> predictions = this.forecaster.forecast(1, null);
		   
		   this.testingPredictions[i] = predictions.get(0).get(0).predicted(); 
   if( this.testingPredictions[i] < 0){System.out.println("negative value");}   		   
	   }
	   
	     long forecastGenerationTime_end = ManagementFactory.getThreadMXBean( ).getCurrentThreadCpuTime();     
	      
         long forecastGenerationTime = (forecastGenerationTime_end - forecastGenerationTime_start);

         
       forecastingOutcomeOfASegment.setTestingPredictions(this.testingPredictions);     
       forecastingOutcomeOfASegment.setTestingForecastsProductionTime(forecastGenerationTime / 1000000000.0); 
	   
		
       
         forecastGenerationTime_start = ManagementFactory.getThreadMXBean( ).getCurrentThreadCpuTime(); 
      
       int index = 0;//to be the index of prediction position 
       
       //generate the training predictions  
       for(int j = trainingDataIndeces[0][0]; j <= trainingDataIndeces[0][1]; j++)//the indexes contained in the interval
       {
           List<Double> predictorInputsForTrainingPredictions = new ArrayList<Double>();//for containing predictor inputs
             
           for(int k = 0; k < j ; k++)      //set predictor inputs
           {
             predictorInputsForTrainingPredictions.add((double)timeSeries.get(k).getResponseTime()); 
           }
     
           double[] predictorInputsForTrainingPredictionsInArray = new double[predictorInputsForTrainingPredictions.size()];
           for(int q = 0; q < predictorInputsForTrainingPredictions.size(); q++)
           {
              predictorInputsForTrainingPredictionsInArray[q] =  predictorInputsForTrainingPredictions.get(q);
           } 
             
             
           Instances predictorInputsForTrainingPredictionsForWeka = this.transformAsDataFormatForWeka(predictorInputsForTrainingPredictionsInArray);
  		   
  		   this.forecaster.primeForecaster(predictorInputsForTrainingPredictionsForWeka);
  		   
  		   
  		   List<List<NumericPrediction>> predictions = this.forecaster.forecast(1, System.out);
  		   
  		   this.trainingPredictions[index] = predictions.get(0).get(0).predicted();  
   if( this.trainingPredictions[index] < 0){System.out.println("negative value");}          
             
           index++;//go to next (training) prediction position
       }
       
	      
	     forecastGenerationTime_end = ManagementFactory.getThreadMXBean( ).getCurrentThreadCpuTime();
	     forecastGenerationTime = (forecastGenerationTime_end - forecastGenerationTime_start);
     
	     
	   forecastingOutcomeOfASegment.setTrainingPredictions(this.trainingPredictions);   
	   forecastingOutcomeOfASegment.setTrainingForecastsProductionTime(forecastGenerationTime / 1000000000.0);
       
		
   	   return forecastingOutcomeOfASegment;
	}
	
	
	protected abstract void setWekaForecaster();
	
	
	protected double[] getDataInArray(List<ObservationsAtOneTimePoint> timeSeries, int[][] dataIndeces, int incrementNumber)
	{
	 	  List<ObservationsAtOneTimePoint> data = new ArrayList<ObservationsAtOneTimePoint>();
	 	     
	 	  for(int i = 0; i < dataIndeces.length; i++)  
	 	  {  
	 	     for(int j = dataIndeces[i][0]; j <= dataIndeces[i][1]; j++)
	 	     {
	 	        data.add(timeSeries.get(j));
	 	     }
	 	  }
	 	     
	 	  
	 	  if(incrementNumber != 0)
	 	  {
	 		  for(int i = 1; i <= incrementNumber; i++)
	 		  {
	 			  data.add(timeSeries.get(dataIndeces[dataIndeces.length - 1][1] + i)); 
	 		  }
	 	  }
	 	  
	 	  
	 	  double[] dataInArray = new double[data.size()];
	 	     
	 	  for(int i = 0; i < dataInArray.length; i++) 
	 	  {
	 	     dataInArray[i] = data.get(i).getResponseTime();
	 	  }
	 	  
	 	  
	 	  return dataInArray;
	}   
	
	
	protected Instances transformAsDataFormatForWeka(double[] data)
	{
		ArrayList<Attribute> attributes = new ArrayList<Attribute>();
		attributes.add( new Attribute(this.targetAttributeName) );
		   
		Instances trainingObservationsForWeka = new Instances("trainingData",attributes, 0);
				 
		double[] value;
		
		for(int i = 0; i < data.length; i++)//put time series observations into Weka data format
		{
			 value = new double[1];

		     value[0] =  data[i];
		       
		     trainingObservationsForWeka.add(new DenseInstance(1.0, value));
		}
		
		
		return trainingObservationsForWeka;
	}
}
