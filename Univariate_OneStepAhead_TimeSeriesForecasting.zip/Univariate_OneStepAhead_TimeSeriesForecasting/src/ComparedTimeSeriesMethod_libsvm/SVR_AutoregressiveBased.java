package ComparedTimeSeriesMethod_libsvm;

import libsvm.svm;
import libsvm.svm_node;

public class SVR_AutoregressiveBased extends SVR_ProcessBasis
{
	public SVR_AutoregressiveBased(boolean performGridSearchForCandGamma) 
	{
		super(performGridSearchForCandGamma);
		
	}

	int numberOfLaggedValues = 10; 
	
	
	@Override
	svm_node[][] setTrainingObservations() 
	{	  
	   svm_node[][] vectors = new svm_node[this.trainingObservationsInArray.length][numberOfLaggedValues];//is an array of svm_node, each node is one training vector. 
  
	   for(int i = 0; i < this.trainingObservationsInArray.length; i++)
	   {
		  svm_node[] vector = new svm_node[numberOfLaggedValues]; 
			 
		  for(int j = 0; j < vector.length; j++)
		  {
			 svm_node node = new svm_node(); 
			 node.index =  j + 1 ;
			 node.value = this.timeSeries.get(trainingDataIndeces[0][0] + i - (j + 1)).getResponseTime();
			 
			 vector[j] = node;
		  }
			 
		  vectors[i] = vector;
	   }
	   
	   return vectors; 
	}

	@Override
	void generateTestingPredictions() 
	{
		for(int i = 0; i < testingPredictions.length; i++)//generate the testing predictions
	    { 
	       svm_node[] vector = new svm_node[numberOfLaggedValues]; 
				 
		   for(int j = 0; j < vector.length; j++)
		   {
			   svm_node node = new svm_node(); 
			   node.index =  j + 1;
			   node.value = this.timeSeries.get(testingDataIndeces[0][0] + i - (j + 1)).getResponseTime();
			   
			   vector[j] = node;
		   }
	        
		   testingPredictions[i] = svm.svm_predict(svmPredictor, vector);   
	    }
	}

	@Override
	void generateTrainingPredictions()
	{
		 for(int i = 0; i < this.trainingPredictions.length; i++)//generate training predictions
		 { 
			 svm_node[] vector = new svm_node[numberOfLaggedValues]; 
			 
			 for(int j = 0; j < vector.length; j++)
			 {
				 svm_node node = new svm_node(); 
				 node.index =  j + 1 ;
				 node.value = this.timeSeries.get(trainingDataIndeces[0][0] + i - (j + 1)).getResponseTime();
				 
				 vector[j] = node;
			 }
		        
			 this.trainingPredictions[i] = svm.svm_predict(this.svmPredictor, vector);
		 }		
	}
}
