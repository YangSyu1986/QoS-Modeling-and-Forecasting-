package ComparedTimeSeriesMethod_libsvm;

import libsvm.svm;
import libsvm.svm_node;

public class SVR_TimeIndexBased extends SVR_ProcessBasis
{

	public SVR_TimeIndexBased(boolean performGridSearchForCandGamma) 
	{
		super(performGridSearchForCandGamma);
		
	}


	@Override
	svm_node[][] setTrainingObservations() 
	{
		svm_node[][] nodes = new svm_node[this.trainingObservationsInArray.length][1];//is an array of svm_node, each node is one training vector. 

		for(int i = 0; i < this.trainingObservationsInArray.length; i++)
		{
		   svm_node node = new svm_node(); 
		   node.index = 1;
		   node.value = i + 1;
			 
		   nodes[i][0] = node;
		}
		
		return nodes;
	}

	
	@Override
	void generateTestingPredictions() 
	{
	   for(int i = 0; i < this.testingPredictions.length; i++)//generate the testing predictions
	   { 
	     svm_node[] node = new svm_node[1]; 
	     node[0] = new svm_node();
	     node[0].index = 1;
		 node[0].value = i + this.trainingObservationsInArray.length + 1;
		  
	     this.testingPredictions[i] = svm.svm_predict(this.svmPredictor, node);   
	   }
	}

	@Override
	void generateTrainingPredictions()
	{
	   for(int i = 0; i < this.trainingPredictions.length; i++)//generate training predictions
	   { 
	     svm_node[] node = new svm_node[1];
	     node[0] = new svm_node();
	     node[0].index = 1;
		 node[0].value = i + 1;
	        
		 this.trainingPredictions[i] = svm.svm_predict(this.svmPredictor, node);
	   }
	}
}
