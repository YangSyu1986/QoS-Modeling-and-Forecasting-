package ComparedTimeSeriesMethod_libsvm;

import java.util.List;

import ComparedTimeSeriesMethods_R.R_ProcessBasis;
import ProposedTimeSeriesMethod_GP.Tools.ForecastingOutcomesProcessor;
import Utilities.CommonSetting.TimeSeriesIntervalsIndicesSet;
import Utilities.DataStructures.ForecastingOutcomeOfASegment;
import Utilities.DatasetProcessingModules.ObservationsAtOneTimePoint;
import Utilities.ForecastingAccuracyMeasures.DiverseErrorsOfASegment;
import Utilities.ForecastingAccuracyMeasures.DiverseMeasuringResultsOfASegment;
import Utilities.ForecastingCostMeasures.TimeCost;
import Utilities.PredictionExperimentsForComparedMethods.PredictionExperiments;


public class PredictionExperiments_SVR extends PredictionExperiments 
{
	
	
	public PredictionExperiments_SVR(List<List<ObservationsAtOneTimePoint>> timeSeries, int numberOfTimeseries,
			                         TimeSeriesIntervalsIndicesSet timeSeriesIntervalsIndicesSet,
			                     
			                         List<ForecastingOutcomeOfASegment[][]> outcomeOfDiverseMethods_ForecastingOutcomes,
			                         List<DiverseErrorsOfASegment[][]> outcomeOfDiverseMethods_DiverseErrors, 
                                     List<DiverseMeasuringResultsOfASegment[][]> outcomeOfDiverseMethods_AccuracyMeasures, 
                                     List<TimeCost[][]> outcomeOfDiverseMethods_TimeCosts
			                        )
    {
		super(timeSeries, numberOfTimeseries, timeSeriesIntervalsIndicesSet, 
				
			  outcomeOfDiverseMethods_ForecastingOutcomes, outcomeOfDiverseMethods_DiverseErrors,
			  outcomeOfDiverseMethods_AccuracyMeasures,  outcomeOfDiverseMethods_TimeCosts				
			 );
		
		
	}
	  
	

	@Override
	protected ForecastingOutcomeOfASegment invokeMethod(Object method, List<ObservationsAtOneTimePoint> timeSeries,
			                                            int[][] trainingDataIntervalsSet, int[][] testingDataIntervalsSet, ForecastingOutcomeOfASegment result) 
	{
		SVR_ProcessBasis svrMethod = (SVR_ProcessBasis) method;
		
	    result = svrMethod.preidct_Mode1(timeSeries, trainingDataIntervalsSet, testingDataIntervalsSet, result);	
		
		return result;
	}
}
