package ComparedTimeSeriesMethod_libsvm;

import java.lang.management.ManagementFactory;
import java.util.ArrayList;
import java.util.List;

import Utilities.DataStructures.ForecastingOutcomeOfASegment;
import Utilities.DatasetProcessingModules.ObservationsAtOneTimePoint;
import libsvm.svm;
import libsvm.svm_model;
import libsvm.svm_node;
import libsvm.svm_parameter;
import libsvm.svm_problem;

public abstract class SVR_ProcessBasis 
{
	 List<ObservationsAtOneTimePoint> timeSeries;
	 int[][] trainingDataIndeces;
	 int[][] testingDataIndeces;
	 ForecastingOutcomeOfASegment forecastingOutcomeOfASegment;
	
	 svm_problem problem;
	 svm_parameter parameter;
	 svm_model svmPredictor;
	 
	 double[] trainingObservationsInArray;
	 double[] testingObservationsInArray;
	 
	 double[] trainingPredictions; 
	 double[] testingPredictions; 
	 
	 
     boolean performGridSearchForCandGamma = false; 
     
     
     public SVR_ProcessBasis(boolean performGridSearchForCandGamma)
     {
    	 this.performGridSearchForCandGamma = performGridSearchForCandGamma;
     }	
	 
     
	 public ForecastingOutcomeOfASegment preidct_Mode1(List<ObservationsAtOneTimePoint> timeSeries, int[][] trainingDataIndeces, int[][] testingDataIndeces, ForecastingOutcomeOfASegment forecastingOutcomeOfASegment)
	 {
		 
		  this.trainingDataIndeces = trainingDataIndeces;
		  this.testingDataIndeces = testingDataIndeces;
		  this.forecastingOutcomeOfASegment = forecastingOutcomeOfASegment;
		 
		  //preparing training data (training observations)
		  this.trainingObservationsInArray = this.getDataInArray(timeSeries, trainingDataIndeces, 0);
          this.trainingPredictions = new double[this.trainingObservationsInArray.length];
		  
          
		  this.forecastingOutcomeOfASegment.setTrainingObservations(this.trainingObservationsInArray); 
		      
		  	  
		  //prepare SVR problem 
		  this.problem = new svm_problem();
		  
		  this.problem.l = this.trainingObservationsInArray.length;//the number of training data
		  this.problem.y = this.trainingObservationsInArray;//an array containing their target values. (real numbers in regression)
		  this.problem.x = this.setTrainingObservations();
		  
		  
		  //prepare SVR parameter
		  this.parameter = new svm_parameter();
		  
		  //these parameters are fixed (no need to find)
		  this.parameter.svm_type = 3;//EPSILON_SVR = 3;
		  this.parameter.kernel_type = 2;//RBF = 2;
		  this.parameter.cache_size = 100;//set cache memory size in MB (default 100)
		  
		  
		     //search optimal parameter values for SVR, and then train the model 
		     long predictorGenerationTime_start = ManagementFactory.getThreadMXBean( ).getCurrentThreadCpuTime();
		  
		  //
		  this.parameter.eps = 0.001;//set tolerance of termination criterion (default 0.001)
		  this.parameter.p = 0.1;//epsilon : set the epsilon in loss function of epsilon-SVR (default 0.1)
		  
		  this.parameter.gamma = 1;//set gamma in kernel function (default 1/num_features)
		  this.parameter.C = 1;//set the parameter C of C-SVC, epsilon-SVR, and nu-SVR (default 1)
		  
	     
		  //perform grid searching to obtain optimal gamma and C parameter values
          if(this.performGridSearchForCandGamma == true)
          {
        	  this.performGridSearchForCandGamma();
          }	  
		  
          
		  //check problem and parameter setting
		  String checkResult = svm.svm_check_parameter(this.problem, this.parameter);
		  
		  if(checkResult != null)
		  {
			 System.out.print("Something wrong in the specified problem/parameter. Message : ");
			 System.out.println(checkResult);
		  }
		     
		  
	      //after the search of optimal SVR parameter values, train the model
		  this.svmPredictor = svm.svm_train(this.problem, this.parameter);
	           
	         long predictorGenerationTime_end = ManagementFactory.getThreadMXBean( ).getCurrentThreadCpuTime();     
	          
	         long predictorGenerationTime = (predictorGenerationTime_end-predictorGenerationTime_start);
	         
	      this.forecastingOutcomeOfASegment.setPredictorProductionTime(predictorGenerationTime / 1000000000.0);    
	      
		   
	      //use the generated predictor to produce forecasts (testing predictions) 
	      this.testingObservationsInArray = this.getDataInArray(timeSeries, testingDataIndeces, 0);
	      
	      this.forecastingOutcomeOfASegment.setTestingObservations(this.testingObservationsInArray);
	      
		  
	      this.testingPredictions = new double[this.testingObservationsInArray.length];//for containing testing predictions
	      
	      
	          long forecastGenerationTime_start = ManagementFactory.getThreadMXBean( ).getCurrentThreadCpuTime();
	       
	      this.generateTestingPredictions();
	      
	          long forecastGenerationTime_end = ManagementFactory.getThreadMXBean( ).getCurrentThreadCpuTime();     
	      
	          long forecastGenerationTime = (forecastGenerationTime_end - forecastGenerationTime_start);
       
	      this.forecastingOutcomeOfASegment.setTestingPredictions(this.testingPredictions);     
	      this.forecastingOutcomeOfASegment.setTestingForecastsProductionTime(forecastGenerationTime / 1000000000.0);    
	          
	      
	      //use the generated predictor to produce forecasts (training predictions) 
	          forecastGenerationTime_start = ManagementFactory.getThreadMXBean( ).getCurrentThreadCpuTime();
	      
	      this.generateTrainingPredictions();
	      
	          forecastGenerationTime_end = ManagementFactory.getThreadMXBean( ).getCurrentThreadCpuTime();
	          forecastGenerationTime = (forecastGenerationTime_end - forecastGenerationTime_start);
        
	      this.forecastingOutcomeOfASegment.setTrainingPredictions(this.trainingPredictions);   
	      this.forecastingOutcomeOfASegment.setTrainingForecastsProductionTime(forecastGenerationTime / 1000000000.0); 
	      
		  return this.forecastingOutcomeOfASegment;
	  }
	   
	 
	  abstract svm_node[][] setTrainingObservations();
	  abstract void generateTestingPredictions();
	  abstract void generateTrainingPredictions();
		  
	  
	   //perform grid search for obtaining optimal SVM parameters
	  private void performGridSearchForCandGamma()
	  {
		  double searchingInterval = 1;
		   
		  double bestGamma = 0;
		  double bestC = 0;
		 
		  
		  double lowestErrorValue = Double.POSITIVE_INFINITY;
		  
		  
		  for(double i = -15; i <= 3; i = i + searchingInterval)
		  {
			  for(double j = -5; j <= 15; j = j + searchingInterval)
			  {
				   
				this.parameter.gamma = Math.pow(2, i);//set gamma in kernel function (default 1/num_features)
				this.parameter.C = Math.pow(2, j);//set the parameter C of C-SVC, epsilon-SVR, and nu-SVR (default 1)		
							  
			    this.svmPredictor = svm.svm_train(this.problem, this.parameter);
						  
						  
				this.generateTrainingPredictions();
						  
						  
				double currentError = 0;
				for(int n = 0; n < this.trainingObservationsInArray.length; n++ )
			    {
				  currentError = currentError + (Math.abs(this.trainingObservationsInArray[n] - this.trainingPredictions[n]));
				}
				currentError = currentError/this.trainingObservationsInArray.length;
						  
						  	  
				if(currentError < lowestErrorValue)
				{
					lowestErrorValue = currentError;
							  
					bestGamma = Math.pow(2, i);
					bestC = Math.pow(2, j);
				}
					
			  }
		  }
		  
		  
		  this.parameter.gamma = bestGamma;
		  this.parameter.C = bestC;		  
	  }
	  
	  
	  
	  protected double[] getDataInArray(List<ObservationsAtOneTimePoint> timeSeries, int[][] dataIndeces, int incrementNumber)
	  {
	 	  List<ObservationsAtOneTimePoint> data = new ArrayList<ObservationsAtOneTimePoint>();
	 	     
	 	  for(int i = 0; i < dataIndeces.length; i++)  
	 	  {  
	 	     for(int j = dataIndeces[i][0]; j <= dataIndeces[i][1]; j++)
	 	     {
	 	        data.add(timeSeries.get(j));
	 	     }
	 	  }
	 	     
	 	  
	 	  if(incrementNumber != 0)
	 	  {
	 		  for(int i = 1; i <= incrementNumber; i++)
	 		  {
	 			  data.add(timeSeries.get(dataIndeces[dataIndeces.length - 1][1] + i)); 
	 		  }
	 	  }
	 	  
	 	  
	 	  double[] dataInArray = new double[data.size()];
	 	     
	 	  for(int i = 0; i < dataInArray.length; i++) 
	 	  {
	 	     dataInArray[i] = data.get(i).getResponseTime();
	 	  }
	 	  
	 	  
	 	  return dataInArray;
	  }   
}
