package ProposedTimeSeriesMethod_GP.Setting;

public class DiverseSetting 
{
	int numberOfTimeSeries;
	int numberOfRepeatsForATimeSeriesSegment; 
	   
	int numberOfChromosomesInAPopulation;
	int numberOfGenerations;
	float crossoverProbability;
	float mutationProbability;
	float newChromosomesInAPopulationProbability;
	      
	int numberOfPreviousTimePointsAllowedToUse;
	String functionSet;
	int roundsOfConstantGeneration;
	int powerUpperBound;
	   
	int limitationOfNodesInAChromosome;
	int minDepth;
	int maxDepth;
	   
	boolean openPunishment;
	boolean isElitismEnabled;
	
	public DiverseSetting()
	{
		this.numberOfTimeSeries = 1;
		this.numberOfRepeatsForATimeSeriesSegment = 3;
		
		this.numberOfChromosomesInAPopulation = 1000;
		this.numberOfGenerations = 50;
		this.crossoverProbability = 0.9f;
		this.mutationProbability = 0.05f;
		this.newChromosomesInAPopulationProbability = 0.1f;
		
		this.numberOfPreviousTimePointsAllowedToUse = 15;//35;
		this.functionSet = "+ - * / min max mod pow sine cosine tangent abs floor ceil round log exp";
		  //this.functionSet = "+ - * /  mod pow sine cosine tangent abs floor ceil round log exp";
		  //this.functionSet="+ - * /";  
	    this.roundsOfConstantGeneration = 1;
	    this.powerUpperBound = 1;
	   
	    this.limitationOfNodesInAChromosome = 128;
	    this.minDepth = 2;
	    this.maxDepth = 6;
	    
	    this.openPunishment = true;
	    this.isElitismEnabled = true;
	}
	
	
	public int getNumberOfTimeSeries()
	{
		return this.numberOfTimeSeries;	
	}

	public int getNumberOfRepeatsForATimeseriesSegment() 
	{
		return this.numberOfRepeatsForATimeSeriesSegment;
	}

	public int getNumberOfChromosomesInAPopulation() 
	{
		return this.numberOfChromosomesInAPopulation;
	}

	public int getNumberOfGenerations() 
	{
		return this.numberOfGenerations;
	}

	public float getCrossoverProbability()
	{
		return this.crossoverProbability;
	}

	public float getMutationProbability()
	{
		return this.mutationProbability;
	}

	public float getNewChromosomesInAPopulationProbability() 
	{
		return this.newChromosomesInAPopulationProbability;
	}

	public int getNumberOfPreviousTimePointsAllowedToUse()
	{
		return this.numberOfPreviousTimePointsAllowedToUse;
	}

	public String getFunctionSet()
	{
		return this.functionSet;
	}

	public int getRoundsOfConstantGeneration()
	{
		return this.roundsOfConstantGeneration;
	}

	public int getPowerUpperBound() 
	{
		return this.powerUpperBound;
	}

	public int getLimitationOfNodesInAChromosome()
	{
		return this.limitationOfNodesInAChromosome;
	}

	public int getMinDepth() 
	{
		return this.minDepth;
	}

	public int getMaxDepth()
	{
		return this.maxDepth;
	}

	public boolean isOpenPunishment() 
	{
		return this.openPunishment;
	}

	public boolean isElitismEnabled() 
	{
		return this.isElitismEnabled;
	}
}
