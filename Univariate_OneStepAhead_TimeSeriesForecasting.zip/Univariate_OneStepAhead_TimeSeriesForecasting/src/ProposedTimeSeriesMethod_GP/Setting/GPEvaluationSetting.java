package ProposedTimeSeriesMethod_GP.Setting;

import org.jgap.Configuration;
import org.jgap.InvalidConfigurationException;

import ProposedTimeSeriesMethod_GP.FitnessFunctions.FitnessFunctionBasis;
import ProposedTimeSeriesMethod_GP.FitnessFunctions.FitnessFunction_MAE;
import ProposedTimeSeriesMethod_GP.FitnessFunctions.FitnessFunction_MAPE;
import ProposedTimeSeriesMethod_GP.FitnessFunctions.WeightBased.WeightedMAEInspiredBySES;
import ProposedTimeSeriesMethod_GP.prediction.GPPredictionConfiguration;


public class GPEvaluationSetting 
{
	FitnessFunctionBasis mainTrainingFitnessFunction;  
	FitnessFunctionBasis mainValidator;
	FitnessFunctionBasis maintTester;
	
	FitnessFunctionBasis secondTrainingFitnessFunction;  
	FitnessFunctionBasis secondValidator;
	FitnessFunctionBasis secondTester;
	

	GPPredictionConfiguration GPConfiguration;
	
	
	
	public GPEvaluationSetting(GPPredictionConfiguration GPConfiguration, FitnessFunctionBasis mainTrainingFitnessFunction) throws InvalidConfigurationException
	{
		this.GPConfiguration = GPConfiguration;
		
		
		this.mainTrainingFitnessFunction = mainTrainingFitnessFunction;
		this.mainValidator = new FitnessFunction_MAE();
		this.maintTester = new FitnessFunction_MAE();
		
		this.secondTrainingFitnessFunction = new FitnessFunction_MAPE();
		this.secondValidator = new FitnessFunction_MAPE();
		this.secondTester = new FitnessFunction_MAPE();
		
		
		this.mainTrainingFitnessFunction.setOpenPunishment(this.GPConfiguration.getDiverseSetting().isOpenPunishment());
		
		
		this.mainTrainingFitnessFunction.setVariables(this.GPConfiguration.getVariables());  
		this.mainValidator.setVariables(this.GPConfiguration.getVariables());
		this.maintTester.setVariables(this.GPConfiguration.getVariables());   
		
		this.secondTrainingFitnessFunction.setVariables(this.GPConfiguration.getVariables());  
		this.secondValidator.setVariables(this.GPConfiguration.getVariables());
		this.secondTester.setVariables(this.GPConfiguration.getVariables());   
		   
		
		this.GPConfiguration.setFitnessFunction(this.mainTrainingFitnessFunction); //set the fitness function of GP 
	}
	
	
	
	public FitnessFunctionBasis getMainTrainingFitnessFunction()
	{
		return this.mainTrainingFitnessFunction;
	}

	public FitnessFunctionBasis getMainValidator()
	{
		return this.mainValidator;
	}

	public FitnessFunctionBasis getMaintTester()
	{
		return this.maintTester;
	} 
	
	
	public FitnessFunctionBasis getSecondTrainingFitnessFunction()
	{
		return secondTrainingFitnessFunction;
	}

	public FitnessFunctionBasis getSecondValidator() 
	{
		return secondValidator;
	}

	public FitnessFunctionBasis getSecondTester()
	{
		return secondTester;
	}
}
