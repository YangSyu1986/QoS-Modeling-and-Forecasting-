/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package ProposedTimeSeriesMethod_GP.Tools;

import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;

import ProposedTimeSeriesMethod_GP.FitnessFunctions.FitnessFunctionBasis;
import ProposedTimeSeriesMethod_GP.FitnessFunctions.FitnessFunction_MAE;
import ProposedTimeSeriesMethod_GP.Setting.DiverseSetting;
import ProposedTimeSeriesMethod_GP.Setting.GPEvaluationSetting;
import Utilities.CommonSetting.TimeSeriesIntervalsIndicesSet;

/**
 *
 * @author YangSyu
 */
public class SettingFileMaker 
{
    private PrintWriter writer; 
    
    private DiverseSetting setting;
    
    private GPEvaluationSetting evaluation;
    
    private TimeSeriesIntervalsIndicesSet timeSeriesIntervalsIndicesSet;
    
    
    public SettingFileMaker(String filePath, DiverseSetting setting, GPEvaluationSetting evaluation,
    		                TimeSeriesIntervalsIndicesSet timeSeriesIntervalsIndicesSet) throws FileNotFoundException, UnsupportedEncodingException
    {
      this.writer = new PrintWriter(filePath + "/" + "Setting.txt", "UTF-8");
      
      this.setting = setting;
      
      this.evaluation = evaluation;
      
      this.timeSeriesIntervalsIndicesSet = timeSeriesIntervalsIndicesSet;
      
      
      this.writeSettingParameters();
      
      this.writeFitnessFunctionsAndTheirDataRanges();
      
      this.close();
    }
    
    private void writeSettingParameters()                                      
    {
     this.writer.println("Number Of Time Series = " + this.setting.getNumberOfTimeSeries());
     this.writer.println("Number Of Repeats For A Time Series = " + this.setting.getNumberOfRepeatsForATimeseriesSegment());
     this.writer.println("");
     
     this.writer.println("Number Of Chromosomes in A Population = " + this.setting.getNumberOfChromosomesInAPopulation());
     this.writer.println("Crossover Probability = " + this.setting.getCrossoverProbability());
     this.writer.println("Mutation Probability = " + this.setting.getMutationProbability());
     this.writer.println("New Chromosomes Probability = " + this.setting.getNewChromosomesInAPopulationProbability());
     this.writer.println("Number Of Generations = " + this.setting.getNumberOfGenerations());
     this.writer.println(""); 
     
     this.writer.println("Number Of Previous Time Points Allowed To Use = " + this.setting.getNumberOfPreviousTimePointsAllowedToUse());
     this.writer.println("FunctionSet = " + this.setting.getFunctionSet());
     this.writer.println("Rounds Of Constant Generation = " + this.setting.getRoundsOfConstantGeneration()); 
     this.writer.println("Power Upper Bound = " + this.setting.getPowerUpperBound());
     
   
     this.writer.println("limitation Of Nodes In A Chromosome = " + this.setting.getLimitationOfNodesInAChromosome());
     this.writer.println("Min Depth = " + this.setting.getMinDepth());
     this.writer.println("Max Depth = " + this.setting.getMinDepth());
     
     this.writer.println("");this.writer.println("");this.writer.println("");   
    }
    
    
    private void writeFitnessFunctionsAndTheirDataRanges()
    {
      this.writer.println("Open Punishment for Fitness Function = " + this.setting.isOpenPunishment());
      this.writer.println("Elitism is enabled = " + this.setting.isElitismEnabled());
      this.writer.println(""); 
      
      this.writer.println("Training Data Intervals Set = "+this.rangeProcessor(this.timeSeriesIntervalsIndicesSet.getTrainingIntervalsIndicesSet()));
      this.writer.println("Validating Data Intervals Set = "+this.rangeProcessor(this.timeSeriesIntervalsIndicesSet.getValidatingIntervalsIndicesSet()));      
      this.writer.println("Testing Data Intervals Set = "+this.rangeProcessor(this.timeSeriesIntervalsIndicesSet.getTestingIntervalsIndicesSet()));
     
      this.writer.println("Training Fitness Function (Trainner)    = " + this.evaluation.getMainTrainingFitnessFunction().getClass().getSimpleName());
      this.writer.println("Validating Fitness Function (Validator) = " + this.evaluation.getMainValidator().getClass().getSimpleName()); 
      this.writer.println("Testing Fitness Function (Tester)       = " + this.evaluation.getMaintTester().getClass().getSimpleName()); 
    }
    
    private String rangeProcessor(int[][][] ranges)
    {
      String returnString="\n";
      
      for(int[][] range:ranges)
      {
        returnString=returnString+"             {";
        
        for(int[] subRange:range)
        {
          returnString=returnString+"( "+subRange[0]+", "+subRange[1]+" ), ";
        }
        
        returnString=returnString+"}\n";
      }
   
      return returnString;
    }
    
      
    private void close()
    {
       this.writer.close();
    }
}
