/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package ProposedTimeSeriesMethod_GP.Tools;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.List;
import org.apache.poi.hssf.usermodel.HSSFPatriarch;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Chart;
import org.apache.poi.ss.usermodel.ClientAnchor;
import org.apache.poi.ss.usermodel.Drawing;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.charts.AxisCrosses;
import org.apache.poi.ss.usermodel.charts.AxisPosition;
import org.apache.poi.ss.usermodel.charts.ChartAxis;
import org.apache.poi.ss.usermodel.charts.ChartDataSource;
import org.apache.poi.ss.usermodel.charts.ChartLegend;
import org.apache.poi.ss.usermodel.charts.DataSources;
import org.apache.poi.ss.usermodel.charts.LegendPosition;
import org.apache.poi.ss.usermodel.charts.LineChartData;
import org.apache.poi.ss.usermodel.charts.LineChartSeries;
import org.apache.poi.ss.usermodel.charts.ValueAxis;
import org.apache.poi.ss.util.CellRangeAddress;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

/**
 *
 * @author YangSyu
 */
public class ExcelMaker 
{
    String pathAndFileName;
    FileOutputStream fileOutputStream;
    Workbook workbook = new XSSFWorkbook();
    Sheet sheetUnderOperation;
    List<Row> sheetRowsUnderOperation;
    int numberOfCeilsJumping;
    Drawing drawingUnderOperation;
      
    
    
    public ExcelMaker(String filePath, String fileName, int numberOfCeilsJumping) throws FileNotFoundException 
    {
        this.pathAndFileName=filePath + "/" + fileName;
        this.fileOutputStream = new FileOutputStream(this.pathAndFileName+".xlsx");

        this.numberOfCeilsJumping = numberOfCeilsJumping;
    }
    

    public void createSheet(String sheetName, int generationNumber)
    {
        this.sheetUnderOperation = this.workbook.createSheet(sheetName);  
        this.sheetUnderOperation.setDefaultColumnWidth(25);
        
        this.sheetRowsUnderOperation = new ArrayList<Row>();

        this.sheetRowsUnderOperation.add(this.sheetUnderOperation.createRow(0));
        for (int row = 1; row < (generationNumber + 4); row++) 
        {
            this.sheetRowsUnderOperation.add(this.sheetUnderOperation.createRow(row));
        }
        
        this.drawingUnderOperation=this.sheetUnderOperation.createDrawingPatriarch();
    }

    public void addExperimentDataTitles(int repeat) 
    {
        (this.sheetRowsUnderOperation.get(0).createCell(repeat * this.numberOfCeilsJumping)).
                setCellValue("Ex. " + repeat + ", training values");
        (this.sheetRowsUnderOperation.get(0).createCell((repeat * this.numberOfCeilsJumping) + 1)).
                setCellValue("validating values");
        (this.sheetRowsUnderOperation.get(0).createCell((repeat * this.numberOfCeilsJumping) + 2)).
                setCellValue("testing values");
        (this.sheetRowsUnderOperation.get(0).createCell((repeat * this.numberOfCeilsJumping) + 3)).
                setCellValue("nodes, number of");
        (this.sheetRowsUnderOperation.get(0).createCell((repeat * this.numberOfCeilsJumping) + 4)).
                setCellValue("levels, number of");
        (this.sheetRowsUnderOperation.get(0).createCell((repeat * this.numberOfCeilsJumping) + 5)).
                setCellValue("Best predictor");
    }

    public void addDataOfAGeneration(int generation, int repeat, double fitnessValue,
                                     double validatingValue, double testingValue,
                                     int numberOfNodes, int numberOfLevels,
                                     String bestPredictor) 
    {/**System.out.println(generation+"   "+  repeat+"    "+  fitnessValue+"     "+
                                      validatingValue+"    "+  testingValue+"     "+
                                      numberOfNodes+"     "+  numberOfLevels);*/
        (this.sheetRowsUnderOperation.get(generation + 1).createCell(repeat * numberOfCeilsJumping)).
                setCellValue(fitnessValue);
        (this.sheetRowsUnderOperation.get(generation + 1).createCell((repeat * numberOfCeilsJumping) + 1)).
                setCellValue(validatingValue);
        (this.sheetRowsUnderOperation.get(generation + 1).createCell((repeat * numberOfCeilsJumping) + 2)).
                setCellValue(testingValue);
        (this.sheetRowsUnderOperation.get(generation + 1).createCell((repeat * numberOfCeilsJumping) + 3)).
                setCellValue(numberOfNodes);
        (this.sheetRowsUnderOperation.get(generation + 1).createCell((repeat * numberOfCeilsJumping) + 4)).
                setCellValue(numberOfLevels);
        (this.sheetRowsUnderOperation.get(generation + 1).createCell((repeat * numberOfCeilsJumping) + 5)).
                setCellValue(bestPredictor);

    }
    
    public void addEvolutionAndForecastProductionTime
    (int numberOfGenerations, int repeat, double evolutionTime, double forecastProductionTime)
    {
       (this.sheetRowsUnderOperation.get(numberOfGenerations + 1).createCell(repeat * numberOfCeilsJumping)).
                setCellValue("Evolution time");
       (this.sheetRowsUnderOperation.get(numberOfGenerations + 1).createCell((repeat * numberOfCeilsJumping) + 1)).
                setCellValue("Best predictor forecast production time");
       
       (this.sheetRowsUnderOperation.get(numberOfGenerations + 2).createCell(repeat * numberOfCeilsJumping)).
                setCellValue(evolutionTime);
       (this.sheetRowsUnderOperation.get(numberOfGenerations + 2).createCell((repeat * numberOfCeilsJumping) + 1)).
                setCellValue(forecastProductionTime);
    }
    
    
    int chartHeight=16; 
    
    public void drawChartsForThisExperiment(int numberOfGenerations, int repeat)
    {
      ClientAnchor anchorForTrainingValues=this.drawingUnderOperation.createAnchor(0, 0, 0, 0, 
       (repeat*this.numberOfCeilsJumping), this.sheetRowsUnderOperation.size()+4, 
       ((repeat+1)*this.numberOfCeilsJumping), this.sheetRowsUnderOperation.size()+this.chartHeight);
      ClientAnchor anchorForValidatingValues=this.drawingUnderOperation.createAnchor(0, 0, 0, 0, 
       (repeat*this.numberOfCeilsJumping), this.sheetRowsUnderOperation.size()+this.chartHeight, 
       ((repeat+1)*this.numberOfCeilsJumping), this.sheetRowsUnderOperation.size()+(this.chartHeight*2));
      ClientAnchor anchorForTestingValues=this.drawingUnderOperation.createAnchor(0, 0, 0, 0, 
       (repeat*this.numberOfCeilsJumping), this.sheetRowsUnderOperation.size()+(this.chartHeight*2), 
       ((repeat+1)*this.numberOfCeilsJumping), this.sheetRowsUnderOperation.size()+(this.chartHeight*3));
      ClientAnchor anchorForNodesAndLevelsValues=this.drawingUnderOperation.createAnchor(0, 0, 0, 0, 
       (repeat*this.numberOfCeilsJumping), this.sheetRowsUnderOperation.size()+(this.chartHeight*3), 
       ((repeat+1)*this.numberOfCeilsJumping), this.sheetRowsUnderOperation.size()+(this.chartHeight*4));
            
       
       Chart chartForTrainingValues=this.drawingUnderOperation.createChart(anchorForTrainingValues);
         chartForTrainingValues.getOrCreateLegend().setPosition(LegendPosition.RIGHT);
       Chart chartForValidatingValues=this.drawingUnderOperation.createChart(anchorForValidatingValues);
         chartForValidatingValues.getOrCreateLegend().setPosition(LegendPosition.RIGHT);
       Chart chartForTestingValues=this.drawingUnderOperation.createChart(anchorForTestingValues);
         chartForTestingValues.getOrCreateLegend().setPosition(LegendPosition.RIGHT);
       Chart chartForNodesAndLevelsValues=this.drawingUnderOperation.createChart(anchorForNodesAndLevelsValues);
         chartForNodesAndLevelsValues.getOrCreateLegend().setPosition(LegendPosition.RIGHT);
       
         ChartAxis bottomAxis = chartForTrainingValues.getChartAxisFactory().createCategoryAxis(AxisPosition.BOTTOM);
         ValueAxis leftAxis = chartForTrainingValues.getChartAxisFactory().createValueAxis(AxisPosition.LEFT);
       
     
         ChartAxis bottomAxis2 = chartForValidatingValues.getChartAxisFactory().createCategoryAxis(AxisPosition.BOTTOM);
         ValueAxis leftAxis2 = chartForValidatingValues.getChartAxisFactory().createValueAxis(AxisPosition.LEFT);
        
         
         ChartAxis bottomAxis3 = chartForTestingValues.getChartAxisFactory().createCategoryAxis(AxisPosition.BOTTOM);
         ValueAxis leftAxis3 = chartForTestingValues.getChartAxisFactory().createValueAxis(AxisPosition.LEFT);
         
     
         ChartAxis bottomAxis4 = chartForNodesAndLevelsValues.getChartAxisFactory().createCategoryAxis(AxisPosition.BOTTOM);
         ValueAxis leftAxis4 = chartForNodesAndLevelsValues.getChartAxisFactory().createValueAxis(AxisPosition.LEFT);
         
         
         Integer[] xAxisIndeces=new Integer[numberOfGenerations];
         for(int i=0;i<xAxisIndeces.length;i++)
         {xAxisIndeces[i]=i+1;}
       
         ChartDataSource<Integer> xAxis =DataSources.fromArray(xAxisIndeces);
         
       LineChartData data = chartForTrainingValues.getChartDataFactory().createLineChartData(); 
       ChartDataSource<Number> y = DataSources.fromNumericCellRange(this.sheetUnderOperation, new CellRangeAddress
          (1, numberOfGenerations, repeat*this.numberOfCeilsJumping, repeat*this.numberOfCeilsJumping));
       data.addSeries(xAxis, y); 
       data.getSeries().get(0).setTitle("Training Values");  
       chartForTrainingValues.plot(data, new ChartAxis[] { bottomAxis, leftAxis });
    
       data = chartForValidatingValues.getChartDataFactory().createLineChartData(); 
       y = DataSources.fromNumericCellRange(this.sheetUnderOperation, new CellRangeAddress
          (1, numberOfGenerations, (repeat*this.numberOfCeilsJumping)+1, (repeat*this.numberOfCeilsJumping)+1));
       data.addSeries(xAxis, y);
       data.getSeries().get(0).setTitle("Validating Values");
       chartForValidatingValues.plot(data, new ChartAxis[] { bottomAxis2, leftAxis2 });
       
       data = chartForTestingValues.getChartDataFactory().createLineChartData(); 
       y = DataSources.fromNumericCellRange(this.sheetUnderOperation, new CellRangeAddress
          (1, numberOfGenerations, (repeat*this.numberOfCeilsJumping)+2, (repeat*this.numberOfCeilsJumping)+2));
       data.addSeries(xAxis, y);
       data.getSeries().get(0).setTitle("Testing Values");
       chartForTestingValues.plot(data, new ChartAxis[] { bottomAxis3, leftAxis3 });
       
       data = chartForNodesAndLevelsValues.getChartDataFactory().createLineChartData(); 
       y = DataSources.fromNumericCellRange(this.sheetUnderOperation, new CellRangeAddress
          (1, numberOfGenerations, (repeat*this.numberOfCeilsJumping)+3, (repeat*this.numberOfCeilsJumping)+3));
       data.addSeries(xAxis, y);
       data.getSeries().get(0).setTitle("Nodes Values");
        
       y = DataSources.fromNumericCellRange(this.sheetUnderOperation, new CellRangeAddress
          (1, numberOfGenerations, (repeat*this.numberOfCeilsJumping)+4, (repeat*this.numberOfCeilsJumping)+4));
       data.addSeries(xAxis, y);
       data.getSeries().get(1).setTitle("Levels Values");
  
       chartForNodesAndLevelsValues.plot(data, new ChartAxis[] { bottomAxis4, leftAxis4 });
    }

    public void calculateAverageValues(int numberOfRepeats) throws IOException
    {
        (this.sheetRowsUnderOperation.get(0).
                createCell(numberOfRepeats * this.numberOfCeilsJumping)).setCellValue("ave. training values");
        (this.sheetRowsUnderOperation.get(0).
                createCell((numberOfRepeats * this.numberOfCeilsJumping) + 1)).setCellValue("ave. validating values");
        (this.sheetRowsUnderOperation.get(0).
                createCell((numberOfRepeats * this.numberOfCeilsJumping) + 2)).setCellValue("ave. testing values");
        (this.sheetRowsUnderOperation.get(0).
                createCell((numberOfRepeats * this.numberOfCeilsJumping) + 3)).setCellValue("ave. nodes, number of");
        (this.sheetRowsUnderOperation.get(0).
                createCell((numberOfRepeats * this.numberOfCeilsJumping) + 4)).setCellValue("ave.levels, number of");


        for (int i = 1; i < this.sheetRowsUnderOperation.size() ; i++) 
        {
          (this.sheetRowsUnderOperation.get(i).createCell(numberOfRepeats * numberOfCeilsJumping)).
               setCellValue(this.getAverageValue(this.sheetRowsUnderOperation.get(i), 0, numberOfRepeats));
          (this.sheetRowsUnderOperation.get(i).createCell((numberOfRepeats * numberOfCeilsJumping)+1)).
               setCellValue(this.getAverageValue(this.sheetRowsUnderOperation.get(i), 1, numberOfRepeats));
          (this.sheetRowsUnderOperation.get(i).createCell((numberOfRepeats * numberOfCeilsJumping)+2)).
               setCellValue(this.getAverageValue(this.sheetRowsUnderOperation.get(i), 2, numberOfRepeats));
          (this.sheetRowsUnderOperation.get(i).createCell((numberOfRepeats * numberOfCeilsJumping)+3)).
               setCellValue(this.getAverageValue(this.sheetRowsUnderOperation.get(i), 3, numberOfRepeats));
          (this.sheetRowsUnderOperation.get(i).createCell((numberOfRepeats * numberOfCeilsJumping)+4)).
               setCellValue(this.getAverageValue(this.sheetRowsUnderOperation.get(i), 4, numberOfRepeats));
        }
    }

    private double getAverageValue(Row row, int index, int numberOfRepeats) 
    {
        double cummulation = 0;

        for (int i = 0; i < numberOfRepeats; i++) 
        {
            cummulation = cummulation + (row.getCell(index + (i * this.numberOfCeilsJumping)).getNumericCellValue());
        }

        return cummulation / numberOfRepeats;
    }
    
    
    public void close() throws IOException 
    { 
        this.workbook.write(this.fileOutputStream);
        this.fileOutputStream.close();
    }

    
}
