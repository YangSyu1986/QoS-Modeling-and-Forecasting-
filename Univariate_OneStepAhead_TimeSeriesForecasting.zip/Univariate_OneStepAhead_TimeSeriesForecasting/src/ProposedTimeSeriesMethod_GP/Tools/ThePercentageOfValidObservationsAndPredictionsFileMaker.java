package ProposedTimeSeriesMethod_GP.Tools;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import Utilities.ForecastingAccuracyMeasures.DiverseErrorsOfASegment;

public class ThePercentageOfValidObservationsAndPredictionsFileMaker
{
	String pathAndFileName;
    FileOutputStream fileOutputStream;
    Workbook workbook;
    Sheet sheetUnderOperation;
   
    
    public ThePercentageOfValidObservationsAndPredictionsFileMaker(String filePath, String fileName) throws FileNotFoundException 
    {
       this.pathAndFileName=filePath + "/" + fileName;
       this.fileOutputStream = new FileOutputStream(this.pathAndFileName+".xlsx");
    }
    
    public void createFile(DiverseErrorsOfASegment[][][] diverseErrorsOfASegment_withRepeats) throws IOException
    {
       this.workbook = new XSSFWorkbook(); 	
    	
       for(int i = 0;i < diverseErrorsOfASegment_withRepeats.length;i++)
       {
    	   for(int j = 0;j < diverseErrorsOfASegment_withRepeats[i].length;j++)
    	   {
    		   this.sheetUnderOperation = this.workbook.createSheet("TS. "+i+" Seg."+j); 
    		   this.sheetUnderOperation.setDefaultColumnWidth(18);
    		   
    		   this.createSheet(diverseErrorsOfASegment_withRepeats[i][j]);
    	   }
       }
       
       this.workbook.write(this.fileOutputStream);
       this.fileOutputStream.close();	
    }
    
    private void createSheet(DiverseErrorsOfASegment[] repeats)
    {
    	Row firstRow = this.sheetUnderOperation.createRow(0);
    	Row secondRow = this.sheetUnderOperation.createRow(1);
    	Row thirdRow = this.sheetUnderOperation.createRow(2);
    	Row fourthRow = this.sheetUnderOperation.createRow(3);
    	Row fifthRow = this.sheetUnderOperation.createRow(4);
    	
    	firstRow.createCell(0).setCellValue("");
    	secondRow.createCell(0).setCellValue("Perc. Vali. Trai. Obse.");
    	thirdRow.createCell(0).setCellValue("Perc. Vali. Trai. Pred.");
    	fourthRow.createCell(0).setCellValue("Perc. Vali. Test. Obse.");
    	fifthRow.createCell(0).setCellValue("Perc. Vali. Test. Pred.");
    	
    	
    	double[] averages = {0,0,0,0};
    	
    	for(int i = 0;i<repeats.length;i++)
    	{
    		firstRow.createCell(i+1).setCellValue("Repeat "+i);
    		
        	secondRow.createCell(i+1).setCellValue(repeats[i].getPercentageOfValidTrainingObservations());
        	averages[0] = averages[0] + repeats[i].getPercentageOfValidTrainingObservations();
        	
        	thirdRow.createCell(i+1).setCellValue(repeats[i].getPercentageOfValidTrainingPredictions());
        	averages[1] = averages[1] + repeats[i].getPercentageOfValidTrainingPredictions();
        	
        	fourthRow.createCell(i+1).setCellValue(repeats[i].getPercentageOfValidTestingObservations());
        	averages[2] = averages[2] + repeats[i].getPercentageOfValidTestingObservations();
        	
        	fifthRow.createCell(i+1).setCellValue(repeats[i].getPercentageOfValidTestingPredictions());
        	averages[3] = averages[3] + repeats[i].getPercentageOfValidTestingPredictions();
    	}
    	
    	
    	firstRow.createCell(repeats.length + 1).setCellValue("Average");
    	secondRow.createCell(repeats.length + 1).setCellValue(averages[0] / repeats.length);
    	thirdRow.createCell(repeats.length + 1).setCellValue(averages[1] / repeats.length);
    	fourthRow.createCell(repeats.length + 1).setCellValue(averages[2] / repeats.length);
    	fifthRow.createCell(repeats.length + 1).setCellValue(averages[3] / repeats.length);
    }
}
