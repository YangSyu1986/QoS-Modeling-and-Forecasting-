package ProposedTimeSeriesMethod_GP.Tools;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;

import Utilities.DataStructures.ForecastingOutcomeOfASegment;
import Utilities.ForecastingAccuracyMeasures.DiverseErrorsOfASegment;
import Utilities.ForecastingAccuracyMeasures.DiverseMeasuringResultsOfASegment;
import Utilities.ForecastingCostMeasures.TimeCost;

public class ForecastingOutcomesProcessor 
{
	//for GP method to use, because there are multiple repeats in a segment
	public static List<ForecastingOutcomeOfASegment[][]> generateForecastingOutcomeOfASegment(ForecastingOutcomeOfASegment[][][] forecastingOutcomeOfASegment_withRepeats)
	{
		List<ForecastingOutcomeOfASegment[][]> results = new ArrayList<ForecastingOutcomeOfASegment[][]>();
		
		for(int k = 0; k < forecastingOutcomeOfASegment_withRepeats[0][0].length; k++)//different repeats
		{
		  ForecastingOutcomeOfASegment[][] result = new ForecastingOutcomeOfASegment[forecastingOutcomeOfASegment_withRepeats.length][forecastingOutcomeOfASegment_withRepeats[0].length]; 	
			
		  for(int i = 0; i < forecastingOutcomeOfASegment_withRepeats.length; i++)
		  {
			 for(int j = 0; j < forecastingOutcomeOfASegment_withRepeats[0].length; j++)
			 {
				result[i][j] = forecastingOutcomeOfASegment_withRepeats[i][j][k];		
			 }
		  }
		  
		  results.add(result);
	    }
		
		return results;
	}
	
	
    //for GP method to use, because there are multiple repeats in a segment
	public static DiverseErrorsOfASegment[][][] generateDiverseErrorsOfASegment_Repeats(ForecastingOutcomeOfASegment[][][] forecastingOutcomeOfASegmentWithRepeats)
	{
		DiverseErrorsOfASegment[][][] results = new DiverseErrorsOfASegment[forecastingOutcomeOfASegmentWithRepeats.length][][];
		
		for(int i = 0;i<results.length;i++)
		{
		  results[i] = new DiverseErrorsOfASegment[forecastingOutcomeOfASegmentWithRepeats[i].length][];	
			
		  for(int j = 0;j<results[i].length;j++)
		  {
			results[i][j] = new DiverseErrorsOfASegment[forecastingOutcomeOfASegmentWithRepeats[i][j].length];	  
			  
			for(int k = 0;k<results[i][j].length;k++)
			{
			  results[i][j][k] = new DiverseErrorsOfASegment(forecastingOutcomeOfASegmentWithRepeats[i][j][k]);	 
			}
		  }	
		}
		
		return results;
	}
	
	
	public static DiverseErrorsOfASegment[][] generateDiverseErrorsOfASegment(ForecastingOutcomeOfASegment[][] forecastingOutcomeOfASegment)
	{
		DiverseErrorsOfASegment[][] results = new DiverseErrorsOfASegment[forecastingOutcomeOfASegment.length][];
		
		for(int i = 0;i<results.length;i++)
		{
		  results[i] = new DiverseErrorsOfASegment[forecastingOutcomeOfASegment[i].length];	
			
		  for(int j = 0;j<results[i].length;j++)
		  { 
			results[i][j] = new DiverseErrorsOfASegment(forecastingOutcomeOfASegment[i][j]);	  
		  }	
		}
		
		return results;
	}
	
	
	
	//for GP method to use, because there are multiple repeats in a segment
	public static DiverseErrorsOfASegment[][] generateAverageDiverseErrorsOfASegment(DiverseErrorsOfASegment[][][] diverseErrorsOfASegment_withRepeats) throws NoSuchMethodException, SecurityException, IllegalAccessException, IllegalArgumentException, InvocationTargetException
	{
		DiverseErrorsOfASegment[][] results = new DiverseErrorsOfASegment[diverseErrorsOfASegment_withRepeats.length][]; 
		
		for(int i = 0;i<results.length;i++)
		{
			results[i] = new DiverseErrorsOfASegment[diverseErrorsOfASegment_withRepeats[i].length]; 
			
			for(int j = 0;j<results[i].length;j++)
			{
		      double[] trainingAbsoluteErrors = calculateAverageErrors(diverseErrorsOfASegment_withRepeats[i][j], "TrainingAbsoluteErrors");
		      double[] testingAbsoluteErrors = calculateAverageErrors(diverseErrorsOfASegment_withRepeats[i][j], "TestingAbsoluteErrors");
		
		      double[] trainingSquaredErrors = calculateAverageErrors(diverseErrorsOfASegment_withRepeats[i][j], "TrainingSquaredErrors");
		      double[] testingSquaredErrors = calculateAverageErrors(diverseErrorsOfASegment_withRepeats[i][j], "TestingSquaredErrors");
		
		      double[] trainingAbsolutePercentageErrors = calculateAverageErrors(diverseErrorsOfASegment_withRepeats[i][j], "TrainingAbsolutePercentageErrors");
		      double[] testingAbsolutePercentageErrors = calculateAverageErrors(diverseErrorsOfASegment_withRepeats[i][j], "TestingAbsolutePercentageErrors");
		
		      double[] trainingSquaredPercentageErrors = calculateAverageErrors(diverseErrorsOfASegment_withRepeats[i][j], "TrainingSquaredPercentageErrors");
		      double[] testingSquaredPercentageErrors = calculateAverageErrors(diverseErrorsOfASegment_withRepeats[i][j], "TestingSquaredPercentageErrors");
		
		      double[] trainingSymmetricAbsolutePercentageErrors = calculateAverageErrors(diverseErrorsOfASegment_withRepeats[i][j], "TrainingSymmetricAbsolutePercentageErrors");
		      double[] testingSymmetricAbsolutePercentageErrors = calculateAverageErrors(diverseErrorsOfASegment_withRepeats[i][j], "TestingSymmetricAbsolutePercentageErrors");
		
		      double[] trainingAbsoluteRelativeErrors = calculateAverageErrors(diverseErrorsOfASegment_withRepeats[i][j], "TrainingAbsoluteRelativeErrors");
		      double[] testingAbsoluteRelativeErrors = calculateAverageErrors(diverseErrorsOfASegment_withRepeats[i][j], "TestingAbsoluteRelativeErrors");
		
		      double[] trainingAbsoluteScaledErrors = calculateAverageErrors(diverseErrorsOfASegment_withRepeats[i][j], "TrainingAbsoluteScaledErrors");
		      double[] testingAbsoluteScaledErrors = calculateAverageErrors(diverseErrorsOfASegment_withRepeats[i][j], "TestingAbsoluteScaledErrors");
		
		      double[] trainingSquaredScaledErrors = calculateAverageErrors(diverseErrorsOfASegment_withRepeats[i][j], "TrainingSquaredScaledErrors");
		      double[] testingSquaredScaledErrors = calculateAverageErrors(diverseErrorsOfASegment_withRepeats[i][j], "TestingSquaredScaledErrors");
		      
		      results[i][j] = new DiverseErrorsOfASegment(diverseErrorsOfASegment_withRepeats[i][j][0].getExperimentNumber(),
		    		                                      trainingAbsoluteErrors, testingAbsoluteErrors,
                                                          trainingSquaredErrors, testingSquaredErrors,
                                                          trainingAbsolutePercentageErrors, testingAbsolutePercentageErrors,
                                                          trainingSquaredPercentageErrors, testingSquaredPercentageErrors,
                                                          trainingSymmetricAbsolutePercentageErrors, testingSymmetricAbsolutePercentageErrors,
                                                          trainingAbsoluteRelativeErrors, testingAbsoluteRelativeErrors,
                                                          trainingAbsoluteScaledErrors, testingAbsoluteScaledErrors,
                                                          trainingSquaredScaledErrors, testingSquaredScaledErrors
		    		                                     );
			}
		}

		return results;
	}
 	
	private static double[] calculateAverageErrors(DiverseErrorsOfASegment[] repeats, String errorName) throws NoSuchMethodException, SecurityException, IllegalAccessException, IllegalArgumentException, InvocationTargetException
	{
		Method method = repeats[0].getClass().getMethod("get"+errorName, null);
		double[] averages = new double[((double[]) method.invoke(repeats[0], null)).length];
		
		double accumulation = 0;
		
		for(int i=0;i<averages.length;i++)
		{
			accumulation = 0;
			
			for(int j=0;j<repeats.length;j++)
			{
				accumulation = accumulation + ((double[]) method.invoke(repeats[j], null))[i];
			}
			
			averages[i] = accumulation / repeats.length;
		}
			
		return averages;
	}
	
	
	//for GP method to use, because there are multiple repeats in a segment
	public static DiverseMeasuringResultsOfASegment[][][] generateDiverseMeasuringResultsOfASegment_Repeats(DiverseErrorsOfASegment[][][] diverseErrorsOfASegmentWithRepeats)
	{
    	DiverseMeasuringResultsOfASegment[][][] results = new DiverseMeasuringResultsOfASegment[diverseErrorsOfASegmentWithRepeats.length][][];
			
	    for(int i = 0;i<results.length;i++)
		{
		   results[i] = new DiverseMeasuringResultsOfASegment[diverseErrorsOfASegmentWithRepeats[i].length][];	
				
		   for(int j = 0;j<results[i].length;j++)
		   {
			 results[i][j] = new DiverseMeasuringResultsOfASegment[diverseErrorsOfASegmentWithRepeats[i][j].length];
			 
			 for(int k=0;k<results[i][j].length;k++)
			 {
			   results[i][j][k] = new DiverseMeasuringResultsOfASegment(diverseErrorsOfASegmentWithRepeats[i][j][k]);
			 }
		   }	
		}
			
		return results;
	}	
	
	
	public static DiverseMeasuringResultsOfASegment[][] generateDiverseMeasuringResultsOfASegment(DiverseErrorsOfASegment[][] diverseErrorsOfASegment)
	{
    	DiverseMeasuringResultsOfASegment[][] results = new DiverseMeasuringResultsOfASegment[diverseErrorsOfASegment.length][];
			
	    for(int i = 0;i<results.length;i++)
		{
		   results[i] = new DiverseMeasuringResultsOfASegment[diverseErrorsOfASegment[i].length];	
				
		   for(int j = 0;j<results[i].length;j++)
		   {
			 results[i][j] = new DiverseMeasuringResultsOfASegment(diverseErrorsOfASegment[i][j]);
		   }	
		}
			
		return results;
	}	
	
	
	
	//used for GP (multiple repetitions for a segment)
	public static DiverseMeasuringResultsOfASegment[][] generateAverageDiverseMeasuringResultsOfASegment(DiverseMeasuringResultsOfASegment[][][] diverseMeasuringResultsOfASegmentWithRepeats) throws NoSuchMethodException, SecurityException, IllegalAccessException, IllegalArgumentException, InvocationTargetException
	{
		DiverseMeasuringResultsOfASegment[][] results = new DiverseMeasuringResultsOfASegment[diverseMeasuringResultsOfASegmentWithRepeats.length][]; 
		
		for(int i = 0;i<results.length;i++)
		{
			results[i] = new DiverseMeasuringResultsOfASegment[diverseMeasuringResultsOfASegmentWithRepeats[i].length]; 
		
			for(int j = 0;j<results[i].length;j++)
			{
			  results[i][j] = new DiverseMeasuringResultsOfASegment
				              (diverseMeasuringResultsOfASegmentWithRepeats[i][j][0].getExperimentNumber(),
				               calculateAverage(diverseMeasuringResultsOfASegmentWithRepeats[i][j], "TrainingMeanAbsoluteError"), calculateAverage(diverseMeasuringResultsOfASegmentWithRepeats[i][j], "TestingMeanAbsoluteError"),
				               calculateAverage(diverseMeasuringResultsOfASegmentWithRepeats[i][j], "TrainingGeometricMeanAbsoluteError"), calculateAverage(diverseMeasuringResultsOfASegmentWithRepeats[i][j], "TestingGeometricMeanAbsoluteError"),
				               calculateAverage(diverseMeasuringResultsOfASegmentWithRepeats[i][j], "TrainingMedianAbsoluteError"), calculateAverage(diverseMeasuringResultsOfASegmentWithRepeats[i][j], "TestingMedianAbsoluteError"),
				               calculateAverage(diverseMeasuringResultsOfASegmentWithRepeats[i][j], "TrainingMeanSquaredError"), calculateAverage(diverseMeasuringResultsOfASegmentWithRepeats[i][j], "TestingMeanSquaredError"),
				               calculateAverage(diverseMeasuringResultsOfASegmentWithRepeats[i][j], "TrainingRootMeanSquaredError"), calculateAverage(diverseMeasuringResultsOfASegmentWithRepeats[i][j], "TestingRootMeanSquaredError"),
				               calculateAverage(diverseMeasuringResultsOfASegmentWithRepeats[i][j], "TrainingMeanAbsolutePercentageError"), calculateAverage(diverseMeasuringResultsOfASegmentWithRepeats[i][j], "TestingMeanAbsolutePercentageError"),
				               calculateAverage(diverseMeasuringResultsOfASegmentWithRepeats[i][j], "TrainingMedianAbsolutePercentageError"), calculateAverage(diverseMeasuringResultsOfASegmentWithRepeats[i][j], "TestingMedianAbsolutePercentageError"),
				               calculateAverage(diverseMeasuringResultsOfASegmentWithRepeats[i][j], "TrainingRootMeanSquaredPercentageError"), calculateAverage(diverseMeasuringResultsOfASegmentWithRepeats[i][j], "TestingRootMeanSquaredPercentageError"),
				               calculateAverage(diverseMeasuringResultsOfASegmentWithRepeats[i][j], "TrainingRootMedianSquaredPercentageError"), calculateAverage(diverseMeasuringResultsOfASegmentWithRepeats[i][j], "TestingRootMedianSquaredPercentageError"),
				               calculateAverage(diverseMeasuringResultsOfASegmentWithRepeats[i][j], "TrainingSymmetricMeanAbsolutePercentageError"), calculateAverage(diverseMeasuringResultsOfASegmentWithRepeats[i][j], "TestingSymmetricMeanAbsolutePercentageError"),
				               calculateAverage(diverseMeasuringResultsOfASegmentWithRepeats[i][j], "TrainingSymmetricMedianAbsolutePercentageError"), calculateAverage(diverseMeasuringResultsOfASegmentWithRepeats[i][j], "TestingSymmetricMedianAbsolutePercentageError"),
				               calculateAverage(diverseMeasuringResultsOfASegmentWithRepeats[i][j], "TrainingMeanRelativeAbsoluteError"), calculateAverage(diverseMeasuringResultsOfASegmentWithRepeats[i][j], "TestingMeanRelativeAbsoluteError"),
				               calculateAverage(diverseMeasuringResultsOfASegmentWithRepeats[i][j], "TrainingMedianRelativeAbsoluteError"), calculateAverage(diverseMeasuringResultsOfASegmentWithRepeats[i][j], "TestingMedianRelativeAbsoluteError"),
				               calculateAverage(diverseMeasuringResultsOfASegmentWithRepeats[i][j], "TrainingGeometricMeanRelativeAbsoluteError"), calculateAverage(diverseMeasuringResultsOfASegmentWithRepeats[i][j], "TestingGeometricMeanRelativeAbsoluteError"),
				               calculateAverage(diverseMeasuringResultsOfASegmentWithRepeats[i][j], "TrainingMeanAbsoluteScaledError"), calculateAverage(diverseMeasuringResultsOfASegmentWithRepeats[i][j], "TestingMeanAbsoluteScaledError"),
				               calculateAverage(diverseMeasuringResultsOfASegmentWithRepeats[i][j], "TrainingRootMeanSquaredScaledError"), calculateAverage(diverseMeasuringResultsOfASegmentWithRepeats[i][j], "TestingRootMeanSquaredScaledError"),
				               calculateAverage(diverseMeasuringResultsOfASegmentWithRepeats[i][j], "TrainingMedianAbsoluteScaledError"), calculateAverage(diverseMeasuringResultsOfASegmentWithRepeats[i][j], "TestingMedianAbsoluteScaledError")
				              );	
			}
		}
   
		return results;
	}
	
	private static double calculateAverage(DiverseMeasuringResultsOfASegment[] repeats, String measureName)throws NoSuchMethodException, SecurityException, IllegalAccessException, IllegalArgumentException, InvocationTargetException
	{
		double average = 0;
		
		for(int i = 0;i<repeats.length;i++)
		{
			Method method = repeats[i].getClass().getMethod("get"+measureName, null);
			average = average + ((double) method.invoke(repeats[i], null));	
		}
		
		return average / repeats.length;
	}
	
	
	
	//for GP method to use, because there are multiple repeats in a segment
	public static TimeCost[][][] generateDiverseTimeCostOfASegment_Repeats(ForecastingOutcomeOfASegment[][][] forecastingOutcomeOfASegmentWithRepeats)
	{
	    TimeCost[][][] results = new TimeCost[forecastingOutcomeOfASegmentWithRepeats.length][][];
			
		for(int i = 0;i<results.length;i++)
		{
			results[i] = new TimeCost[forecastingOutcomeOfASegmentWithRepeats[i].length][];	
				
			for(int j = 0;j<results[i].length;j++)
			{
			   results[i][j] = new TimeCost[forecastingOutcomeOfASegmentWithRepeats[i][j].length];	  
				  
			   for(int k = 0;k<results[i][j].length;k++)
			   {
				  results[i][j][k] = new TimeCost(forecastingOutcomeOfASegmentWithRepeats[i][j][k].getExperimentNumber(), forecastingOutcomeOfASegmentWithRepeats[i][j][k].getPredictorProductionTime(), forecastingOutcomeOfASegmentWithRepeats[i][j][k].getTrainingForecastsProductionTime(), forecastingOutcomeOfASegmentWithRepeats[i][j][k].getTestingForecastsProductionTime());	 
			   }
			 }	
		}
			
		return results;
	}
	
	public static TimeCost[][] generateAverageDiverseTimeCostOfASegment(TimeCost[][][] timeCostOfASegmentWithRepeats) throws NoSuchMethodException, SecurityException, IllegalAccessException, IllegalArgumentException, InvocationTargetException
	{
		TimeCost[][] results = new TimeCost[timeCostOfASegmentWithRepeats.length][];
		
		for(int i = 0;i<results.length;i++)
		{
		   results[i] = new TimeCost[timeCostOfASegmentWithRepeats[i].length];
			
		   for(int j = 0;j<results[i].length;j++)
		   {
			  results[i][j] = new TimeCost(timeCostOfASegmentWithRepeats[i][j][0].getExperimentNumber(),calculateAverageTimeCost(timeCostOfASegmentWithRepeats[i][j], "PredictorProductionTime"), calculateAverageTimeCost(timeCostOfASegmentWithRepeats[i][j], "TrainingForecastsProductionTime"), calculateAverageTimeCost(timeCostOfASegmentWithRepeats[i][j], "TestingForecastsProductionTime"));
		   }
		}
		
		return results;
	}
	
	private static double calculateAverageTimeCost(TimeCost[] repeats, String timeCostName) throws NoSuchMethodException, SecurityException, IllegalAccessException, IllegalArgumentException, InvocationTargetException
	{
		double average = 0;
		
		for(int i = 0;i<repeats.length;i++)
		{
			Method method = repeats[i].getClass().getMethod("get" + timeCostName, null);
			average = average + ((double) method.invoke(repeats[i], null));		
		}
		
		return average / repeats.length;
	}
	
	
	public static TimeCost[][] generateDiverseTimeCostOfASegment(ForecastingOutcomeOfASegment[][] forecastingOutcomeOfASegment)
	{
	    TimeCost[][] results = new TimeCost[forecastingOutcomeOfASegment.length][];
			
		for(int i = 0;i<results.length;i++)
		{
			results[i] = new TimeCost[forecastingOutcomeOfASegment[i].length];	
				
			for(int j = 0;j<results[i].length;j++)
			{
			   results[i][j] = new TimeCost(forecastingOutcomeOfASegment[i][j].getExperimentNumber(), forecastingOutcomeOfASegment[i][j].getPredictorProductionTime(), forecastingOutcomeOfASegment[i][j].getTrainingForecastsProductionTime(), forecastingOutcomeOfASegment[i][j].getTestingForecastsProductionTime());
			}	
		}
			
		return results;
	}
	
	
	
	public static void performFinalProcessing(ForecastingOutcomeOfASegment[][][] forecastingOutcomeOfASegment_withRepeats,
			
			                                  List<ForecastingOutcomeOfASegment[][]> outcomeOfDiverseMethods_ForecastingOutcomes,
			                                  List<DiverseErrorsOfASegment[][]> outcomeOfDiverseMethods_DiverseErrors,
			                                  List<DiverseMeasuringResultsOfASegment[][]> outcomeOfDiverseMethods_AccuracyMeasures,
			                                  List<TimeCost[][]> outcomeOfDiverseMethods_TimeCosts 
			                                 ) throws NoSuchMethodException, SecurityException, IllegalAccessException, IllegalArgumentException, InvocationTargetException
	{
		List<ForecastingOutcomeOfASegment[][]> forecastingOutcomeOfASegment = ForecastingOutcomesProcessor.generateForecastingOutcomeOfASegment(forecastingOutcomeOfASegment_withRepeats);
	    outcomeOfDiverseMethods_ForecastingOutcomes.addAll(forecastingOutcomeOfASegment);	
	      
	        //time series, segments, repeats (diverse errors)
	    DiverseErrorsOfASegment[][][] diverseErrorsOfASegment_withRepeats = ForecastingOutcomesProcessor.generateDiverseErrorsOfASegment_Repeats(forecastingOutcomeOfASegment_withRepeats);
	    
// new ThePercentageOfValidObservationsAndPredictionsFileMaker(proposedMethodDirectory,"Percentage Of Valid Values").createFile(diverseErrorsOfASegment_withRepeats);
	     
	   //may cause problem //time series, segments (diverse (average) errors)
	    DiverseErrorsOfASegment[][]  diverseAverageErrorsOfASegment = ForecastingOutcomesProcessor.generateAverageDiverseErrorsOfASegment(diverseErrorsOfASegment_withRepeats); 
	    outcomeOfDiverseMethods_DiverseErrors.add(diverseAverageErrorsOfASegment); 
	    
	        //time series, segments, repeats (diverse measuring results)
	    DiverseMeasuringResultsOfASegment[][][] diverseMeasuringResultsOfASegment_withRepeats = ForecastingOutcomesProcessor.generateDiverseMeasuringResultsOfASegment_Repeats(diverseErrorsOfASegment_withRepeats);
	    
	    //time series, segments (diverse (average) measuring results)
	    DiverseMeasuringResultsOfASegment[][] diverseMeasuringResultsOfASegment = ForecastingOutcomesProcessor.generateAverageDiverseMeasuringResultsOfASegment(diverseMeasuringResultsOfASegment_withRepeats);
	    outcomeOfDiverseMethods_AccuracyMeasures.add(diverseMeasuringResultsOfASegment);
	    
	         //time series, segments, repeats (two time costs)
	    TimeCost[][][]  timeCostOfASegment_withRepeats = ForecastingOutcomesProcessor.generateDiverseTimeCostOfASegment_Repeats(forecastingOutcomeOfASegment_withRepeats);
	  
	    //time series, segments (two time costs)
	    TimeCost[][]  timeCostOfASegment = ForecastingOutcomesProcessor.generateAverageDiverseTimeCostOfASegment(timeCostOfASegment_withRepeats);
	    outcomeOfDiverseMethods_TimeCosts.add(timeCostOfASegment); 
	    
	    
	    forecastingOutcomeOfASegment_withRepeats = null;//release memory
	}
}
