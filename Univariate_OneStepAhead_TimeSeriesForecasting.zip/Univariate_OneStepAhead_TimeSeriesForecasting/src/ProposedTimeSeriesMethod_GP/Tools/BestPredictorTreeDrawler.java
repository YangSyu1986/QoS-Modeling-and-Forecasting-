package ProposedTimeSeriesMethod_GP.Tools;

import java.io.File;

import org.jgap.InvalidConfigurationException;
import org.jgap.gp.IGPProgram;

import ProposedTimeSeriesMethod_GP.prediction.GPPredictionConfiguration;

public class BestPredictorTreeDrawler 
{
  static String rootPath;
  
  public static void setRootPath(String rootPath)
  {  
	  BestPredictorTreeDrawler.rootPath = rootPath + "/BestPredictorTrees";
	  
	  (new File(BestPredictorTreeDrawler.rootPath)).mkdir();
  }
  
  
  public static void drawTreeAndSaveIntoFile(int TSNumber, int segmentNumer, int repeatNumber, String GPName, 
		                                     GPPredictionConfiguration configuration, IGPProgram best) throws InvalidConfigurationException
  {
	  String path = BestPredictorTreeDrawler.rootPath  + "/" + "TS_" + TSNumber + "_Seg_" + segmentNumer; 
	  (new File(path)).mkdir();
  
	  configuration.showTree(best, path + "/" + GPName + "_Repeat_" + repeatNumber + ".png" );
	  
  }
}
