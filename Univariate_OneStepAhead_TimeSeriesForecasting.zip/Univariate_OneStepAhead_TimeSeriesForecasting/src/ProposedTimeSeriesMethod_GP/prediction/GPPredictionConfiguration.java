/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package ProposedTimeSeriesMethod_GP.prediction;

import java.util.ArrayList;
import java.util.List;
import org.jgap.InvalidConfigurationException;
import org.jgap.gp.CommandGene;
import org.jgap.gp.GPFitnessFunction;
import org.jgap.gp.GPProblem;
import org.jgap.gp.IGPInitStrategy;
import org.jgap.gp.IGPProgram;
import org.jgap.gp.function.Abs;
import org.jgap.gp.function.Ceil;
import org.jgap.gp.function.Cosine;
import org.jgap.gp.function.Exp;
import org.jgap.gp.function.Floor;
import org.jgap.gp.function.Log;
import org.jgap.gp.function.Max;
import org.jgap.gp.function.Min;
import org.jgap.gp.function.Modulo;
import org.jgap.gp.function.Pow;
import org.jgap.gp.function.Round;
import org.jgap.gp.function.Sine;
import org.jgap.gp.function.Tangent;
import org.jgap.gp.function.statistics.Kurtosis;
import org.jgap.gp.function.statistics.Mean;
import org.jgap.gp.function.statistics.Skewness;
import org.jgap.gp.function.statistics.StandardDeviation;
import org.jgap.gp.function.statistics.Variance;
import org.jgap.gp.impl.DeltaGPFitnessEvaluator;
import org.jgap.gp.impl.GPConfiguration;
import org.jgap.gp.impl.GPGenotype;
import org.jgap.gp.terminal.Terminal;
import org.jgap.gp.terminal.Variable;

import ProposedTimeSeriesMethod_GP.FitnessFunctions.FitnessFunctionBasis;
import ProposedTimeSeriesMethod_GP.FitnessFunctions.FitnessFunction_MAE;
import ProposedTimeSeriesMethod_GP.Setting.DiverseSetting;
import ProposedTimeSeriesMethod_GP.prediction.modifiedFunctions.ModifiedAdd;
import ProposedTimeSeriesMethod_GP.prediction.modifiedFunctions.ModifiedDivide;
import ProposedTimeSeriesMethod_GP.prediction.modifiedFunctions.ModifiedMultiply;
import ProposedTimeSeriesMethod_GP.prediction.modifiedFunctions.ModifiedSubtract;
/**
 *
 * @author YangSyu
 */
public class GPPredictionConfiguration  extends GPProblem
{
    GPConfiguration config;//jgap configuration
      
    List<Variable>  variables;//jgap variables (terminal set)
    List<CommandGene> commands;//for containing all of the allowed commands (terminal and function sets)
   
    
    DiverseSetting GPSetting;
    
    
    public GPPredictionConfiguration(DiverseSetting GPSetting) throws InvalidConfigurationException
    {
    	  this.config = new GPConfiguration();
          this.setGPConfiguration(this.config);
          
          this.variables = new ArrayList<Variable>();
          this.commands = new ArrayList<CommandGene>();
          
          this.config.setGPFitnessEvaluator(new DeltaGPFitnessEvaluator());//for the situation that less value is better 
          this.config.setStrictProgramCreation(true);
          //the above statements are all official to enable JGAP runnable
          
          this.GPSetting = GPSetting;
          
          this.setGPParameters(this.GPSetting);
          this.setNumberOfPreviousTimePointsAllowedToUse(this.GPSetting);
          this.setConstants(this.GPSetting);
          this.setFunctionSet(this.GPSetting);
    }
    
    
    private void setGPParameters(DiverseSetting GPSetting) throws InvalidConfigurationException
    {
      this.config.setPopulationSize(this.GPSetting.getNumberOfChromosomesInAPopulation());
      this.config.setCrossoverProb(this.GPSetting.getCrossoverProbability());
      this.config.setMutationProb(this.GPSetting.getMutationProbability());
      this.config.setNewChromsPercent(this.GPSetting.getNewChromosomesInAPopulationProbability());
    }
     
    private void setNumberOfPreviousTimePointsAllowedToUse(DiverseSetting GPSetting) throws InvalidConfigurationException
    {
      for(int i=0;i<this.GPSetting.getNumberOfPreviousTimePointsAllowedToUse();i++)
      {
         this.variables.add(Variable.create(this.config, "Yt-"+(i+1), CommandGene.FloatClass ));
      
         commands.add(this.variables.get(i));
      }
      
    } 
    
    private void setConstants(DiverseSetting GPSetting) throws InvalidConfigurationException
    {
      for(int i=0;i<this.GPSetting.getRoundsOfConstantGeneration();i++)
      {
        for(int j=0;j<=this.GPSetting.getPowerUpperBound();j++)  
        {
         this.commands.add
          (new Terminal(this.config, CommandGene.FloatClass ,-(Math.pow(10, j)),Math.pow(10, j), false));
        }
      } 
    }
    
    private void setFunctionSet(DiverseSetting GPSetting) throws InvalidConfigurationException
    {  
      String notationOfAllowedOperators	= GPSetting.getFunctionSet();
    	
       //binary operators
      if(notationOfAllowedOperators.contains("+"))
      {this.commands.add(new ModifiedAdd(this.config,CommandGene.FloatClass ));}
      
      if(notationOfAllowedOperators.contains("-"))
      {this.commands.add(new ModifiedSubtract(this.config,CommandGene.FloatClass ));}
      
      if(notationOfAllowedOperators.contains("*"))
      {this.commands.add(new ModifiedMultiply(this.config,CommandGene.FloatClass ));}
      
      if(notationOfAllowedOperators.contains("/"))
      {this.commands.add(new ModifiedDivide(this.config,CommandGene.FloatClass ));}
      
      if(notationOfAllowedOperators.contains("max"))
      {this.commands.add(new Max(this.config,CommandGene.FloatClass ));}
      
      if(notationOfAllowedOperators.contains("min"))
      {this.commands.add(new Min(this.config,CommandGene.FloatClass ));}
      
      if(notationOfAllowedOperators.contains("mod"))
      {this.commands.add(new Modulo(this.config,CommandGene.FloatClass ));}
      
      if(notationOfAllowedOperators.contains("pow"))
      {this.commands.add(new Pow(this.config,CommandGene.FloatClass ));}
        
        //unary operators
      if(notationOfAllowedOperators.contains("sine"))
      {this.commands.add(new Sine(this.config,CommandGene.FloatClass ));}
      
      if(notationOfAllowedOperators.contains("cosine"))
      {this.commands.add(new Cosine(this.config,CommandGene.FloatClass ));}
      
      if(notationOfAllowedOperators.contains("tangent"))
      {this.commands.add(new Tangent(this.config,CommandGene.FloatClass ));}
      
      if(notationOfAllowedOperators.contains("abs"))
      {this.commands.add(new Abs(this.config,CommandGene.FloatClass ));}
      
      if(notationOfAllowedOperators.contains("floor"))
      {this.commands.add(new Floor(this.config,CommandGene.FloatClass ));}
      
      if(notationOfAllowedOperators.contains("ceil"))
      {this.commands.add(new Ceil(this.config,CommandGene.FloatClass ));}
      
      if(notationOfAllowedOperators.contains("log"))
      {this.commands.add(new Log(this.config,CommandGene.FloatClass ));}
      
      if(notationOfAllowedOperators.contains("exp"))
      {this.commands.add(new Exp(this.config,CommandGene.FloatClass ));}
        
      if(notationOfAllowedOperators.contains("round"))
      {this.commands.add(new Round(this.config,CommandGene.FloatClass ));}
    }
    
    
    public void setFitnessFunction(GPFitnessFunction fitnessfunction) throws InvalidConfigurationException
    {     
       this.config.setFitnessFunction(fitnessfunction);
    }
    
    @Override
    public GPGenotype create() throws InvalidConfigurationException 
    {
        Class[] rootReturnTypes = { CommandGene.FloatClass };

        Class[][] argTypes = {{}};
     
         
           CommandGene[] forCast=new CommandGene[this.commands.size()];//for casting
           for(int i=0;i<this.commands.size();i++)
           {
             forCast[i]=this.commands.get(i);
           }
        
          
           CommandGene[][] nodeSet={forCast};//all of the allowed mathmatical notations to be presented and included in evolved predictors 
           int[] minD={this.GPSetting.getMinDepth()}; int[] maxD={this.GPSetting.getMaxDepth()};boolean[] fullmode={true};
        
        
        return GPGenotype.randomInitialGenotype
               (this.config, 
                rootReturnTypes, argTypes, 
                nodeSet,
                minD, maxD, this.GPSetting.getLimitationOfNodesInAChromosome(),fullmode,
                false);
    }

    
    public List<Variable> getVariables() 
    {
        return this.variables;
    }

    public DiverseSetting getDiverseSetting()
    {
    	return this.GPSetting;
    }
}

