/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package ProposedTimeSeriesMethod_GP.prediction;

import java.io.IOException;
import java.lang.management.ManagementFactory;
import java.lang.management.ThreadMXBean;
import java.util.List;
import java.util.Random;
import org.jgap.Configuration;
import org.jgap.InvalidConfigurationException;
import org.jgap.gp.IGPProgram;
import org.jgap.gp.impl.GPGenotype;
import org.jgap.gp.impl.GPPopulation;

import ProposedTimeSeriesMethod_GP.FitnessFunctions.FitnessFunctionBasis;

import ProposedTimeSeriesMethod_GP.Setting.GPEvaluationSetting;
import ProposedTimeSeriesMethod_GP.Tools.BestPredictorTreeDrawler;
import ProposedTimeSeriesMethod_GP.Tools.ExcelMaker;
import Utilities.CommonSetting.TimeSeriesIntervalsIndicesSet;
import Utilities.DataStructures.ForecastingOutcomeOfASegment;
import Utilities.DatasetProcessingModules.ObservationsAtOneTimePoint;
import Utilities.ForecastingCostMeasures.TimeCost;

/**
 *
 * @author YangSyu
 */
public class PredictionExperiments
{
  String name;	
	
  GPPredictionConfiguration configuration;
  
  List<List<ObservationsAtOneTimePoint>> timeseries;
  
  int[][][] trainingDataIntervalsIndicesSet;
  int[][][] validatingDataIntervalsIndicesSet; 
  int[][][] testingDataIntervalsIndicesSet;
  
  GPEvaluationSetting gpEvaluationSetting;
  
  ExcelMaker excelMakerForBestPredictor;
  ExcelMaker excelMakerForBestPredictorRelativeValue;
  
  
  double timeConverUnit = 1000000000.0;  
  
  
    
  public PredictionExperiments(String name,
		                       GPPredictionConfiguration configuration,
                               List<List<ObservationsAtOneTimePoint>> timeseries,
                               TimeSeriesIntervalsIndicesSet timeSeriesIntervalsIndicesSet,
                               GPEvaluationSetting gpEvaluationSetting,
                               ExcelMaker excelMakerForBestPredictor, ExcelMaker excelMakerForBestPredictorRelativeValue
                              )
  {
	this.name = name;  
	  
    this.configuration = configuration;  
      
    this.timeseries = timeseries;
    
    this.trainingDataIntervalsIndicesSet = timeSeriesIntervalsIndicesSet.getTrainingIntervalsIndicesSet();
    this.validatingDataIntervalsIndicesSet = timeSeriesIntervalsIndicesSet.getValidatingIntervalsIndicesSet();
    this.testingDataIntervalsIndicesSet = timeSeriesIntervalsIndicesSet.getTestingIntervalsIndicesSet();
    
    this.gpEvaluationSetting = gpEvaluationSetting;
    
    this.excelMakerForBestPredictor = excelMakerForBestPredictor;
    this.excelMakerForBestPredictorRelativeValue = excelMakerForBestPredictorRelativeValue;
  }
  
  
  public ForecastingOutcomeOfASegment[][][] runExperiments() throws IOException, InvalidConfigurationException
  {  
	ForecastingOutcomeOfASegment[][][] forecastingOutcome_TimeSeries = new ForecastingOutcomeOfASegment[this.configuration.getDiverseSetting().getNumberOfTimeSeries()][][]; 
 
      //different service timeseries
    for(int service=0;service<this.configuration.getDiverseSetting().getNumberOfTimeSeries();service++)
    {
       List<ObservationsAtOneTimePoint> targetTimeseries=this.timeseries.get(service); 
       
       this.gpEvaluationSetting.getMainTrainingFitnessFunction().setEntireTimeseries(targetTimeseries);
       this.gpEvaluationSetting.getMainValidator().setEntireTimeseries(targetTimeseries);
       this.gpEvaluationSetting.getMaintTester().setEntireTimeseries(targetTimeseries);
       
       this.gpEvaluationSetting.getSecondTrainingFitnessFunction().setEntireTimeseries(targetTimeseries);
       this.gpEvaluationSetting.getSecondValidator().setEntireTimeseries(targetTimeseries);
       this.gpEvaluationSetting.getSecondTester().setEntireTimeseries(targetTimeseries);
      
       forecastingOutcome_TimeSeries[service] = this.runExperimentsWithDataSegments(service);
          
           /**
          this.excelMaker.calculateAverageValues(numberOfRepeatsForAServiceTimeseries);
          this.excelMaker.drawChartsForThisExperiment(numberOfGenetions,numberOfRepeatsForAServiceTimeseries);
          this.excelMakerForPercentage.calculateAverageValues(numberOfRepeatsForAServiceTimeseries);
          this.excelMakerForPercentage.drawChartsForThisExperiment(numberOfGenetions,numberOfRepeatsForAServiceTimeseries);
          */     
    }
      
     ///*
    this.excelMakerForBestPredictor.close();
    this.excelMakerForBestPredictorRelativeValue.close(); 
      //*/
    
    return forecastingOutcome_TimeSeries;
  }
  
  
  private ForecastingOutcomeOfASegment[][] runExperimentsWithDataSegments(int timeseriesNumber) throws InvalidConfigurationException, IOException
  {
	ForecastingOutcomeOfASegment[][] forecastingOutcome_Segments = new ForecastingOutcomeOfASegment[this.trainingDataIntervalsIndicesSet.length][]; 
      
    for(int segmentNumber=0;segmentNumber<this.trainingDataIntervalsIndicesSet.length;segmentNumber++)//different time intervals segments
    { 
      this.gpEvaluationSetting.getMainTrainingFitnessFunction().setAvailableDataIntervals(this.trainingDataIntervalsIndicesSet[segmentNumber]);
      this.gpEvaluationSetting.getMainValidator().setAvailableDataIntervals(this.validatingDataIntervalsIndicesSet[segmentNumber]);
      this.gpEvaluationSetting.getMaintTester().setAvailableDataIntervals(this.testingDataIntervalsIndicesSet[segmentNumber]);
      
      this.gpEvaluationSetting.getSecondTrainingFitnessFunction().setAvailableDataIntervals(this.trainingDataIntervalsIndicesSet[segmentNumber]);
      this.gpEvaluationSetting.getSecondValidator().setAvailableDataIntervals(this.validatingDataIntervalsIndicesSet[segmentNumber]);
      this.gpEvaluationSetting.getSecondTester().setAvailableDataIntervals(this.testingDataIntervalsIndicesSet[segmentNumber]);
        
       ///**
      this.excelMakerForBestPredictor.createSheet("TS. "+timeseriesNumber+" Seg. "+segmentNumber, this.configuration.getDiverseSetting().getNumberOfGenerations());
      this.excelMakerForBestPredictorRelativeValue.createSheet("TS. "+timeseriesNumber+" Seg. "+segmentNumber, this.configuration.getDiverseSetting().getNumberOfGenerations());
       //*/
      
      forecastingOutcome_Segments[segmentNumber] = this.repeatsForAServiceTimeseries(timeseriesNumber, segmentNumber);
         
      
           /**
          this.excelMaker.calculateAverageValues(numberOfRepeatsForAServiceTimeseries);
          this.excelMaker.drawChartsForThisExperiment(numberOfGenetions,numberOfRepeatsForAServiceTimeseries);
          this.excelMakerForPercentage.calculateAverageValues(numberOfRepeatsForAServiceTimeseries);
          this.excelMakerForPercentage.drawChartsForThisExperiment(numberOfGenetions,numberOfRepeatsForAServiceTimeseries);
          */
         
    }
    
    return forecastingOutcome_Segments;
  }
  
  
  private ForecastingOutcomeOfASegment[] repeatsForAServiceTimeseries( int timeseriesNumber, int segmentNumber) throws InvalidConfigurationException
  {
	ForecastingOutcomeOfASegment[] forecastingOutcome_Repetitions = new ForecastingOutcomeOfASegment[this.configuration.getDiverseSetting().getNumberOfRepeatsForATimeseriesSegment()]; 
      
    for(int repeat=0;repeat<this.configuration.getDiverseSetting().getNumberOfRepeatsForATimeseriesSegment();repeat++)//for iterating different experiments of the same service
    {                     
                           
       GPGenotype gp = this.configuration.create();
         ///**
           this.excelMakerForBestPredictor.addExperimentDataTitles(repeat);
           this.excelMakerForBestPredictorRelativeValue.addExperimentDataTitles(repeat);
         
        //*/
           long forecastModelGenerationTime_start = ManagementFactory.getThreadMXBean( ).getCurrentThreadCpuTime();
      
       forecastingOutcome_Repetitions[repeat] = this.evolveAnEvolution(gp, segmentNumber, timeseriesNumber, repeat);
          
           long forecastModelGenerationTime_end = ManagementFactory.getThreadMXBean( ).getCurrentThreadCpuTime();     
           
           long forecastModelGenerationTime = (forecastModelGenerationTime_end-forecastModelGenerationTime_start);
  
           
       forecastingOutcome_Repetitions[repeat].setPredictorProductionTime(forecastModelGenerationTime / this.timeConverUnit);   
      
       // /**  
           this.excelMakerForBestPredictor.drawChartsForThisExperiment(this.configuration.getDiverseSetting().getNumberOfGenerations(),repeat);
           this.excelMakerForBestPredictorRelativeValue.drawChartsForThisExperiment (this.configuration.getDiverseSetting().getNumberOfGenerations(),repeat);
    
           
           this.excelMakerForBestPredictor.addEvolutionAndForecastProductionTime(this.configuration.getDiverseSetting().getNumberOfGenerations(), repeat, (forecastModelGenerationTime/this.timeConverUnit),forecastingOutcome_Repetitions[repeat].getTestingForecastsProductionTime());
           //   */
          
    }
    
    return forecastingOutcome_Repetitions;
  }
  
  
 
  private ForecastingOutcomeOfASegment evolveAnEvolution(GPGenotype gp,int segmentNumber ,int timeseriesNumber ,int repeatNumber) throws InvalidConfigurationException
  {
      //forecasting results, including 1.training observations, 2.testing observations, 3.training predictions, 4. testing predictions 
      ForecastingOutcomeOfASegment forecastingOutcomeOfASegment = new ForecastingOutcomeOfASegment(timeseriesNumber, segmentNumber, repeatNumber, this.name);//forecasting results
        
      for(int generation = 0; generation < this.configuration.getDiverseSetting().getNumberOfGenerations(); generation++)//GP evolution
      {       
         System.out.println("TS  "+ timeseriesNumber + "  Segment  " + segmentNumber + "  Repeat  " + repeatNumber + "  Generation  " + generation);  
      
         //for elitism
         IGPProgram best = this.getBestPredictor(gp.getGPPopulation(), generation == (this.configuration.getDiverseSetting().getNumberOfGenerations() - 1));
         IGPProgram bestClone = (IGPProgram)best.clone();
    
         
         if(generation == (this.configuration.getDiverseSetting().getNumberOfGenerations() - 1))//last generation
         {  
            forecastingOutcomeOfASegment.setTrainingObservations(this.gpEvaluationSetting.getMainTrainingFitnessFunction().getAvailableObservations());
            forecastingOutcomeOfASegment.setTestingObservations(this.gpEvaluationSetting.getMaintTester().getAvailableObservations());
            
            forecastingOutcomeOfASegment.setTrainingPredictions(this.gpEvaluationSetting.getMainTrainingFitnessFunction().callEvaluateToHavePredictions(best));
            forecastingOutcomeOfASegment.setTestingPredictions(this.gpEvaluationSetting.getMaintTester().callEvaluateToHavePredictions(best)); 
 /** 
  for(double d:forecastingOutcomeOfASegment.getTrainingPredictions())    
  {System.out.println("training : " + d);}
  for(double d:forecastingOutcomeOfASegment.getTestingPredictions())    
  {System.out.println("testing : " + d);}
  */
            forecastingOutcomeOfASegment.setTrainingForecastsProductionTime(this.gpEvaluationSetting.getMainTrainingFitnessFunction().getTotalForecastProductionTime() / this.timeConverUnit);
            forecastingOutcomeOfASegment.setTestingForecastsProductionTime(this.gpEvaluationSetting.getMaintTester().getTotalForecastProductionTime() / this.timeConverUnit);
          
            
            //BestPredictorTreeDrawler.drawTreeAndSaveIntoFile(timeseriesNumber, segmentNumber, repeatNumber, this.name, this.configuration, best);
         }
 /**        
 for(IGPProgram program:gp.getGPPopulation().getGPPrograms())
 {
   System.out.println("Depth: "+program.getChromosome(0).getDepth(0)+"   Size:"+program.getChromosome(0).getSize(0)
       +"  Fitness Value:  "+ program.getFitnessValue()   );
   System.out.println(program.toStringNorm(0));
 
 }   */     
         
            this.excelMakerForBestPredictor.addDataOfAGeneration
                                           (generation, repeatNumber, 
                                        		   
                                            best.getFitnessValue(),
                                            this.gpEvaluationSetting.getMainValidator().callEvaluateToHaveAMeasureValue(best), 
                                            this.gpEvaluationSetting.getMaintTester().callEvaluateToHaveAMeasureValue(best),
                                            
                                            best.getChromosome(0).getSize(0), 
                                            best.getChromosome(0).getDepth(0),
                                            best.getChromosome(0).toStringNorm(0) 
                                           );
            
             this.excelMakerForBestPredictorRelativeValue.addDataOfAGeneration
                                           (generation, repeatNumber,
                                        		   
                                            this.gpEvaluationSetting.getSecondTrainingFitnessFunction().callEvaluateToHaveAMeasureValue(best),
                                            this.gpEvaluationSetting.getSecondValidator().callEvaluateToHaveAMeasureValue(best), 
                                            this.gpEvaluationSetting.getSecondTester().callEvaluateToHaveAMeasureValue(best),
                                            
                                            0,
                                            0,
                                            "" 
                                           );
     
            
         gp.evolve();
     
         
         if(this.configuration.getDiverseSetting().isElitismEnabled())//work around by us to have elitism 
         {
           while(true)//elitism
           {
            int randomIndex=(new Random()).nextInt(gp.getGPPopulation().size());
           
            if(gp.getGPPopulation().getGPProgram(randomIndex) != this.getBestPredictor(gp.getGPPopulation(), false))
            {
              gp.getGPPopulation().setGPProgram(randomIndex, bestClone);
              break;
            }
           }
         }
         
      }
      
      return forecastingOutcomeOfASegment;
  }
  
  
  
  private IGPProgram getBestPredictor(GPPopulation population, boolean lastGeneration)
  { 
	int indexOfBest = -1;
	double bestFitnessValue = Double.POSITIVE_INFINITY;
	
	for(int i = 0; i < population.size(); i++)
	{
	  IGPProgram candidate = population.getGPProgram(i);	
		
	  if(!Double.isInfinite(candidate.getFitnessValue()) && !Double.isNaN(candidate.getFitnessValue()))
	  {
		  //in last generation, no full predictions (some predictions can not be computed) are not acceptable
		  if(lastGeneration && this.gpEvaluationSetting.getMaintTester().callEvaluateToHavePredictions(candidate).length !=  this.gpEvaluationSetting.getMaintTester().getTotalNumberOfAvailableTimePoints() )
		  {
			  continue;
		  }
		  
		  
		  if(candidate.getFitnessValue() < bestFitnessValue)
	      {   
	    	 indexOfBest = i;
	    	 bestFitnessValue = candidate.getFitnessValue() ;
	      }
	      else if(candidate.getFitnessValue() == bestFitnessValue)
	      {
	        if(candidate.getChromosome(0).getSize(0) < population.getGPProgram(indexOfBest).getChromosome(0).getSize(0))
	        {    
	        	indexOfBest = i;
		    	bestFitnessValue = population.getGPProgram(i).getFitnessValue() ;
	        }
	      }
	  }
	}  
	
	return  population.getGPProgram(indexOfBest);  
  } 
}
