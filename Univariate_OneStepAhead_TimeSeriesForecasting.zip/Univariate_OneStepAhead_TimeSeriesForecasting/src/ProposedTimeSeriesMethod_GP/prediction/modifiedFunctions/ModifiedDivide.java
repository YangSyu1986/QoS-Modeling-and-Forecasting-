/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package ProposedTimeSeriesMethod_GP.prediction.modifiedFunctions;

import org.jgap.InvalidConfigurationException;
import org.jgap.gp.CommandGene;
import org.jgap.gp.MathCommand;
import org.jgap.gp.function.Divide;
import org.jgap.gp.impl.GPConfiguration;

/**
 *
 * @author YangSyu
 */
public class ModifiedDivide extends Divide
{
    public ModifiedDivide(final GPConfiguration a_conf, Class a_returnType) throws InvalidConfigurationException 
    {
      super(a_conf, a_returnType);
    }
    
    public CommandGene applyMutation(int index, double a_percentage) throws InvalidConfigurationException 
    {
      MathCommand mutant=null;
       
      double randomValue=Math.random();
      
      if(randomValue<0.333)
      {
        mutant = new ModifiedAdd(getGPConfiguration(), getReturnType());
      }
      else if(randomValue>=0.333&&randomValue<0.666)
      {
        mutant = new ModifiedSubtract(getGPConfiguration(), getReturnType());
      }
      else 
      {
        mutant = new ModifiedMultiply(getGPConfiguration(), getReturnType()); 
      }
      
      return mutant;
    }
}
