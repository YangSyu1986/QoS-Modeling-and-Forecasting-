package ProposedTimeSeriesMethod_GP.FitnessFunctions;

public class FitnessFunction_MAPE extends FitnessFunctionBasis
{

	@Override
	protected double calculatePointError(int orderNumber, double predictedValue, double actualValue) 
	{
		
		return (Math.abs(predictedValue - actualValue) / actualValue);
	}

	
	@Override
	protected double calculateIntegratedValue( double totalError, int  validResultsCounter)
	{
	   return totalError/validResultsCounter;
	}
}
