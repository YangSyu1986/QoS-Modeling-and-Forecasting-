package ProposedTimeSeriesMethod_GP.FitnessFunctions.WeightBased;

import java.util.ArrayList;
import java.util.List;

import org.rosuda.JRI.Rengine;

import ProposedTimeSeriesMethod_GP.FitnessFunctions.FitnessFunctionBasis;
import Utilities.DatasetProcessingModules.ObservationsAtOneTimePoint;

public class WeightedMAEInspiredBySES extends FitnessFunctionBasis
{
	double alpha;//smoothing parameter for simple exponential smoothing (SES)
	
	@Override
	protected void analyzeAvaliableTimeSeries()//this method was called when the available time series intervals were set, 
	                                           //then calculates the alpha parameter value for the subsequent evaluation of this fitness function 
	{    //prepare data to get alpha value
		List<ObservationsAtOneTimePoint> timeSeries = new ArrayList<ObservationsAtOneTimePoint>();  
      
	    for(int interval = 0; interval < this.availableDataIntervals.length; interval++)  
		{  
		  for(int i = this.availableDataIntervals[interval][0]; i <= this.availableDataIntervals[interval][1]; i++)
		  {  
			  timeSeries.add(this.entireTimeseries.get(i));
		  }
		}
	    
	    double[] timeSeriesInArray = new double[timeSeries.size()];
		
	    for(int i = 0; i < timeSeriesInArray.length; i++) 
		{
	    	timeSeriesInArray[i] = timeSeries.get(i).getResponseTime();
		}                                                                                      
	    //the end of data preparation

	    
	    //using R to calculate the alpha value for this time series segment
	    Rengine re = Rengine.getMainEngine();
	   // re = new Rengine(new String[] {"--vanilla"}, false, null);
	    re.eval("library(\"forecast\")");
	    
	    re.assign("data", timeSeriesInArray);
	    re.eval("timeSeries<-ts(data)");
	    re.eval("model<-ses(timeSeries)");
	    this.alpha = re.eval("model$model$fit$par[1]").asDouble();   //R command for seeing model type : "model$method"  and "model$model$method"
	    System.out.println("alpha value : " + this.alpha);
	}
	
	
    @Override
    protected double calculatePointError(int orderNumber, double predictedValue, double actualValue) 
    {  //inspired by Simple Exponential Smoothing (SES)  	
      return  (this.alpha) * Math.pow( 1 - this.alpha, this.totalNumberOfAvailableTimePoints - orderNumber) * (Math.abs(predictedValue - actualValue));//get the difference (error) between the real answer and the predicted value
    }
    
    @Override
    protected double calculateIntegratedValue( double totalError, int  validResultsCounter)
    {
    	return totalError/validResultsCounter;
    }
    
}
