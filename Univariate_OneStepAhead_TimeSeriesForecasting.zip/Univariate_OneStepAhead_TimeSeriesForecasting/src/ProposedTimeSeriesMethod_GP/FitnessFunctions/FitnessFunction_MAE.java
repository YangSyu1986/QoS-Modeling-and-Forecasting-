/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package ProposedTimeSeriesMethod_GP.FitnessFunctions;

import java.util.List;
import org.jgap.gp.terminal.Variable;

import Utilities.DatasetProcessingModules.ObservationsAtOneTimePoint;

/**
 *
 * @author YangSyu
 */
public class FitnessFunction_MAE extends FitnessFunctionBasis
{
    @Override
    protected double calculatePointError(int orderNumber, double predictedValue, double actualValue) 
    {
      return  Math.abs(predictedValue - actualValue);//get the difference (error) between the real answer and the predicted value
    }
    
    
    @Override
    protected double calculateIntegratedValue( double totalError, int  validResultsCounter)
    {
    	return totalError/validResultsCounter;
    }
}
