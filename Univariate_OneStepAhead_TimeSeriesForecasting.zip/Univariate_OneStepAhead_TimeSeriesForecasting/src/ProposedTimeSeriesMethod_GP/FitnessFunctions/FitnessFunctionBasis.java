/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package ProposedTimeSeriesMethod_GP.FitnessFunctions;

import static ProposedTimeSeriesMethod_GP.FitnessFunctions.FitnessFunctionBasis.NO_ARGS;

import java.lang.management.ManagementFactory;
import java.util.ArrayList;
import java.util.List;
import org.jgap.gp.GPFitnessFunction;
import org.jgap.gp.IGPProgram;
import org.jgap.gp.terminal.Variable;

import Utilities.DatasetProcessingModules.ObservationsAtOneTimePoint;

/**
 *
 * @author YangSyu
 */
public abstract class FitnessFunctionBasis extends GPFitnessFunction 
{
    protected List<ObservationsAtOneTimePoint> entireTimeseries;//for storing entire timeseries, including training and testing data
    protected int[][] availableDataIntervals;
    
    List<Variable>  variables;//for storing allowed variables (terminal set)
    
    protected int totalNumberOfAvailableTimePoints;
    
    List<Double> errors;//for storing individual forecast errors (point errors)
    
      static Object[] NO_ARGS = new Object[0];

    boolean openPunishment = false;
    
    long totalForecastProductionTime = 0;
   
    
    @Override
    protected double evaluate(IGPProgram program) 
    {
      int punishmentFactor = 1;  

        
      if(this.openPunishment) //eliminate chromosomes with only one element or having no any variable
      { 
        int programSize = program.getChromosome(0).getSize(0); 
          
        boolean containAtLeastOneVariable = false;      
        for(int i = 0; i < programSize && containAtLeastOneVariable == false; i++)
        {
          for(Variable variable:this.variables)
          {
            if(program.getChromosome(0).getNode(i) == variable)
            {
              containAtLeastOneVariable = true;
              break;
            }
          }
        }
       
        if(programSize == 1 || containAtLeastOneVariable == false)//punish predictors with only one terminal or constant 
        {
           punishmentFactor = 10;
           //return Double.MAX_VALUE;
        } 
      }
      
      
 
      double totalError = 0; //for storing total error amount
      int  validResultsCounter = 0;
      double tempError = 0;
      
      this.errors = new ArrayList<Double>();//for storing individual errors
      double result = 0;
      
      for(int interval = 0; interval < this.availableDataIntervals.length; interval++)  
      {  //calculating error amount between the output of evolved predictor and the answer
        //for each training time point
        for(int i = this.availableDataIntervals[interval][0]; i <= this.availableDataIntervals[interval][1]; i++)//here i represents the index of each training time point to predict
        {  
          for(int j = 0; j<this.variables.size(); j++)//for predicting time point with index i, set this predictor's variables(terminals)' values with training data  
          {
             (this.variables.get(j)).set(this.entireTimeseries.get(i-(j+1)).getResponseTime());
          } 
          
          result = program.execute_float(0, NO_ARGS);//get this predictor's output (predicted value)    
  
   if(Double.isInfinite(result) || Double.isNaN(result) || result == 0)
   {  return Double.MAX_VALUE;
     //continue;
   }
          tempError = this.calculatePointError(validResultsCounter,result, this.entireTimeseries.get(i).getResponseTime());
          totalError = totalError + tempError;                                                           //accumulate error amount
                
          this.errors.add(tempError);
          
                   
          validResultsCounter++;
        }
      }
     
      
      return this.calculateIntegratedValue(totalError, validResultsCounter) * punishmentFactor;  
    }
    
    
    abstract protected double calculatePointError(int orderNumber, double predictedValue, double actualValue);
    
    abstract protected double calculateIntegratedValue( double totalError, int  validResultsCounter);
    
    
    
    
    public double callEvaluateToHaveAMeasureValue(IGPProgram program)
    {
      return this.evaluate(program);
    }
    
    public double[] callEvaluateToHavePredictions(IGPProgram program)
    {
       List<Double> tempPredictions = new ArrayList<Double>();
       double tempPrediction = 0;
    	
         this.totalForecastProductionTime = 0;
         long forecastProduction_StartTime = 0;
         long forecastProduction_EndTime = 0;
     
       
       for(int interval = 0;interval<this.availableDataIntervals.length;interval++)  
       {  
          for(int i=this.availableDataIntervals[interval][0];i<=this.availableDataIntervals[interval][1];i++)//here i represents the index of each training time point to predict
          {
        	    forecastProduction_StartTime = ManagementFactory.getThreadMXBean( ).getCurrentThreadCpuTime();  
        	  
            for(int j=0;j<this.variables.size();j++)
            {
                 (this.variables.get(j)).set(this.entireTimeseries.get(i-(j+1)).getResponseTime());
            } 
            
            tempPrediction = (double) program.execute_float(0, NO_ARGS);
            
                forecastProduction_EndTime = ManagementFactory.getThreadMXBean( ).getCurrentThreadCpuTime();
                this.totalForecastProductionTime = this.totalForecastProductionTime + (forecastProduction_EndTime - forecastProduction_StartTime);

            tempPredictions.add(tempPrediction);   
          }
       }
       
       return this.doubleListToDoubleArray(tempPredictions);
    }

    public void setEntireTimeseries(List<ObservationsAtOneTimePoint> entireTimeseries)
    {
        this.entireTimeseries = entireTimeseries;
    }

    public void setVariables(List<Variable> variables) 
    {
        this.variables = variables;
    }

    public void setAvailableDataIntervals(int[][] availableDataIntervals) 
    {
        this.availableDataIntervals = availableDataIntervals;
        
        int accumulation = 0;
                
        for(int[] timeInterval:this.availableDataIntervals)
        {
          accumulation = accumulation + (timeInterval[1] - timeInterval[0]) + 1;
        }
        
        this.totalNumberOfAvailableTimePoints = accumulation;
        
     
        this.analyzeAvaliableTimeSeries();//after the setting of available training data, analyze it before GP's evolution
    }
    
    protected void analyzeAvaliableTimeSeries()
    {}
    
    
    public double[] getAvailableObservations()
    {
    	List<Double> tempObservations = new ArrayList<Double>();
    	
    	for(int interval = 0;interval<this.availableDataIntervals.length;interval++)  
        {  
          for(int i=this.availableDataIntervals[interval][0];i<=this.availableDataIntervals[interval][1];i++)
          {
        	  tempObservations.add((double)this.entireTimeseries.get(i).getResponseTime());
          }
        }
    	 
    	return this.doubleListToDoubleArray(tempObservations);
    }
    
    private double[] doubleListToDoubleArray(List<Double> list)
    {
        double[] array = new double[list.size()];
    	
    	for(int i=0;i<array.length;i++)
    	{
    		array[i] = list.get(i);
    	}
    	 
    	return array;
    }

    public void setOpenPunishment(boolean openPunishment)
    {
        this.openPunishment = openPunishment;
    }
    
    
    
    public double[] getIndividualForecastErrors()
    {
      if(this.errors.size()==0)
      {
        System.out.println("No individual forecast errors!! ");
        return null;
      }
      else
      {
        double[] errors=new double[this.errors.size()];
        
        for(int i=0;i<this.errors.size();i++)
        {
          errors[i]=this.errors.get(i);
        }
        
        this.errors=null;
        
        return errors;
      }
    }

    
    public long getTotalForecastProductionTime()
    {
        long temp = this.totalForecastProductionTime;
        this.totalForecastProductionTime = 0;
        
        return temp;
    }
    
    public int getTotalNumberOfAvailableTimePoints()
    {
    	return this.totalNumberOfAvailableTimePoints;
    }
}
