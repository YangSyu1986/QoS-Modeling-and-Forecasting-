package ComparedTimeSeriesMethods_CrossApproachesSelection;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;

import Utilities.DataStructures.ExperimentNumber;
import Utilities.ForecastingAccuracyMeasures.DiverseErrorsOfASegment;
import Utilities.ForecastingAccuracyMeasures.DiverseMeasuringResultsOfASegment;
import Utilities.ForecastingCostMeasures.TimeCost;

/**
For cross-approach model selection, we consider modeling accuracy as their selection criterion because
some of them have no AIC, AICc, or BIC values (such as average and naive approaches).
Furthermore, these values calculated for different approaches (models) are not fair. 
*/

public class Selection_Approaches 
{
	String[] excludedApproachesAbbreviations;
	
	List<DiverseErrorsOfASegment[][]> outcomeOfDiverseMethods_DiverseErrors; 
	List<DiverseMeasuringResultsOfASegment[][]> outcomeOfDiverseMethods_AccuracyMeasures; 
	List<TimeCost[][]> outcomeOfDiverseMethods_TimeCosts;
	
	List<DiverseErrorsOfASegment[][]> outcomeOfSelectionMethods_DiverseErrors; 
	List<DiverseMeasuringResultsOfASegment[][]> outcomeOfSelectionMethods_AccuracyMeasures; 
	List<TimeCost[][]> outcomeOfSelectionMethods_TimeCosts;
	
	
	public Selection_Approaches(String[] excludedApproachesAbbreviations,
			                    List<DiverseErrorsOfASegment[][]> outcomeOfDiverseMethods_DiverseErrors,
			                    List<DiverseMeasuringResultsOfASegment[][]> outcomeOfDiverseMethods_AccuracyMeasures,
			                    List<TimeCost[][]> outcomeOfDiverseMethods_TimeCosts
			                   )
	{
		this.excludedApproachesAbbreviations = excludedApproachesAbbreviations;
		
		this.outcomeOfDiverseMethods_DiverseErrors = outcomeOfDiverseMethods_DiverseErrors;
		this.outcomeOfDiverseMethods_AccuracyMeasures = outcomeOfDiverseMethods_AccuracyMeasures;
		this.outcomeOfDiverseMethods_TimeCosts = outcomeOfDiverseMethods_TimeCosts;
		
		this.outcomeOfSelectionMethods_DiverseErrors = new ArrayList<DiverseErrorsOfASegment[][]>() ; 
		this.outcomeOfSelectionMethods_AccuracyMeasures = new ArrayList<DiverseMeasuringResultsOfASegment[][]>(); 
		this.outcomeOfSelectionMethods_TimeCosts = new ArrayList<TimeCost[][]>();
	}
	
	
	public void runDependingOnTrainingAccuracyApproach(String selectionCriterion, String criterionAbbreviation) throws NoSuchMethodException, SecurityException, IllegalAccessException, IllegalArgumentException, InvocationTargetException
	{
	  int numberOfTSs = this.outcomeOfDiverseMethods_AccuracyMeasures.get(0).length;
	  int numberOfSegments = this.outcomeOfDiverseMethods_AccuracyMeasures.get(0)[0].length;
		 
	  DiverseErrorsOfASegment[][] selected_DiverseErrorsOfASegment = new DiverseErrorsOfASegment[numberOfTSs][numberOfSegments];	
	  DiverseMeasuringResultsOfASegment[][] selected_DiverseMeasuringResultsOfASegment = new DiverseMeasuringResultsOfASegment[numberOfTSs][numberOfSegments];
	  TimeCost[][] selected_TimeCost = new TimeCost[numberOfTSs][numberOfSegments];
	  
	  
	  for(int i = 0; i < numberOfTSs; i++)
	  {
		  for(int j = 0; j < numberOfSegments; j++)
		  {
			  System.out.println("Select_" + criterionAbbreviation + "  TS  " + i + "  Segment  " + j);	
				
			  
			  int currentBestSelectionIndex = -1;
			  double currentBestTrainingAccuracy = Double.MAX_VALUE;	  
			  double predictorProductionTime = 0;	  
			  
			  for(int k = 0; k < this.outcomeOfDiverseMethods_AccuracyMeasures.size(); k++)//consider different forecasting approaches
			  {    //did not consider excluded approaches
				  if(matchApproachName(this.outcomeOfDiverseMethods_AccuracyMeasures.get(k)[i][j].getExperimentNumber().getMethodName(),this.excludedApproachesAbbreviations))
				  {continue;}	
				  
				  
				  Method method = this.outcomeOfDiverseMethods_AccuracyMeasures.get(k)[i][j].getClass().getMethod("getTraining" + selectionCriterion, null);
				  double currentAccuracy = (double) method.invoke(this.outcomeOfDiverseMethods_AccuracyMeasures.get(k)[i][j], null);
				  
				  predictorProductionTime = predictorProductionTime + this.outcomeOfDiverseMethods_TimeCosts.get(k)[i][j].getPredictorProductionTime();  
				  
				  if(currentBestTrainingAccuracy > currentAccuracy)
				  {
					  currentBestSelectionIndex = k;
					  currentBestTrainingAccuracy = currentAccuracy;
				  }
			  }
			  
			  ExperimentNumber experimentNumber = new ExperimentNumber(i, j , 0, "Select" + criterionAbbreviation);
			  DiverseErrorsOfASegment best_DiverseErrorsOfASegmen = this.outcomeOfDiverseMethods_DiverseErrors.get(currentBestSelectionIndex)[i][j];
			 
			  
			  selected_DiverseErrorsOfASegment[i][j] = new DiverseErrorsOfASegment(experimentNumber,
					                                                               best_DiverseErrorsOfASegmen.getTrainingAbsoluteErrors(), best_DiverseErrorsOfASegmen.getTestingAbsoluteErrors(),
					                                                               best_DiverseErrorsOfASegmen.getTrainingSquaredErrors(), best_DiverseErrorsOfASegmen.getTestingSquaredErrors(),
					                                                               best_DiverseErrorsOfASegmen.getTrainingAbsolutePercentageErrors(), best_DiverseErrorsOfASegmen.getTestingAbsolutePercentageErrors(),
					                                                               best_DiverseErrorsOfASegmen.getTestingSquaredPercentageErrors(), best_DiverseErrorsOfASegmen.getTestingSquaredPercentageErrors(),
					                                                               best_DiverseErrorsOfASegmen.getTrainingSymmetricAbsolutePercentageErrors(), best_DiverseErrorsOfASegmen.getTestingSymmetricAbsolutePercentageErrors(),
					                                                               best_DiverseErrorsOfASegmen.getTrainingAbsoluteRelativeErrors(), best_DiverseErrorsOfASegmen.getTestingAbsoluteRelativeErrors(),
					                                                               best_DiverseErrorsOfASegmen.getTrainingAbsoluteScaledErrors(), best_DiverseErrorsOfASegmen.getTestingAbsoluteScaledErrors(),
					                                                               best_DiverseErrorsOfASegmen.getTestingSquaredScaledErrors(), best_DiverseErrorsOfASegmen.getTestingSquaredScaledErrors()
					                                                              );
			  
			  selected_DiverseMeasuringResultsOfASegment[i][j] = new DiverseMeasuringResultsOfASegment(selected_DiverseErrorsOfASegment[i][j]);
			  
			  TimeCost timeCost = new TimeCost(experimentNumber, predictorProductionTime, this.outcomeOfDiverseMethods_TimeCosts.get(currentBestSelectionIndex)[i][j].getTrainingForecastsProductionTime(),this.outcomeOfDiverseMethods_TimeCosts.get(currentBestSelectionIndex)[i][j].getTestingForecastsProductionTime());
			  selected_TimeCost[i][j] = timeCost; 
		  }
	  }
	  
	  
	  this.outcomeOfSelectionMethods_DiverseErrors.add(selected_DiverseErrorsOfASegment); 
	  this.outcomeOfSelectionMethods_AccuracyMeasures.add(selected_DiverseMeasuringResultsOfASegment); 
	  this.outcomeOfSelectionMethods_TimeCosts.add(selected_TimeCost);
	}
	
	
	public void endSelectionBasedOnTrainingAccuracyApproaches()
	{
		for(int i = 0; i < this.outcomeOfSelectionMethods_DiverseErrors.size(); i++)
		{
			this.outcomeOfDiverseMethods_DiverseErrors.add(this.outcomeOfSelectionMethods_DiverseErrors.get(i));
			this.outcomeOfDiverseMethods_AccuracyMeasures.add(this.outcomeOfSelectionMethods_AccuracyMeasures.get(i));
			this.outcomeOfDiverseMethods_TimeCosts.add(this.outcomeOfSelectionMethods_TimeCosts.get(i));
		}
	}
	
	
	
	private boolean matchApproachName(String currentApproachAbbreviation, String[] excludedApproachesAbbreviations)
	{
		for(String approachAbbreviation:excludedApproachesAbbreviations)
		{
			if(approachAbbreviation.equals(currentApproachAbbreviation)) {return true;}
		}
		
		return false;
	}
}





