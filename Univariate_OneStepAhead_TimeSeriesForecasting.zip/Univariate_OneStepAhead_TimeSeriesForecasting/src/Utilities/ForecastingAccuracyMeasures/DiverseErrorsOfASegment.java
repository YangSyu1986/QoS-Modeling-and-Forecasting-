package Utilities.ForecastingAccuracyMeasures;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.math.stat.descriptive.DescriptiveStatistics;

import Utilities.DataStructures.ExperimentNumber;
import Utilities.DataStructures.ForecastingOutcomeOfASegment;

public class DiverseErrorsOfASegment 
{
	ExperimentNumber experimentNumber;
	
	double percentageOfValidTrainingObservations;
	double percentageOfValidTrainingPredictions;
	double percentageOfValidTestingObservations;
	double percentageOfValidTestingPredictions;
	
	
	double[] validTrainingObservations;
	double[] validTrainingPredictions;
	double[] validTestingObservations;
	double[] validTestingPredictions;	
	  
	double[] trainingDifferences;//differences, i.e, absolute errors without absolution
	double[] testingDifferences;
	
	double[] trainingAbsoluteErrors;
	double[] testingAbsoluteErrors;
	
	double[] trainingSquaredErrors;
	double[] testingSquaredErrors;
	
	double[] trainingAbsolutePercentageErrors;
	double[] testingAbsolutePercentageErrors;
	
	double[] trainingSquaredPercentageErrors;
	double[] testingSquaredPercentageErrors;
	
	double[] trainingSymmetricAbsolutePercentageErrors;
	double[] testingSymmetricAbsolutePercentageErrors;
	
	double[] trainingAbsoluteRelativeErrors;
	double[] testingAbsoluteRelativeErrors;
	
	/**boolean[] trainingPercentBetters;
	boolean[] testingPercentBetters;*/
	
	double[] trainingAbsoluteScaledErrors;
	double[] testingAbsoluteScaledErrors;
	
	double[] trainingSquaredScaledErrors;
	double[] testingSquaredScaledErrors;
	
	
	//the standard deviation of diverse error types
	double trainingAbsoluteErrorsSD;
	double testingAbsoluteErrorsSD;
	
	double trainingSquaredErrorsSD;
	double testingSquaredErrorsSD;
	
	double trainingAbsolutePercentageErrorsSD;
	double testingAbsolutePercentageErrorsSD;
	
	double trainingSquaredPercentageErrorsSD;
	double testingSquaredPercentageErrorsSD;
	
	double trainingSymmetricAbsolutePercentageErrorsSD;
	double testingSymmetricAbsolutePercentageErrorsSD;
	
	double trainingAbsoluteRelativeErrorsSD;
	double testingAbsoluteRelativeErrorsSD;
	
	double trainingAbsoluteScaledErrorsSD;
	double testingAbsoluteScaledErrorsSD;
	
	double trainingSquaredScaledErrorsSD;
	double testingSquaredScaledErrorsSD;
 	

	public DiverseErrorsOfASegment()
	{}
	
	public DiverseErrorsOfASegment(ExperimentNumber experimentNumber, 
            double[] trainingAbsoluteErrors,	double[] testingAbsoluteErrors,
            double[] trainingSquaredErrors, double[] testingSquaredErrors,
            double[] trainingAbsolutePercentageErrors, double[] testingAbsolutePercentageErrors,
            double[] trainingSquaredPercentageErrors, double[] testingSquaredPercentageErrors,
            double[] trainingSymmetricAbsolutePercentageErrors, double[] testingSymmetricAbsolutePercentageErrors,
            double[] trainingAbsoluteRelativeErrors, double[] testingAbsoluteRelativeErrors,
            double[] trainingAbsoluteScaledErrors, double[] testingAbsoluteScaledErrors,
            double[] trainingSquaredScaledErrors, double[] testingSquaredScaledErrors
           )
    {
      this.experimentNumber = experimentNumber;

      this.trainingAbsoluteErrors = trainingAbsoluteErrors;	this.testingAbsoluteErrors = testingAbsoluteErrors;
      this.trainingSquaredErrors = trainingSquaredErrors; this.testingSquaredErrors = testingSquaredErrors;
      this.trainingAbsolutePercentageErrors = trainingAbsolutePercentageErrors; this.testingAbsolutePercentageErrors = testingAbsolutePercentageErrors;
      this.trainingSquaredPercentageErrors = trainingSquaredPercentageErrors; this.testingSquaredPercentageErrors = testingSquaredPercentageErrors;
      this.trainingSymmetricAbsolutePercentageErrors = trainingSymmetricAbsolutePercentageErrors; this.testingSymmetricAbsolutePercentageErrors = testingSymmetricAbsolutePercentageErrors;
      this.trainingAbsoluteRelativeErrors = trainingAbsoluteRelativeErrors; this.testingAbsoluteRelativeErrors = testingAbsoluteRelativeErrors;
      this.trainingAbsoluteScaledErrors = trainingAbsoluteScaledErrors; this.testingAbsoluteScaledErrors = testingAbsoluteScaledErrors;
      this.trainingSquaredScaledErrors = trainingSquaredScaledErrors; this.testingSquaredScaledErrors = testingSquaredScaledErrors;
      
      this.calculateStandardDeviationOfDiverseErrors();
    }

	
	public DiverseErrorsOfASegment(ForecastingOutcomeOfASegment originalForecastingOutcomeOfASegment)
	{
		this.experimentNumber = originalForecastingOutcomeOfASegment.getExperimentNumber();
		
		
		this.preprocessing(originalForecastingOutcomeOfASegment);
		
		this.calculateDifferences();

		this.calculateAbsoluteErrors();
	  	this.calculateSquaredErrors();
	  	
	  	this.calculateAbsolutePercentageErrors();
	  	this.calculateSquaredPercentageErrors();
	  	this.calculateSymmetricAbsolutePercentageErrors();
	  	
	  	this.calculateAbsoluteRelativeErrors();
	  	
	  	//this.calculatePercentBetters();
	  	
	  	this.calculateAbsoluteScaledErrors();
	  	this.calculateSquaredScaledErrors();
	  	
	  	
	  	this.calculateStandardDeviationOfDiverseErrors();
	}
	
	public void preprocessing(ForecastingOutcomeOfASegment originalForecastingOutcomeOfASegment)
	{
		this.preprocessing_training(originalForecastingOutcomeOfASegment);
		this.preprocessing_testing(originalForecastingOutcomeOfASegment);
	}
	
	
	private void preprocessing_training(ForecastingOutcomeOfASegment originalForecastingOutcomeOfASegment)
	{
		List<Double> validTrainingObservations_list = new ArrayList<Double>();
		List<Double> validTrainingPredictions_list = new ArrayList<Double>();
		
		int numberOfValidTrainingObservations = originalForecastingOutcomeOfASegment.getTrainingObservations().length;
		int numberOfValidTrainingPredictions = originalForecastingOutcomeOfASegment.getTrainingPredictions().length;
		
		double tempObservation = 0;
		double tempPrediction = 0;
		boolean flag = false;
		
		for(int i = 0;i<originalForecastingOutcomeOfASegment.getTrainingObservations().length;i++)
		{
			flag = false;
			tempObservation = originalForecastingOutcomeOfASegment.getTrainingObservations()[i];
			tempPrediction = originalForecastingOutcomeOfASegment.getTrainingPredictions()[i];
			
			if(tempObservation == 0 || Double.isNaN(tempObservation) || Double.isInfinite(tempObservation))
			{
				numberOfValidTrainingObservations--;
				flag = true; 
			}
			
			if(tempPrediction == 0 || Double.isNaN(tempPrediction) || Double.isInfinite(tempPrediction))
			{
				numberOfValidTrainingPredictions--;
				flag = true; 
			}
			
			if(flag)
			{
				continue;
			}
			else
			{
				validTrainingObservations_list.add(tempObservation);
				validTrainingPredictions_list.add(tempPrediction);
			}
		}
			
		
		this.validTrainingObservations =  new double[validTrainingObservations_list.size()];
		for(int i=0;i<validTrainingObservations.length;i++)
		{
			this.validTrainingObservations[i] = validTrainingObservations_list.get(i);
		}
		
		this.validTrainingPredictions =  new double[validTrainingPredictions_list.size()];
		for(int i=0;i<validTrainingPredictions.length;i++)
		{
			this.validTrainingPredictions[i] = validTrainingPredictions_list.get(i);
		}
		
	
		this.percentageOfValidTrainingObservations = numberOfValidTrainingObservations / (double) originalForecastingOutcomeOfASegment.getTrainingObservations().length; 
		this.percentageOfValidTrainingPredictions = numberOfValidTrainingPredictions / (double) originalForecastingOutcomeOfASegment.getTrainingPredictions().length;  
	}
	
	private void preprocessing_testing(ForecastingOutcomeOfASegment originalForecastingOutcomeOfASegment)
	{
		List<Double> validTestingObservations_list = new ArrayList<Double>();
		List<Double> validTestingPredictions_list = new ArrayList<Double>();
		
		int numberOfValidTestingObservations = originalForecastingOutcomeOfASegment.getTestingObservations().length;
		int numberOfValidTestingPredictions = originalForecastingOutcomeOfASegment.getTestingPredictions().length;
		
		double tempObservation = 0;
		double tempPrediction = 0;
		boolean flag = false;
		
		for(int i = 0;i<originalForecastingOutcomeOfASegment.getTestingObservations().length;i++)
		{
			flag = false;
			tempObservation = originalForecastingOutcomeOfASegment.getTestingObservations()[i];
			tempPrediction = originalForecastingOutcomeOfASegment.getTestingPredictions()[i];
			
			if(tempObservation == 0 || Double.isNaN(tempObservation) || Double.isInfinite(tempObservation))
			{
				numberOfValidTestingObservations--;
				flag = true;
			}
			
			if(tempPrediction == 0 || Double.isNaN(tempPrediction) || Double.isInfinite(tempPrediction))
			{
				numberOfValidTestingPredictions--;
				flag = true;
			}
			
			if(flag)
			{
				continue;
			}
			else
			{
				validTestingObservations_list.add(tempObservation);
				validTestingPredictions_list.add(tempPrediction);
			}
		}
			
		
		this.validTestingObservations =  new double[validTestingObservations_list.size()];
		for(int i=0;i<validTestingObservations.length;i++)
		{
			this.validTestingObservations[i] = validTestingObservations_list.get(i);
		}
		
		this.validTestingPredictions =  new double[validTestingPredictions_list.size()];
		for(int i=0;i<validTestingPredictions.length;i++)
		{
			this.validTestingPredictions[i] = validTestingPredictions_list.get(i);
		}
		
	
		this.percentageOfValidTestingObservations = numberOfValidTestingObservations / (double) originalForecastingOutcomeOfASegment.getTestingObservations().length; 
		this.percentageOfValidTestingPredictions = numberOfValidTestingPredictions / (double) originalForecastingOutcomeOfASegment.getTestingPredictions().length;  
	}
	
	public double getPercentageOfValidTrainingObservations() 
	{
		return percentageOfValidTrainingObservations;
	}

	public double getPercentageOfValidTrainingPredictions()
	{
		return percentageOfValidTrainingPredictions;
	}

	public double getPercentageOfValidTestingObservations() 
	{
		return percentageOfValidTestingObservations;
	}

	public double getPercentageOfValidTestingPredictions()
	{
		return percentageOfValidTestingPredictions;
	}
	
	
	private void calculateDifferences()
	{
		this.trainingDifferences = new double[this.validTrainingObservations.length];
		this.testingDifferences = new double[this.validTestingObservations.length];
		
		for(int i = 0; i < this.trainingDifferences.length; i++)
		{
		  this.trainingDifferences[i] = this.validTrainingObservations[i] - this.validTrainingPredictions[i];
		}
		
		for(int i = 0; i < this.testingDifferences.length; i++)
		{
		  this.testingDifferences[i] = this.validTestingObservations[i] - this.validTestingPredictions[i];
		}	
	}
	
	private void calculateAbsoluteErrors()
	{
		this.trainingAbsoluteErrors = new double[this.validTrainingObservations.length];
		this.testingAbsoluteErrors = new double[this.validTestingObservations.length];
		
		for(int i=0;i<this.trainingAbsoluteErrors.length;i++)
		{
		  this.trainingAbsoluteErrors[i] = Math.abs(this.validTrainingObservations[i] - this.validTrainingPredictions[i]);
		}
		
		for(int i=0;i<this.testingAbsoluteErrors.length;i++)
		{
		  this.testingAbsoluteErrors[i] = Math.abs(this.validTestingObservations[i] - this.validTestingPredictions[i]);
		}
	}
	
	private void calculateSquaredErrors()
	{
		this.trainingSquaredErrors = new double[this.validTrainingObservations.length];
		this.testingSquaredErrors = new double[this.validTestingObservations.length];
		
		for(int i=0;i<this.trainingSquaredErrors.length;i++)
		{
		  this.trainingSquaredErrors[i] = Math.pow(this.trainingAbsoluteErrors[i],2);
		}
		
		for(int i=0;i<this.testingSquaredErrors.length;i++)
		{
		  this.testingSquaredErrors[i] = Math.pow(this.testingAbsoluteErrors[i],2);
		}
	}
	
	
	private void calculateAbsolutePercentageErrors()
	{
		this.trainingAbsolutePercentageErrors = new double[this.validTrainingObservations.length];
		this.testingAbsolutePercentageErrors = new double[this.validTestingObservations.length];
		
		
		for(int i=0;i<this.trainingAbsoluteErrors.length;i++)
		{
		  this.trainingAbsolutePercentageErrors[i] = Math.abs((this.validTrainingObservations[i] - this.validTrainingPredictions[i]) / this.validTrainingObservations[i]);
		}
		
		for(int i=0;i<this.testingAbsoluteErrors.length;i++)
		{ 
		  this.testingAbsolutePercentageErrors[i] = Math.abs((this.validTestingObservations[i] - this.validTestingPredictions[i]) / this.validTestingObservations[i]);
		}
	}
	
	private void calculateSquaredPercentageErrors()
	{
		this.trainingSquaredPercentageErrors = new double[this.validTrainingObservations.length];
		this.testingSquaredPercentageErrors = new double[this.validTestingObservations.length];
		
		for(int i=0;i<this.trainingSquaredPercentageErrors.length;i++)
		{
		  this.trainingSquaredPercentageErrors[i] = Math.pow(this.trainingAbsolutePercentageErrors[i], 2);
		}
		
		for(int i=0;i<this.testingSquaredPercentageErrors.length;i++)
		{
		  this.testingSquaredPercentageErrors[i] =  Math.pow(this.testingAbsolutePercentageErrors[i], 2);
		}
	}
	
	private void calculateSymmetricAbsolutePercentageErrors()
	{
		this.trainingSymmetricAbsolutePercentageErrors = new double[this.validTrainingObservations.length];
		this.testingSymmetricAbsolutePercentageErrors = new double[this.validTestingObservations.length];
		
		for(int i=0;i<this.trainingSymmetricAbsolutePercentageErrors.length;i++)
		{
		  this.trainingSymmetricAbsolutePercentageErrors[i] = (Math.abs( this.validTrainingPredictions[i] - this.validTrainingObservations[i] ) / ( Math.abs(this.validTrainingObservations[i]) + Math.abs(this.validTrainingPredictions[i]) ) );
		}
		
		for(int i=0;i<this.testingSymmetricAbsolutePercentageErrors.length;i++)
		{ 
		  this.testingSymmetricAbsolutePercentageErrors[i] =  (Math.abs(  this.validTestingPredictions[i] - this.validTestingObservations[i] ) / ( Math.abs(this.validTestingObservations[i]) + Math.abs(this.validTestingPredictions[i]) ) );
		}
	}
	
	
	private void calculateAbsoluteRelativeErrors()
	{
		this.trainingAbsoluteRelativeErrors = new double[this.validTrainingObservations.length];
		this.testingAbsoluteRelativeErrors = new double[this.validTestingObservations.length];
		
		
		this.trainingAbsoluteRelativeErrors[0] = 1;
		
		for(int i = 1; i < this.trainingAbsoluteRelativeErrors.length; i++)
		{ 
		  this.trainingAbsoluteRelativeErrors[i] = (Math.abs(this.validTrainingObservations[i] - this.validTrainingPredictions[i]) / Math.abs(this.validTrainingObservations[i] - this.validTrainingObservations[i-1]));
		}
		
		
		this.testingAbsoluteRelativeErrors[0] = (Math.abs(this.validTestingObservations[0] - this.validTestingPredictions[0]) / Math.abs(this.validTestingObservations[0] - this.validTrainingObservations[this.validTrainingObservations.length - 1]));
		
		for(int i = 1; i<this.validTestingObservations.length; i++)
		{ 
		  this.testingAbsoluteRelativeErrors[i] = (Math.abs(this.validTestingObservations[i] - this.validTestingPredictions[i]) / Math.abs(this.validTestingObservations[i] - this.validTestingObservations[i-1]));
		}
	}
	
	/**
	private void calculatePercentBetters()
	{
		this.trainingPercentBetters = new boolean[this.validTrainingObservations.length - 1];
		this.testingPercentBetters = new boolean[this.validTestingObservations.length];
		
		
		for(int i=1;i<this.validTrainingObservations.length;i++)
		{
		  this.trainingPercentBetters[i-1] = Math.abs(this.validTrainingObservations[i] - this.validTrainingPredictions[i]) > Math.abs(this.validTrainingObservations[i] - this.validTrainingObservations[i-1]);
		}
		
		this.testingPercentBetters[0] = Math.abs(this.validTestingObservations[0] - this.validTestingPredictions[0]) > Math.abs(this.validTestingObservations[0] - this.validTrainingObservations[this.validTrainingObservations.length - 1]);
		for(int i=1;i<this.testingPercentBetters.length;i++)
		{
		  this.testingPercentBetters[i] = Math.abs(this.validTestingObservations[i] - this.validTestingPredictions[i]) > Math.abs(this.validTestingObservations[i] - this.validTestingObservations[i-1]);
		}
	}
	*/
	
	private void calculateAbsoluteScaledErrors()
	{
		this.trainingAbsoluteScaledErrors = new double[this.validTrainingObservations.length];
		this.testingAbsoluteScaledErrors = new double[this.validTestingObservations.length];
		
		
		double trainingMAEfromNaiveMethod = 0;
		
		for(int i=1;i<this.validTrainingObservations.length;i++)
		{
			trainingMAEfromNaiveMethod = trainingMAEfromNaiveMethod + (Math.abs(this.validTrainingObservations[i] - this.validTrainingObservations[i-1]));
		}
		
		trainingMAEfromNaiveMethod = trainingMAEfromNaiveMethod / (this.validTrainingObservations.length - 1);
		
		
		for(int i=0;i<this.validTrainingObservations.length;i++)
		{
		  this.trainingAbsoluteScaledErrors[i] = Math.abs(this.validTrainingObservations[i] - this.validTrainingPredictions[i]) / trainingMAEfromNaiveMethod;
		}
		
		for(int i=0;i<this.validTestingObservations.length;i++)
		{
		  this.testingAbsoluteScaledErrors[i] = Math.abs(this.validTestingObservations[i] - this.validTestingPredictions[i]) / trainingMAEfromNaiveMethod;
		}
	}

	private void calculateSquaredScaledErrors()
	{
		this.trainingSquaredScaledErrors = new double[this.validTrainingObservations.length];
		this.testingSquaredScaledErrors = new double[this.validTestingObservations.length];
		
		for(int i=0;i<this.trainingSquaredScaledErrors.length;i++)
		{
		  this.trainingSquaredScaledErrors[i] = Math.pow(this.trainingAbsoluteScaledErrors[i],2);
		}
		
		for(int i=0;i<this.testingSquaredScaledErrors.length;i++)
		{
		  this.testingSquaredScaledErrors[i] = Math.pow(this.testingAbsoluteScaledErrors[i],2);
		}
		
	}	
	
	
	private void calculateStandardDeviationOfDiverseErrors()
	{
		this.trainingAbsoluteErrorsSD = this.calculateStandardDeviation(this.trainingAbsoluteErrors);
		this.testingAbsoluteErrorsSD = this.calculateStandardDeviation(this.testingAbsoluteErrors);
		
		this.trainingSquaredErrorsSD = this.calculateStandardDeviation(this.trainingSquaredErrors);
		this.testingSquaredErrorsSD = this.calculateStandardDeviation(this.testingSquaredErrors);
		
		this.trainingAbsolutePercentageErrorsSD = this.calculateStandardDeviation(this.trainingAbsolutePercentageErrors);
		this.testingAbsolutePercentageErrorsSD = this.calculateStandardDeviation(this.testingAbsolutePercentageErrors);
		
		this.trainingSquaredPercentageErrorsSD = this.calculateStandardDeviation(this.trainingSquaredPercentageErrors);
		this.testingSquaredPercentageErrorsSD = this.calculateStandardDeviation(this.testingSquaredPercentageErrors);
		
		this.trainingSymmetricAbsolutePercentageErrorsSD = this.calculateStandardDeviation(this.trainingSymmetricAbsolutePercentageErrors);
		this.testingSymmetricAbsolutePercentageErrorsSD = this.calculateStandardDeviation(this.testingSymmetricAbsolutePercentageErrors);
		
		this.trainingAbsoluteRelativeErrorsSD = this.calculateStandardDeviation(this.trainingAbsoluteRelativeErrors);
		this.testingAbsoluteRelativeErrorsSD = this.calculateStandardDeviation(this.testingAbsoluteRelativeErrors);
		
		this.trainingAbsoluteScaledErrorsSD = this.calculateStandardDeviation(this.trainingAbsoluteScaledErrors);
		this.testingAbsoluteScaledErrorsSD = this.calculateStandardDeviation(this.testingAbsoluteScaledErrors);
		
		this.trainingSquaredScaledErrorsSD = this.calculateStandardDeviation(this.trainingSquaredScaledErrors);
		this.testingSquaredScaledErrorsSD = this.calculateStandardDeviation(this.testingSquaredScaledErrors);
	}
	
	private double calculateStandardDeviation(double[] errors)
	{
		DescriptiveStatistics statistics = new DescriptiveStatistics();
		
		for(double error:errors)
		{
			statistics.addValue(error);
		}
		
		return statistics.getStandardDeviation();
	}
	
	
	
	public ExperimentNumber getExperimentNumber()
	{
		return experimentNumber;
	}

	public double[] getTrainingAbsoluteErrors() 
	{
		return trainingAbsoluteErrors;
	}

	public double[] getTestingAbsoluteErrors()
	{
		return testingAbsoluteErrors;
	}

	public double[] getTrainingSquaredErrors()
	{
		return trainingSquaredErrors;
	}

	public double[] getTestingSquaredErrors() 
	{
		return testingSquaredErrors;
	}

	public double[] getTrainingAbsolutePercentageErrors()
	{
		return trainingAbsolutePercentageErrors;
	}

	public double[] getTestingAbsolutePercentageErrors()
	{
		return testingAbsolutePercentageErrors;
	}

	public double[] getTrainingSquaredPercentageErrors() 
	{
		return trainingSquaredPercentageErrors;
	}

	public double[] getTestingSquaredPercentageErrors() 
	{
		return testingSquaredPercentageErrors;
	}

	public double[] getTrainingSymmetricAbsolutePercentageErrors() 
	{
		return trainingSymmetricAbsolutePercentageErrors;
	}

	public double[] getTestingSymmetricAbsolutePercentageErrors()
	{
		return testingSymmetricAbsolutePercentageErrors;
	}

	public double[] getTrainingAbsoluteRelativeErrors() 
	{
		return trainingAbsoluteRelativeErrors;
	}

	public double[] getTestingAbsoluteRelativeErrors()
	{
		return testingAbsoluteRelativeErrors;
	}

	/**public boolean[] getTrainingPercentBetters() 
	{
		return trainingPercentBetters;
	}

	public boolean[] getTestingPercentBetters() 
	{
		return testingPercentBetters;
	}*/

	public double[] getTrainingAbsoluteScaledErrors() 
	{
		return trainingAbsoluteScaledErrors;
	}

	public double[] getTestingAbsoluteScaledErrors() 
	{
		return testingAbsoluteScaledErrors;
	}
	
	public double[] getTrainingSquaredScaledErrors() 
	{
		return trainingSquaredScaledErrors;
	}

	public double[] getTestingSquaredScaledErrors() 
	{
		return testingSquaredScaledErrors;
	}
	
	
	//the getter of Error SD
	public double getTrainingAbsoluteErrorsSD() 
	{
		return trainingAbsoluteErrorsSD;
	}

	public double getTestingAbsoluteErrorsSD() 
	{
		return testingAbsoluteErrorsSD;
	}

	public double getTrainingSquaredErrorsSD() 
	{
		return trainingSquaredErrorsSD;
	}

	public double getTestingSquaredErrorsSD() 
	{
		return testingSquaredErrorsSD;
	}

	public double getTrainingAbsolutePercentageErrorsSD() 
	{
		return trainingAbsolutePercentageErrorsSD;
	}

	public double getTestingAbsolutePercentageErrorsSD() 
	{
		return testingAbsolutePercentageErrorsSD;
	}

	public double getTrainingSquaredPercentageErrorsSD()
	{
		return trainingSquaredPercentageErrorsSD;
	}

	public double getTestingSquaredPercentageErrorsSD() {
		return testingSquaredPercentageErrorsSD;
	}

	public double getTrainingSymmetricAbsolutePercentageErrorsSD()
	{
		return trainingSymmetricAbsolutePercentageErrorsSD;
	}

	public double getTestingSymmetricAbsolutePercentageErrorsSD()
	{
		return testingSymmetricAbsolutePercentageErrorsSD;
	}

	public double getTrainingAbsoluteRelativeErrorsSD()
	{
		return trainingAbsoluteRelativeErrorsSD;
	}

	public double getTestingAbsoluteRelativeErrorsSD()
	{
		return testingAbsoluteRelativeErrorsSD;
	}

	public double getTrainingAbsoluteScaledErrorsSD()
	{
		return trainingAbsoluteScaledErrorsSD;
	}

	public double getTestingAbsoluteScaledErrorsSD()
	{
		return testingAbsoluteScaledErrorsSD;
	}

	public double getTrainingSquaredScaledErrorsSD()
	{
		return trainingSquaredScaledErrorsSD;
	}

	public double getTestingSquaredScaledErrorsSD()
	{
		return testingSquaredScaledErrorsSD;
	}
}
