package Utilities.ForecastingAccuracyMeasures;

import java.math.BigDecimal;

import org.apache.commons.math.stat.descriptive.DescriptiveStatistics;

import Utilities.DataStructures.ExperimentNumber;

public class DiverseMeasuringResultsOfASegment
{
  ExperimentNumber experimentNumber;
  
  
  double trainingMeanAbsoluteError;
  double testingMeanAbsoluteError;
  
  double trainingGeometricMeanAbsoluteError;
  double testingGeometricMeanAbsoluteError;
  
  double trainingMedianAbsoluteError;
  double testingMedianAbsoluteError;
  
  double trainingMeanSquaredError;
  double testingMeanSquaredError;
  
  double trainingRootMeanSquaredError;
  double testingRootMeanSquaredError;
  
  
  double trainingMeanAbsolutePercentageError;
  double testingMeanAbsolutePercentageError;
  
  double trainingMedianAbsolutePercentageError;
  double testingMedianAbsolutePercentageError;
  
  double trainingRootMeanSquaredPercentageError;
  double testingRootMeanSquaredPercentageError;
  
  double trainingRootMedianSquaredPercentageError;
  double testingRootMedianSquaredPercentageError;
  
  double trainingSymmetricMeanAbsolutePercentageError;
  double testingSymmetricMeanAbsolutePercentageError;
  
  double trainingSymmetricMedianAbsolutePercentageError;
  double testingSymmetricMedianAbsolutePercentageError;
  
	
  double trainingMeanRelativeAbsoluteError;
  double testingMeanRelativeAbsoluteError;
  
  double trainingMedianRelativeAbsoluteError;
  double testingMedianRelativeAbsoluteError;
  
  double trainingGeometricMeanRelativeAbsoluteError;
  double testingGeometricMeanRelativeAbsoluteError;
  
  
  double trainingMeanAbsoluteScaledError;
  double testingMeanAbsoluteScaledError;
  
  double trainingRootMeanSquaredScaledError;
  double testingRootMeanSquaredScaledError;
  
  double trainingMedianAbsoluteScaledError;
  double testingMedianAbsoluteScaledError;
  
  
  public DiverseMeasuringResultsOfASegment(ExperimentNumber experimentNumber,
                                           double trainingMeanAbsoluteError, double testingMeanAbsoluteError,
                                           double trainingGeometricMeanAbsoluteError, double testingGeometricMeanAbsoluteError,
                                           double trainingMedianAbsoluteError,double testingMedianAbsoluteError,
                                           double trainingMeanSquaredError,double testingMeanSquaredError,
                                           double trainingRootMeanSquaredError,double testingRootMeanSquaredError,
                                           double trainingMeanAbsolutePercentageError,double testingMeanAbsolutePercentageError,
                                           double trainingMedianAbsolutePercentageError,double testingMedianAbsolutePercentageError,
                                           double trainingRootMeanSquaredPercentageError,double testingRootMeanSquaredPercentageError,
                                           double trainingRootMedianSquaredPercentageError,double testingRootMedianSquaredPercentageError,
                                           double trainingSymmetricMeanAbsolutePercentageError,double testingSymmetricMeanAbsolutePercentageError,
                                           double trainingSymmetricMedianAbsolutePercentageError,double testingSymmetricMedianAbsolutePercentageError,
                                           double trainingMeanRelativeAbsoluteError,double testingMeanRelativeAbsoluteError,
                                           double trainingMedianRelativeAbsoluteError,double testingMedianRelativeAbsoluteError,
                                           double trainingGeometricMeanRelativeAbsoluteError,double testingGeometricMeanRelativeAbsoluteError,
                                           double trainingMeanAbsoluteScaledError,double testingMeanAbsoluteScaledError,
                                           double trainingRootMeanSquaredScaledError,double testingRootMeanSquaredScaledError,
                                           double trainingMedianAbsoluteScaledError,double testingMedianAbsoluteScaledError
                                          )
  {
	  this.experimentNumber = experimentNumber;
	  
	  this.trainingMeanAbsoluteError = trainingMeanAbsoluteError; this.testingMeanAbsoluteError = testingMeanAbsoluteError;
      this.trainingGeometricMeanAbsoluteError = trainingGeometricMeanAbsoluteError; this.testingGeometricMeanAbsoluteError = testingGeometricMeanAbsoluteError;
      this.trainingMedianAbsoluteError = trainingMedianAbsoluteError;this.testingMedianAbsoluteError = testingMedianAbsoluteError;
      this.trainingMeanSquaredError = trainingMeanSquaredError;this.testingMeanSquaredError = testingMeanSquaredError;
      this.trainingRootMeanSquaredError = trainingRootMeanSquaredError;this.testingRootMeanSquaredError = testingRootMeanSquaredError;
      this.trainingMeanAbsolutePercentageError = trainingMeanAbsolutePercentageError;this.testingMeanAbsolutePercentageError = testingMeanAbsolutePercentageError;
      this.trainingMedianAbsolutePercentageError = trainingMedianAbsolutePercentageError;this.testingMedianAbsolutePercentageError = testingMedianAbsolutePercentageError;
      this.trainingRootMeanSquaredPercentageError = trainingRootMeanSquaredPercentageError;this.testingRootMeanSquaredPercentageError = testingRootMeanSquaredPercentageError;
      this.trainingRootMedianSquaredPercentageError = trainingRootMedianSquaredPercentageError;this.testingRootMedianSquaredPercentageError = testingRootMedianSquaredPercentageError;
      this.trainingSymmetricMeanAbsolutePercentageError = trainingSymmetricMeanAbsolutePercentageError;this.testingSymmetricMeanAbsolutePercentageError = testingSymmetricMeanAbsolutePercentageError;
      this.trainingSymmetricMedianAbsolutePercentageError = trainingSymmetricMedianAbsolutePercentageError;this.testingSymmetricMedianAbsolutePercentageError = testingSymmetricMedianAbsolutePercentageError;
      this.trainingMeanRelativeAbsoluteError = trainingMeanRelativeAbsoluteError;this.testingMeanRelativeAbsoluteError = testingMeanRelativeAbsoluteError;
      this.trainingMedianRelativeAbsoluteError = trainingMedianRelativeAbsoluteError;this.testingMedianRelativeAbsoluteError = testingMedianRelativeAbsoluteError;
      this.trainingGeometricMeanRelativeAbsoluteError = trainingGeometricMeanRelativeAbsoluteError;this.testingGeometricMeanRelativeAbsoluteError = testingGeometricMeanRelativeAbsoluteError;
      this.trainingMeanAbsoluteScaledError = trainingMeanAbsoluteScaledError;this.testingMeanAbsoluteScaledError = testingMeanAbsoluteScaledError;
      this.trainingRootMeanSquaredScaledError = trainingRootMeanSquaredScaledError;this.testingRootMeanSquaredScaledError = testingRootMeanSquaredScaledError;
      this.trainingMedianAbsoluteScaledError = trainingMedianAbsoluteScaledError;this.testingMedianAbsoluteScaledError = testingMedianAbsoluteScaledError;
  }
  
  public DiverseMeasuringResultsOfASegment(DiverseErrorsOfASegment  diverseErrorsOfASegment)
  {
	  this.experimentNumber = diverseErrorsOfASegment.getExperimentNumber();
	  
	  this.calculateScaleDependentMeasures(diverseErrorsOfASegment);
	  
	  this.calculatePercentageBasedMeasures(diverseErrorsOfASegment);
	  
	  this.calculateRelativeBasedMeasures(diverseErrorsOfASegment);
	  
	  this.calculateScaleFreeMeasures(diverseErrorsOfASegment);
  }
  
  private void calculateScaleDependentMeasures(DiverseErrorsOfASegment  diverseErrorsOfASegment)
  {
	  this.trainingMeanAbsoluteError = this.calculateMean(diverseErrorsOfASegment.getTrainingAbsoluteErrors());
	  this.testingMeanAbsoluteError = this.calculateMean(diverseErrorsOfASegment.getTestingAbsoluteErrors());
	  
	  this.trainingGeometricMeanAbsoluteError = this.calculateGeometricMean(diverseErrorsOfASegment.getTrainingAbsoluteErrors());
	  this.testingGeometricMeanAbsoluteError = this.calculateGeometricMean(diverseErrorsOfASegment.getTestingAbsoluteErrors());
	  
	  this.trainingMedianAbsoluteError = this.calculateMedian(diverseErrorsOfASegment.getTrainingAbsoluteErrors());
	  this.testingMedianAbsoluteError = this.calculateMedian(diverseErrorsOfASegment.getTestingAbsoluteErrors());
	  
	  this.trainingMeanSquaredError = this.calculateMean(diverseErrorsOfASegment.getTrainingSquaredErrors());
	  this.testingMeanSquaredError = this.calculateMean(diverseErrorsOfASegment.getTestingSquaredErrors());
	  
	  this.trainingRootMeanSquaredError = this.calculateRootMean(diverseErrorsOfASegment.getTrainingSquaredErrors());
	  this.testingRootMeanSquaredError = this.calculateRootMean(diverseErrorsOfASegment.getTestingSquaredErrors());
  }
  
  private void calculatePercentageBasedMeasures(DiverseErrorsOfASegment  diverseErrorsOfASegment)
  {
	  this.trainingMeanAbsolutePercentageError = this.calculateMean(diverseErrorsOfASegment.getTrainingAbsolutePercentageErrors());
	  this.testingMeanAbsolutePercentageError = this.calculateMean(diverseErrorsOfASegment.getTestingAbsolutePercentageErrors());
	  
	  this.trainingMedianAbsolutePercentageError = this.calculateMedian(diverseErrorsOfASegment.getTrainingAbsolutePercentageErrors());
	  this.testingMedianAbsolutePercentageError = this.calculateMedian(diverseErrorsOfASegment.getTestingAbsolutePercentageErrors());
	  
	  this.trainingRootMeanSquaredPercentageError = this.calculateRootMean(diverseErrorsOfASegment.getTrainingSquaredPercentageErrors());  
	  this.testingRootMeanSquaredPercentageError = this.calculateRootMean(diverseErrorsOfASegment.getTestingSquaredPercentageErrors());  
	  
	  this.trainingRootMedianSquaredPercentageError = this.calculateRootMedian(diverseErrorsOfASegment.getTrainingSquaredPercentageErrors());
	  this.testingRootMedianSquaredPercentageError = this.calculateRootMedian(diverseErrorsOfASegment.getTestingSquaredPercentageErrors());
	  
	  this.trainingSymmetricMeanAbsolutePercentageError = this.calculateMean(diverseErrorsOfASegment.getTrainingSymmetricAbsolutePercentageErrors());
	  this.testingSymmetricMeanAbsolutePercentageError = this.calculateMean(diverseErrorsOfASegment.getTestingSymmetricAbsolutePercentageErrors());
	  
	  this.trainingSymmetricMedianAbsolutePercentageError = this.calculateMedian(diverseErrorsOfASegment.getTrainingSymmetricAbsolutePercentageErrors());
	  this.testingSymmetricMedianAbsolutePercentageError = this.calculateMedian(diverseErrorsOfASegment.getTestingSymmetricAbsolutePercentageErrors());
  }
  
  private void calculateRelativeBasedMeasures(DiverseErrorsOfASegment  diverseErrorsOfASegment)
  {
	  this.trainingMeanRelativeAbsoluteError = this.calculateMean(diverseErrorsOfASegment.getTrainingAbsoluteRelativeErrors());
	  this.testingMeanRelativeAbsoluteError = this.calculateMean(diverseErrorsOfASegment.getTestingAbsoluteRelativeErrors());
	  
	  this.trainingMedianRelativeAbsoluteError = this.calculateMedian(diverseErrorsOfASegment.getTrainingAbsoluteRelativeErrors());
	  this.testingMedianRelativeAbsoluteError = this.calculateMedian(diverseErrorsOfASegment.getTrainingAbsoluteRelativeErrors());
	  
	  this.trainingGeometricMeanRelativeAbsoluteError = this.calculateGeometricMean(diverseErrorsOfASegment.getTrainingAbsoluteRelativeErrors());
	  this.testingGeometricMeanRelativeAbsoluteError = this.calculateGeometricMean(diverseErrorsOfASegment.getTestingAbsoluteRelativeErrors());
  }
  
  private void calculateScaleFreeMeasures(DiverseErrorsOfASegment  diverseErrorsOfASegment)
  {
	  this.trainingMeanAbsoluteScaledError = this.calculateMean(diverseErrorsOfASegment.getTrainingAbsoluteScaledErrors());
	  this.testingMeanAbsoluteScaledError = this.calculateMean(diverseErrorsOfASegment.getTestingAbsoluteScaledErrors());
	  
	  this.trainingRootMeanSquaredScaledError = this.calculateRootMean(diverseErrorsOfASegment.getTrainingSquaredScaledErrors());
	  this.testingRootMeanSquaredScaledError = this.calculateRootMean(diverseErrorsOfASegment.getTestingSquaredScaledErrors());
	  
	  this.trainingMedianAbsoluteScaledError = this.calculateMedian(diverseErrorsOfASegment.getTrainingAbsoluteScaledErrors()); 
	  this.testingMedianAbsoluteScaledError = this.calculateMedian(diverseErrorsOfASegment.getTestingAbsoluteScaledErrors());
  }
  
  
  private double calculateMean(double[] errors)
  {
	  double accumulation = 0;
	  
	  for(double error:errors)
	  {
		 accumulation = accumulation + error;
	  }
	  
	  return accumulation / errors.length;
  }
  
  private double calculateMedian(double[] errors)
  {
	  double median = 0;
	  
	  if((errors.length % 2) == 0)
	  {
		  median = (errors[(int) ((errors.length / 2) - 1)] + errors[(int) (errors.length / 2)]) / 2;
	  }
	  else
	  {
		  median = errors[(int) Math.floor(errors.length / 2)];
	  }
	
	  return median;
  }
  
  private double calculateGeometricMean(double[] errors)
  {  
	  DescriptiveStatistics stats = new DescriptiveStatistics();
     
      
	  for(double error:errors)
	  {
		if(error == 0 || Double.isNaN(error) || Double.isInfinite(error))
		{ 
		   error = 0;
		}  
		 
		stats.addValue(error);
	
	  }
	  
	  return stats.getGeometricMean();
  }
  
  private double calculateRootMean(double[] errors)
  {
	  return Math.sqrt(this.calculateMean(errors));
  }
  
  private double calculateRootMedian(double[] errors)
  {
	  return Math.sqrt(this.calculateMedian(errors));
  }

  
  
  
  public ExperimentNumber getExperimentNumber() 
  {
	return experimentNumber;
  }

  public double getTrainingMeanAbsoluteError() 
  {
	return trainingMeanAbsoluteError;
  }

  public double getTestingMeanAbsoluteError() 
  {
	return testingMeanAbsoluteError;
  }

  public double getTrainingGeometricMeanAbsoluteError()
  {
	return trainingGeometricMeanAbsoluteError;
  }

  public double getTestingGeometricMeanAbsoluteError() 
  {
	return testingGeometricMeanAbsoluteError;
  }

  public double getTrainingMedianAbsoluteError()
  {
	return trainingMedianAbsoluteError;
  }

  public double getTestingMedianAbsoluteError() 
  {
	return testingMedianAbsoluteError;
  }

  public double getTrainingMeanSquaredError()
  {
	return trainingMeanSquaredError;
  }

  public double getTestingMeanSquaredError()
  {
	return testingMeanSquaredError;
  }

  public double getTrainingRootMeanSquaredError() 
  {
	return trainingRootMeanSquaredError;
  }

  public double getTestingRootMeanSquaredError() 
  {
	return testingRootMeanSquaredError;
  }

  public double getTrainingMeanAbsolutePercentageError() 
  {
	return trainingMeanAbsolutePercentageError;
  }

  public double getTestingMeanAbsolutePercentageError()
  {
	return testingMeanAbsolutePercentageError;
  }

  public double getTrainingMedianAbsolutePercentageError() 
  {
	return trainingMedianAbsolutePercentageError;
  }

  public double getTestingMedianAbsolutePercentageError()
  {
	return testingMedianAbsolutePercentageError;
  }

  public double getTrainingRootMeanSquaredPercentageError() 
  {
	return trainingRootMeanSquaredPercentageError;
  }

  public double getTestingRootMeanSquaredPercentageError() 
  {
	return testingRootMeanSquaredPercentageError;
  }

  public double getTrainingRootMedianSquaredPercentageError()
  {
	return trainingRootMedianSquaredPercentageError;
  }

  public double getTestingRootMedianSquaredPercentageError()
  {
	return testingRootMedianSquaredPercentageError;
  }

  public double getTrainingSymmetricMeanAbsolutePercentageError()
  {
	return trainingSymmetricMeanAbsolutePercentageError;
  }

  public double getTestingSymmetricMeanAbsolutePercentageError() 
  {
	return testingSymmetricMeanAbsolutePercentageError;
  }

  public double getTrainingSymmetricMedianAbsolutePercentageError()
  {
	return trainingSymmetricMedianAbsolutePercentageError;
  }

  public double getTestingSymmetricMedianAbsolutePercentageError() 
  {
	return testingSymmetricMedianAbsolutePercentageError;
  }

  public double getTrainingMeanRelativeAbsoluteError() 
  {
	return trainingMeanRelativeAbsoluteError;
  }

  public double getTestingMeanRelativeAbsoluteError() 
  {
	return testingMeanRelativeAbsoluteError;
  }

  public double getTrainingMedianRelativeAbsoluteError() 
  {
	return trainingMedianRelativeAbsoluteError;
  }

  public double getTestingMedianRelativeAbsoluteError()
  {
	return testingMedianRelativeAbsoluteError;
  }

  public double getTrainingGeometricMeanRelativeAbsoluteError()
  {
	return trainingGeometricMeanRelativeAbsoluteError;
  }

  public double getTestingGeometricMeanRelativeAbsoluteError()
  {
	return testingGeometricMeanRelativeAbsoluteError;
  }

  public double getTrainingMeanAbsoluteScaledError() 
  {
	return trainingMeanAbsoluteScaledError;
  }

  public double getTestingMeanAbsoluteScaledError() 
  {
	return testingMeanAbsoluteScaledError;
  }

  public double getTrainingRootMeanSquaredScaledError() 
  {
	return trainingRootMeanSquaredScaledError;
  }

  public double getTestingRootMeanSquaredScaledError() 
  {
	return testingRootMeanSquaredScaledError;
  }

  public double getTrainingMedianAbsoluteScaledError()
  {
	return trainingMedianAbsoluteScaledError;
  }

  public double getTestingMedianAbsoluteScaledError()
  {
	return testingMedianAbsoluteScaledError;
  }
}
