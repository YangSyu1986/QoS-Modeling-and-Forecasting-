package Utilities.ForecastingCostMeasures;

import Utilities.DataStructures.ExperimentNumber;

public class TimeCost 
{
   private ExperimentNumber experimentNumber;	
	
   private double predictorProductionTime;
   
   private double trainingForecastsProductionTime;
   private double testingForecastsProductionTime;
   
   
   public TimeCost(ExperimentNumber experimentNumber, double predictorProductionTime, double trainingForecastsProductionTime, double testingForecastsProductionTime)
   {
	   this.experimentNumber = experimentNumber;
	   
	   this.predictorProductionTime = predictorProductionTime;
	   
	   this.trainingForecastsProductionTime = trainingForecastsProductionTime;
	   this.testingForecastsProductionTime = testingForecastsProductionTime;
   }

   

   public ExperimentNumber getExperimentNumber()
   {
	   return experimentNumber;
   }



   public double getPredictorProductionTime() 
   {
	   return predictorProductionTime;
   }
   
 
   public double getTrainingForecastsProductionTime() 
   {
	   return this.trainingForecastsProductionTime;
   }  

   public double getTestingForecastsProductionTime() 
   {
	   return this.testingForecastsProductionTime;
   }  
}
