package Utilities.Painters;

import java.io.File;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.List;

import org.rosuda.JRI.Rengine;

import Utilities.DataStructures.ForecastingOutcomeOfASegment;
import Utilities.ForecastingAccuracyMeasures.DiverseErrorsOfASegment;

public class DiverseErrorsPlotPainterInR 
{
	Rengine re;
	  
	String rootDirectoryPath;
	
	List<DiverseErrorsOfASegment[][]> outcomeOfDiverseMethods_DiverseErrors;
	
	
	public DiverseErrorsPlotPainterInR(String filePath, String directoryName, List<DiverseErrorsOfASegment[][]> outcomeOfDiverseMethods_DiverseErrors)
	{
		  this.re = Rengine.getMainEngine();
		    
		  if(this.re == null)
		  {
		    this.re = new Rengine(new String[] {"--vanilla"}, false, null);
		  }
		    
		  if (!this.re.waitForR()) 
		  {
		    System.out.println("Cannot load R");
		  }
		    
		  
		  this.rootDirectoryPath = filePath + "/" + directoryName;
		  this.outcomeOfDiverseMethods_DiverseErrors = outcomeOfDiverseMethods_DiverseErrors;	
	}
	
	
	public void plot()
	{
		System.out.println("Draw Diverse Errors Plots");
		
		this.createDirectories();
	    this.drawDiverseErrorsPlots();
	    
	    System.out.println("Done !!");
	}
	
	
	private void createDirectories()
	{
		this.makeDirectory(this.rootDirectoryPath);	
			
		for(int i = 0; i < this.outcomeOfDiverseMethods_DiverseErrors.get(0).length; i++)
		{
		   for(int j = 0 ; j < this.outcomeOfDiverseMethods_DiverseErrors.get(0)[i].length; j++)
		   {
		      String secondDirectoryPath = this.rootDirectoryPath + "/" + "TS" + i +" Seg." + j;
		      this.makeDirectory(secondDirectoryPath);
		      
		      String trainingResults = secondDirectoryPath + "/" + "Training";
			  this.makeDirectory(trainingResults);
			      
			  String testingResults = secondDirectoryPath + "/" + "Testing";
			  this.makeDirectory(testingResults);
		      
			  
		      for(int k = 0; k < this.outcomeOfDiverseMethods_DiverseErrors.size(); k++)
		      {
		    	 this.makeDirectory(trainingResults + "/" + this.outcomeOfDiverseMethods_DiverseErrors.get(k)[0][0].getExperimentNumber().getMethodName());     
		    	  
		    	 this.makeDirectory(testingResults + "/" + this.outcomeOfDiverseMethods_DiverseErrors.get(k)[0][0].getExperimentNumber().getMethodName());
		      }
		   }
		}
	}
	  
	private void makeDirectory(String directoryPath)
	{    
	   File directory = new File(directoryPath);
	   directory.mkdir();  
	}
	
	
	
	private void drawDiverseErrorsPlots() 
	{
		for(int i = 0; i < this.outcomeOfDiverseMethods_DiverseErrors.get(0).length; i++)
		{
		   for(int j = 0 ; j < this.outcomeOfDiverseMethods_DiverseErrors.get(0)[i].length; j++)
		   { 
			  String trainingResultsPath = this.rootDirectoryPath + "/" + "TS" + i +" Seg." + j+ "/" + "Training/";
			  String testingResultsPath = this.rootDirectoryPath + "/" + "TS" + i +" Seg." + j+ "/" + "Testing/"; 
			  
			   
			  for(int k = 0; k < this.outcomeOfDiverseMethods_DiverseErrors.size(); k++)//draw plots for individual methods (their forecasts)
			  {
				  String methodName = this.outcomeOfDiverseMethods_DiverseErrors.get(k)[i][j].getExperimentNumber().getMethodName();
				  
			      
			      this.drawErrorsPlot(trainingResultsPath + methodName + "/", "Absolute Errors", this.outcomeOfDiverseMethods_DiverseErrors.get(k)[i][j].getTrainingAbsoluteErrors());
			      this.drawErrorsPlot(trainingResultsPath + methodName + "/", "Squared Errors", this.outcomeOfDiverseMethods_DiverseErrors.get(k)[i][j].getTrainingSquaredErrors());
			      this.drawErrorsPlot(trainingResultsPath + methodName + "/", "Absolute Percentage Errors", this.outcomeOfDiverseMethods_DiverseErrors.get(k)[i][j].getTrainingAbsolutePercentageErrors());
			      this.drawErrorsPlot(trainingResultsPath + methodName + "/", "Squared Percentage Errors", this.outcomeOfDiverseMethods_DiverseErrors.get(k)[i][j].getTrainingSquaredPercentageErrors());
			      this.drawErrorsPlot(trainingResultsPath + methodName + "/", "Symmetric Absolute Percentage Errors", this.outcomeOfDiverseMethods_DiverseErrors.get(k)[i][j].getTrainingSymmetricAbsolutePercentageErrors());
			      this.drawErrorsPlot(trainingResultsPath + methodName + "/", "Absolute Relative Errors", this.outcomeOfDiverseMethods_DiverseErrors.get(k)[i][j].getTrainingAbsoluteRelativeErrors());
			      this.drawErrorsPlot(trainingResultsPath + methodName + "/", "Absolute Scaled Errors", this.outcomeOfDiverseMethods_DiverseErrors.get(k)[i][j].getTrainingAbsoluteScaledErrors());
			      this.drawErrorsPlot(trainingResultsPath + methodName + "/", "Squared Scaled Errors", this.outcomeOfDiverseMethods_DiverseErrors.get(k)[i][j].getTrainingSquaredScaledErrors());
				  
			      
			      this.drawErrorsPlot(testingResultsPath + methodName + "/", "Absolute Errors", this.outcomeOfDiverseMethods_DiverseErrors.get(k)[i][j].getTestingAbsoluteErrors());
			      this.drawErrorsPlot(testingResultsPath + methodName + "/", "Squared Errors", this.outcomeOfDiverseMethods_DiverseErrors.get(k)[i][j].getTestingSquaredErrors());
			      this.drawErrorsPlot(testingResultsPath + methodName + "/", "Absolute Percentage Errors", this.outcomeOfDiverseMethods_DiverseErrors.get(k)[i][j].getTestingAbsolutePercentageErrors());
			      this.drawErrorsPlot(testingResultsPath + methodName + "/", "Squared Percentage Errors", this.outcomeOfDiverseMethods_DiverseErrors.get(k)[i][j].getTestingSquaredPercentageErrors());
			      this.drawErrorsPlot(testingResultsPath + methodName + "/", "Symmetric Absolute Percentage Errors", this.outcomeOfDiverseMethods_DiverseErrors.get(k)[i][j].getTestingSymmetricAbsolutePercentageErrors());
			      this.drawErrorsPlot(testingResultsPath + methodName + "/", "Absolute Relative Errors", this.outcomeOfDiverseMethods_DiverseErrors.get(k)[i][j].getTestingAbsoluteRelativeErrors());
			      this.drawErrorsPlot(testingResultsPath + methodName + "/", "Absolute Scaled Errors", this.outcomeOfDiverseMethods_DiverseErrors.get(k)[i][j].getTestingAbsoluteScaledErrors());
			      this.drawErrorsPlot(testingResultsPath + methodName + "/", "Squared Scaled Errors", this.outcomeOfDiverseMethods_DiverseErrors.get(k)[i][j].getTestingSquaredScaledErrors());
			  }
		   }
		}
	}
	
	private void drawErrorsPlot(String plotPath, String errorsType, double[] errors)
	{	
	   this.re.assign("errors", errors);       
	   this.re.eval("errorsTS<-ts(errors)");
	    
	   this.re.eval("png(filename=\"" + plotPath + "/" + errorsType +".png\")");
	    
	   this.re.eval("plot(errorsTS, main=\""+ errorsType +" Plot\", xlab=\"Time Points\", ylab=\"Error Value\", col = \"black\")");
	   this.re.eval("legend(\"topright\",box.lty = 0, col=c(\"black\"),lty=1,legend=c(\""+ errorsType +"\"))");
	   this.re.eval("dev.off()");
	}
}
