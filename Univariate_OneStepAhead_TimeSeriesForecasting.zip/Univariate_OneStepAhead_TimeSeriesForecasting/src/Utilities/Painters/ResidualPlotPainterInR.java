package Utilities.Painters;

import java.io.File;
import java.lang.reflect.InvocationTargetException;
import java.util.List;

import org.rosuda.JRI.Rengine;

import Utilities.DataStructures.ForecastingOutcomeOfASegment;
import Utilities.DataStructures.Residuals;

public class ResidualPlotPainterInR 
{
	Rengine re;
	  
	String rootDirectoryPath;
	
	List<Residuals[][]> outcomeOfDiverseMethods_Residuals;
	
	
	public ResidualPlotPainterInR(String filePath, String directoryName, List<Residuals[][]> outcomeOfDiverseMethods_Residuals)
	{
		  this.re = Rengine.getMainEngine();
		    
		  if(this.re == null)
		  {
		    this.re = new Rengine(new String[] {"--vanilla"}, false, null);
		  }
		    
		  if (!this.re.waitForR()) 
		  {
		    System.out.println("Cannot load R");
		  }
		  
		  this.re.eval("library(\"forecast\")");//loading package "forecast"
		    
		  
		  this.rootDirectoryPath = filePath + "/" + directoryName;
		  this.outcomeOfDiverseMethods_Residuals = outcomeOfDiverseMethods_Residuals;	
	}
	
	
	public void plot()
	{
		this.createDirectories();
		this.drawResidualPlots();
	}
	
	
	private void createDirectories()
	{
		this.makeDirectory(this.rootDirectoryPath);	
			
		for(int i = 0; i < this.outcomeOfDiverseMethods_Residuals.get(0).length; i++)
		{
		   for(int j = 0 ; j < this.outcomeOfDiverseMethods_Residuals.get(0)[i].length; j++)
		   {
		      String secondDirectoryPath = this.rootDirectoryPath + "/" + "TS" + i +" Seg." + j;
		      this.makeDirectory(secondDirectoryPath);
		      
		      String trainingResults = secondDirectoryPath + "/" + "Training";
		      this.makeDirectory(trainingResults);
		      this.makeDirectory(trainingResults + "/ResidualPlots");
		      this.makeDirectory(trainingResults + "/ACFPlots");
		      this.makeDirectory(trainingResults + "/HistogramPlots");

		      
		      
		      String testingResults = secondDirectoryPath + "/" + "Testing";
		      this.makeDirectory(testingResults);
		      this.makeDirectory(testingResults + "/ResidualPlots");
		      this.makeDirectory(testingResults + "/ACFPlots");
		      this.makeDirectory(testingResults + "/HistogramPlots");
		   }
		}
	}
	  
	
	private void makeDirectory(String directoryPath)
	{    
	   File directory = new File(directoryPath);
	   directory.mkdir();  
	}
	
	
	private void drawResidualPlots() 
	{
		String trainingResultsPath;
		String testingResultsPath;
		
		String residualInstruction = "plot(residualsTS, main=\"Residuals Plot\", xlab=\"Time Points\", ylab=\"Value\", col = \"black\")";
		String ACFInstruction = "Acf(residualsTS, main=\"ACF of Residuals\")";
		String histogramInstruction = "hist(residualsTS, nclass = \"FD\", main=\"Histogram of Residuals\")";
		
		
		for(int i = 0; i < this.outcomeOfDiverseMethods_Residuals.get(0).length; i++)
		{
		   for(int j = 0 ; j < this.outcomeOfDiverseMethods_Residuals.get(0)[i].length; j++)
		   { 
			  trainingResultsPath = this.rootDirectoryPath + "/" + "TS" + i +" Seg." + j+ "/" + "Training/";
			  testingResultsPath = this.rootDirectoryPath + "/" + "TS" + i +" Seg." + j+ "/" + "Testing/"; 
			  
			   
			  for(int k = 0; k < this.outcomeOfDiverseMethods_Residuals.size(); k++)//draw plots for individual methods (their forecasts)
			  {
				  String methodName = this.outcomeOfDiverseMethods_Residuals.get(k)[i][j].getExperimentNumber().getMethodName();
				
			      this.drawPlot(trainingResultsPath + "ResidualPlots/", methodName, residualInstruction, this.outcomeOfDiverseMethods_Residuals.get(k)[i][j].getExperimentNumber().getRepeatNumber(), this.outcomeOfDiverseMethods_Residuals.get(k)[i][j].getTrainingResiduals());
				  
			      this.drawPlot(testingResultsPath + "ResidualPlots/", methodName, residualInstruction, this.outcomeOfDiverseMethods_Residuals.get(k)[i][j].getExperimentNumber().getRepeatNumber(),this.outcomeOfDiverseMethods_Residuals.get(k)[i][j].getTestingResiduals());
			 
			     
			      this.drawPlot(trainingResultsPath + "ACFPlots/", methodName, ACFInstruction, this.outcomeOfDiverseMethods_Residuals.get(k)[i][j].getExperimentNumber().getRepeatNumber(), this.outcomeOfDiverseMethods_Residuals.get(k)[i][j].getTrainingResiduals());
				  
			      this.drawPlot(testingResultsPath + "ACFPlots/", methodName, ACFInstruction, this.outcomeOfDiverseMethods_Residuals.get(k)[i][j].getExperimentNumber().getRepeatNumber(),this.outcomeOfDiverseMethods_Residuals.get(k)[i][j].getTestingResiduals());
			 
			      
                  this.drawPlot(trainingResultsPath + "HistogramPlots/", methodName, histogramInstruction, this.outcomeOfDiverseMethods_Residuals.get(k)[i][j].getExperimentNumber().getRepeatNumber(), this.outcomeOfDiverseMethods_Residuals.get(k)[i][j].getTrainingResiduals());
				  
			      this.drawPlot(testingResultsPath + "HistogramPlots/", methodName, histogramInstruction, this.outcomeOfDiverseMethods_Residuals.get(k)[i][j].getExperimentNumber().getRepeatNumber(),this.outcomeOfDiverseMethods_Residuals.get(k)[i][j].getTestingResiduals());
			 
			  }
		   }
		}
	}
	
	
	private void drawPlot(String plotPath, String methodName, String RInstruction, int repeatNumber,  double[] residuals)
	{
		this.re.assign("residuals", residuals);       
	    this.re.eval("residualsTS<-ts(residuals)");
	   
	    
	    if(methodName.contains("GP"))
	    {
	      this.re.eval("png(filename=\"" + plotPath + methodName + "_" + repeatNumber +".png\")");
	    }
	    else
	    {
	      this.re.eval("png(filename=\"" + plotPath + methodName +".png\")");
	    }
	    
	    this.re.eval(RInstruction);
	    this.re.eval("dev.off()");
	}
}
