package Utilities.Painters;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;

import org.rosuda.JRI.Rengine;

import Utilities.DataStructures.ForecastingOutcomeOfASegment;


public class ForecastsAndObservationsPlotPainterInR 
{
	Rengine re;
	  
	String rootDirectoryPath;
	
	List<ForecastingOutcomeOfASegment[][]> outcomeOfDiverseMethods_ForecastingOutcomes;
	
	public ForecastsAndObservationsPlotPainterInR(String filePath, String directoryName, List<ForecastingOutcomeOfASegment[][]> outcomeOfDiverseMethods_ForecastingOutcomes)
	{
		  this.re = Rengine.getMainEngine();
		    
		  if(this.re == null)
		  {
		    this.re = new Rengine(new String[] {"--vanilla"}, false, null);
		  }
		    
		  if (!this.re.waitForR()) 
		  {
		    System.out.println("Cannot load R");
		  }
		    
		  
		  this.rootDirectoryPath = filePath + "/" + directoryName;
		  this.outcomeOfDiverseMethods_ForecastingOutcomes = outcomeOfDiverseMethods_ForecastingOutcomes;	
	}
	
	
	public void plot() throws NoSuchMethodException, SecurityException, IllegalAccessException, IllegalArgumentException, InvocationTargetException, FileNotFoundException
	{
		System.out.println("Draw Forecasts and Observations Plots");
		
	    this.createDirectories();
	    this.drawObservationsAndForecastsPlots();
	    
	    System.out.println("Done !!");
	}
	
	
	private void createDirectories()
	{
		this.makeDirectory(this.rootDirectoryPath);	
			
		for(int i = 0; i < this.outcomeOfDiverseMethods_ForecastingOutcomes.get(0).length; i++)
		{
		   for(int j = 0 ; j < this.outcomeOfDiverseMethods_ForecastingOutcomes.get(0)[i].length; j++)
		   {
		      String secondDirectoryPath = this.rootDirectoryPath + "/" + "TS" + i +" Seg." + j;
		      this.makeDirectory(secondDirectoryPath);
		      
		      String trainingResults = secondDirectoryPath + "/" + "Training";
		      this.makeDirectory(trainingResults);
		      
		      String testingResults = secondDirectoryPath + "/" + "Testing";
		      this.makeDirectory(testingResults);
		   }
		}
	}
	  
	
	private void makeDirectory(String directoryPath)
	{    
	   File directory = new File(directoryPath);
	   directory.mkdir();  
	}
	
	
	
	private void drawObservationsAndForecastsPlots() throws NoSuchMethodException, SecurityException, IllegalAccessException, IllegalArgumentException, InvocationTargetException, FileNotFoundException
	{
		for(int i = 0; i < this.outcomeOfDiverseMethods_ForecastingOutcomes.get(0).length; i++)
		{
		   for(int j = 0 ; j < this.outcomeOfDiverseMethods_ForecastingOutcomes.get(0)[i].length; j++)
		   { 
			  String trainingResultsPath = this.rootDirectoryPath + "/" + "TS" + i +" Seg." + j+ "/" + "Training/";
			  String testingResultsPath = this.rootDirectoryPath + "/" + "TS" + i +" Seg." + j+ "/" + "Testing/"; 
			  
			   
			  for(int k = 0; k < this.outcomeOfDiverseMethods_ForecastingOutcomes.size(); k++)//draw plots for individual methods (their forecasts)
			  {
				  String methodName = this.outcomeOfDiverseMethods_ForecastingOutcomes.get(k)[i][j].getExperimentNumber().getMethodName();
				  
			      //drawing plots
			      this.drawObservationsAndForecastsPlot_ResultsOfSingleForecastingMetodh(trainingResultsPath, methodName, this.outcomeOfDiverseMethods_ForecastingOutcomes.get(k)[i][j].getExperimentNumber().getRepeatNumber(), this.outcomeOfDiverseMethods_ForecastingOutcomes.get(k)[i][j].getTrainingObservations(), this.outcomeOfDiverseMethods_ForecastingOutcomes.get(k)[i][j].getTrainingPredictions());
				  
			      this.drawObservationsAndForecastsPlot_ResultsOfSingleForecastingMetodh(testingResultsPath, methodName, this.outcomeOfDiverseMethods_ForecastingOutcomes.get(k)[i][j].getExperimentNumber().getRepeatNumber(),this.outcomeOfDiverseMethods_ForecastingOutcomes.get(k)[i][j].getTestingObservations(), this.outcomeOfDiverseMethods_ForecastingOutcomes.get(k)[i][j].getTestingPredictions());
			  
			   
			      //writing files
                  this.writeObservationsAndForecasts_ResultsOfSingleForecastingMetodh(trainingResultsPath, methodName, this.outcomeOfDiverseMethods_ForecastingOutcomes.get(k)[i][j].getExperimentNumber().getRepeatNumber(), this.outcomeOfDiverseMethods_ForecastingOutcomes.get(k)[i][j].getTrainingObservations(), this.outcomeOfDiverseMethods_ForecastingOutcomes.get(k)[i][j].getTrainingPredictions());
				  
			      this.writeObservationsAndForecasts_ResultsOfSingleForecastingMetodh(testingResultsPath, methodName, this.outcomeOfDiverseMethods_ForecastingOutcomes.get(k)[i][j].getExperimentNumber().getRepeatNumber(),this.outcomeOfDiverseMethods_ForecastingOutcomes.get(k)[i][j].getTestingObservations(), this.outcomeOfDiverseMethods_ForecastingOutcomes.get(k)[i][j].getTestingPredictions());
			  
			  }
			  
			  
			  List<ForecastingOutcomeOfASegment> forecastingResultsOfAllMethods = this.extractForecastingOutcomeOfAllMethods(i, j);
			  
			  this.drawObservationsAndForecastsPlot_ResultsOfAllForecastingMetodh(trainingResultsPath, "Training",forecastingResultsOfAllMethods);
			  this.drawObservationsAndForecastsPlot_ResultsOfAllForecastingMetodh(testingResultsPath, "Testing", forecastingResultsOfAllMethods);
		   }
		}
	}
	
	//for drawing plots
	private void drawObservationsAndForecastsPlot_ResultsOfSingleForecastingMetodh(String plotPath, String methodName, int repeatNumber,  double[] observations, double[] predictions)
	{
		this.re.assign("observations", observations);       
	    this.re.eval("observationsTS<-ts(observations)");
	    
	    this.re.assign("predictions", predictions);       
	    this.re.eval("predictionsTS<-ts(predictions)");
	    
	    if(methodName.contains("GP"))
	    {
	      this.re.eval("png(filename=\"" + plotPath + methodName + "_" + repeatNumber +".png\")");
	    }
	    else
	    {
	      this.re.eval("png(filename=\"" + plotPath + methodName +".png\")");
	    }
	    
	    this.re.eval("plot(observationsTS, main=\"Time Series Plot\", xlab=\"Time Points\", ylab=\"Value\", col = \"black\")");
	    this.re.eval("lines(predictionsTS, col = \"red\")");
	    this.re.eval("legend(\"topright\",box.lty = 0, col=c(\"black\",\"red\"),lty=1,legend=c(\"Observations\",\"Predictions\"))");
	    this.re.eval("dev.off()");
	}
	
	//for writing text files
	private void writeObservationsAndForecasts_ResultsOfSingleForecastingMetodh(String filePath, String methodName, int repeatNumber,  double[] observations, double[] predictions) throws FileNotFoundException
	{
		PrintWriter writer; 
		
		if(methodName.contains("GP"))
	    {
		  writer = new PrintWriter(filePath + methodName + "_" + repeatNumber + ".txt\"");  
	    }
	    else
	    {
	      writer = new PrintWriter(filePath + methodName + "_" + ".txt\"");  
	    }
		
		
	  	  
		writer.println("Observations" + "  and   " + "Predictions");
		
	    for(int i = 0; i < observations.length; i++)
	    {
	      writer.println(i + ":  " + observations[i] + "   " + predictions[i]);
	    }
   	 
	    writer.close();
	}
	
	
	private List<ForecastingOutcomeOfASegment> extractForecastingOutcomeOfAllMethods(int timeSeries, int segment)
	{
		List<ForecastingOutcomeOfASegment> results = new ArrayList<ForecastingOutcomeOfASegment>();
		
		for(ForecastingOutcomeOfASegment[][] square:this.outcomeOfDiverseMethods_ForecastingOutcomes)
		{
			results.add(square[timeSeries][segment]);
		}
		
		return results;
	}
	
	private void drawObservationsAndForecastsPlot_ResultsOfAllForecastingMetodh(String plotPath, String type, List<ForecastingOutcomeOfASegment> forecastingResultsOfAllMethods) throws NoSuchMethodException, SecurityException, IllegalAccessException, IllegalArgumentException, InvocationTargetException
	{
		Method method = forecastingResultsOfAllMethods.get(0).getClass().getMethod("get" + type + "Observations", null);
		double[] observations = (double[]) method.invoke(forecastingResultsOfAllMethods.get(0), null); 
		
		this.re.assign("observations", observations);       
	    this.re.eval("observationsTS<-ts(observations)");
	    
	    this.re.eval("png(filename=\"" + plotPath + "ALL.png\")");
	    this.re.eval("plot(observationsTS, main=\"Time Series Plot\", xlab=\"Time Points\", ylab=\"Value\", col = 1)");
	  
	    
	    String methodNames = "";
	    String lineColorIndices = "";
	    
	    for(int i = 0; i < forecastingResultsOfAllMethods.size(); i++)
	    {
	    	//if(methodNames.equals("GP") && forecastingResultsOfAllMethods.get(i).getExperimentNumber().getRepeatNumber()!=0){continue;}//only draw the line of first repeat
	    	
	    	
	    	method = forecastingResultsOfAllMethods.get(i).getClass().getMethod("get" + type + "Predictions", null);
			double[] predictions = (double[]) method.invoke(forecastingResultsOfAllMethods.get(i), null); 
	    	
	    	this.re.assign("predictions", predictions);       
	 	    this.re.eval("predictionsTS<-ts(predictions)");
	 	    
	 	    this.re.eval("lines(predictionsTS, col = " + (i + 2) + ")");
	 	    
	 	    
	 	    if(forecastingResultsOfAllMethods.get(i).getExperimentNumber().getMethodName().contains("GP"))
	 	    {
	 	      methodNames = methodNames + ", \"" + forecastingResultsOfAllMethods.get(i).getExperimentNumber().getMethodName() + "_" + forecastingResultsOfAllMethods.get(i).getExperimentNumber().getRepeatNumber() + "\"";
	 	    }
	 	    else
	 	    {
	 	      methodNames = methodNames + ", \"" + forecastingResultsOfAllMethods.get(i).getExperimentNumber().getMethodName() + "\"";  
	 	    }
	 	  
	 	    lineColorIndices = lineColorIndices + "," + (i + 2);
	    }
	      //legend outside the plot
	    //this.re.eval("legend(x = -1, y = -1, xpd = TRUE, col=c(1 " + lineColorIndices + "),lty=1,legend=c(\"Observations\""+ methodNames +"))");
	      //legend inside the plot
	    this.re.eval("legend(\"topright\", col=c(1 " + lineColorIndices + "),lty=1,legend=c(\"Observations\""+ methodNames +"))");
	    this.re.eval("dev.off()");
	}
}
