package Utilities.Painters;

import java.io.File;
import java.io.FileOutputStream;
import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.List;

import org.rosuda.JRI.Rengine;

import Utilities.DatasetProcessingModules.ObservationsAtOneTimePoint;
import Utilities.ForecastingAccuracyMeasures.DiverseErrorsOfASegment;

public class BoxplotsPainterInR 
{
  Rengine re;
	  
  String rootDirectoryPath;
	
  List<DiverseErrorsOfASegment[][]> outcomeOfDiverseMethods_DiverseErrors;	
	

  public BoxplotsPainterInR(String filePath, String directoryName, List<DiverseErrorsOfASegment[][]> outcomeOfDiverseMethods_DiverseErrors)
  {
	  this.re = Rengine.getMainEngine();
	    
	  if(this.re == null)
	  {
	    this.re = new Rengine(new String[] {"--vanilla"}, false, null);
	  }
	    
	  if (!this.re.waitForR()) 
	  {
	    System.out.println("Cannot load R");
	  }
	    
	  
	  this.rootDirectoryPath = filePath + "/" + directoryName;
	  this.outcomeOfDiverseMethods_DiverseErrors = outcomeOfDiverseMethods_DiverseErrors;
  }
  
  
  public void plot() throws IllegalAccessException, IllegalArgumentException, InvocationTargetException, NoSuchMethodException, SecurityException
  {
	System.out.println("Draw Boxplots");  
	  
	this.createDirectories();  
	this.plotBoxplots();
	
	System.out.println("Done !!");
  }
  
  
  
  private void createDirectories()
  {
	this.makeDirectory(this.rootDirectoryPath);	
		
	for(int i = 0; i < this.outcomeOfDiverseMethods_DiverseErrors.get(0).length; i++)
	{
	   for(int j = 0 ; j < this.outcomeOfDiverseMethods_DiverseErrors.get(0)[i].length; j++)
	   {
	      String secondDirectoryPath = this.rootDirectoryPath + "/" + "TS" + i +" Seg." + j;
	      this.makeDirectory(secondDirectoryPath);
	   }
	}
  }
  
  private void makeDirectory(String directoryPath)
  {    
	File directory = new File(directoryPath);
	directory.mkdir();  
  }
  
  
  private void plotBoxplots() throws IllegalAccessException, IllegalArgumentException, InvocationTargetException, NoSuchMethodException, SecurityException
  {
	  List<DiverseErrorsOfASegment>  diverseErrorsOfASegment_DiverseMethods; 
	  
	  for(int i = 0; i < this.outcomeOfDiverseMethods_DiverseErrors.get(0).length; i++)
	  {
		  for(int j = 0 ; j <  this.outcomeOfDiverseMethods_DiverseErrors.get(0)[i].length; j++)
		  {
			 diverseErrorsOfASegment_DiverseMethods = new ArrayList<DiverseErrorsOfASegment>(); 
			  
			 for(int k = 0; k < this.outcomeOfDiverseMethods_DiverseErrors.size(); k++)//different methods on the same segment
			 {
			    diverseErrorsOfASegment_DiverseMethods.add((this.outcomeOfDiverseMethods_DiverseErrors.get(k))[i][j]); 
			 }
			 
			 
			 //this.plotBoxplotsForDiverseErrorsOfASegment(diverseErrorsOfASegment_DiverseMethods, i, j, "TrainingAbsoluteErrors");
			 //this.plotBoxplotsForDiverseErrorsOfASegment(diverseErrorsOfASegment_DiverseMethods, i, j, "TrainingSquaredErrors");
			 this.plotBoxplotsForDiverseErrorsOfASegment(diverseErrorsOfASegment_DiverseMethods, i, j, "TrainingAbsolutePercentageErrors");
//these two are problematic			// this.plotBoxplotsForDiverseErrorsOfASegment(diverseErrorsOfASegment_DiverseMethods, i, j, "TrainingSquaredPercentageErrors");
			 //this.plotBoxplotsForDiverseErrorsOfASegment(diverseErrorsOfASegment_DiverseMethods, i, j, "TrainingSymmetricAbsolutePercentageErrors");
			 //this.plotBoxplotsForDiverseErrorsOfASegment(diverseErrorsOfASegment_DiverseMethods, i, j, "TrainingAbsoluteRelativeErrors");
			 this.plotBoxplotsForDiverseErrorsOfASegment(diverseErrorsOfASegment_DiverseMethods, i, j, "TrainingAbsoluteScaledErrors");
			// this.plotBoxplotsForDiverseErrorsOfASegment(diverseErrorsOfASegment_DiverseMethods, i, j, "TrainingSquaredScaledErrors");
			
			 //this.plotBoxplotsForDiverseErrorsOfASegment(diverseErrorsOfASegment_DiverseMethods, i, j, "TestingAbsoluteErrors");
			 //this.plotBoxplotsForDiverseErrorsOfASegment(diverseErrorsOfASegment_DiverseMethods, i, j, "TestingSquaredErrors");
			 this.plotBoxplotsForDiverseErrorsOfASegment(diverseErrorsOfASegment_DiverseMethods, i, j, "TestingAbsolutePercentageErrors");
			// this.plotBoxplotsForDiverseErrorsOfASegment(diverseErrorsOfASegment_DiverseMethods, i, j, "TestingSquaredPercentageErrors");
			 //this.plotBoxplotsForDiverseErrorsOfASegment(diverseErrorsOfASegment_DiverseMethods, i, j, "TestingSymmetricAbsolutePercentageErrors");
			 //this.plotBoxplotsForDiverseErrorsOfASegment(diverseErrorsOfASegment_DiverseMethods, i, j, "TestingAbsoluteRelativeErrors");
			 this.plotBoxplotsForDiverseErrorsOfASegment(diverseErrorsOfASegment_DiverseMethods, i, j, "TestingAbsoluteScaledErrors");
			// this.plotBoxplotsForDiverseErrorsOfASegment(diverseErrorsOfASegment_DiverseMethods, i, j, "TestingSquaredScaledErrors");	
		  }
	  } 
  }
  
  
  private void plotBoxplotsForDiverseErrorsOfASegment(List<DiverseErrorsOfASegment>  diverseErrorsOfASegment_DiverseMethods, int timeseriesNumber, int segmentNumber, String errorName) throws IllegalAccessException, IllegalArgumentException, InvocationTargetException, NoSuchMethodException, SecurityException
  {
	  String commandForR = "";
	  int numberOfErrorPoints = 0;
	  
	  for(int i = 0; i < ((double[])(diverseErrorsOfASegment_DiverseMethods.get(0).getClass().getMethod("get" + errorName, null).invoke(diverseErrorsOfASegment_DiverseMethods.get(0), null))).length; i++)//different error points
	  { 
		 commandForR = "EP" + i + " <- c(";  
		   
		 for(int j = 0; j < diverseErrorsOfASegment_DiverseMethods.size(); j++)//different methods
		 {
			if((diverseErrorsOfASegment_DiverseMethods.get(j).getExperimentNumber().getMethodName().contains("Select")||diverseErrorsOfASegment_DiverseMethods.get(j).getExperimentNumber().getMethodName().contains("GARCH"))&&errorName.contains("Training"))
			{continue;}//do not draw boxplots for cross-approach selection approaches' modeling/training performance 
		    
			
		    if(j > 0)
			{
			  commandForR = commandForR + ",";
			}
		 
		    commandForR = commandForR + ((double[])(diverseErrorsOfASegment_DiverseMethods.get(j).getClass().getMethod("get" + errorName, null).invoke(diverseErrorsOfASegment_DiverseMethods.get(j), null))) [i];
		 }
		 
		 commandForR = commandForR + ")";
	 
		 numberOfErrorPoints++;
	 
		 this.re.eval(commandForR);
	  }
	
	  
	  //create R data frame
	  commandForR = "all.data = data.frame(rbind(";
	  
	  for(int i = 0; i <  numberOfErrorPoints; i++)
	  {
		commandForR = commandForR + "EP" + i;
		
		if(i < ( numberOfErrorPoints - 1))
		{
		  commandForR = commandForR + ",";
		}
	  }
	  
	  commandForR = commandForR + "))";

	  this.re.eval(commandForR);
	  
	  
	  //replace column names to method names
	  commandForR = "";
	  
	  for(int i = 0 ; i < diverseErrorsOfASegment_DiverseMethods.size(); i++)
	  {
		if((diverseErrorsOfASegment_DiverseMethods.get(i).getExperimentNumber().getMethodName().contains("Select")||diverseErrorsOfASegment_DiverseMethods.get(i).getExperimentNumber().getMethodName().contains("GARCH"))&&errorName.contains("Training"))
		{continue;}//do not draw boxplots for cross-approach selection approaches' modeling/training performance 
	    
		
		if(i > 0)
	    {
		  commandForR = commandForR + ",";  
	    }
	  
	    commandForR = commandForR + "'" + diverseErrorsOfASegment_DiverseMethods.get(i).getExperimentNumber().getMethodName() + "'";
	  }
	  
	  this.re.eval("colnames(all.data) <- c(" + commandForR + ")");
	  
	  
	  
	  //create Boxplot
	  this.re.eval("png(filename=\"" + this.rootDirectoryPath + "/" + "TS" + timeseriesNumber +" Seg." + segmentNumber + "/" + errorName + ".png\", width = 2500, height = 1500, pointsize = 40)");
	  this.re.eval("par(mar=c(11,8,5,5))");
	  this.re.eval("par(mgp=c(4,1,0))");
	  this.re.eval("boxplot(all.data, varwidth = TRUE, main = \""+ errorName +"\", xlab = \"Method Names (in Abbreviation)\", las = 2, ylab = \"Error Distributions\")");
	  this.re.eval("dev.off()");
  }
}
