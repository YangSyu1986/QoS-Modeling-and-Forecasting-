/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Utilities.Painters;

import java.io.File;
import java.util.List;
import org.rosuda.JRI.Rengine;

import Utilities.DatasetProcessingModules.ObservationsAtOneTimePoint;

/**
 *
 * @author YangSyu
 */
public class TimeSeriesPlotPainterInR 
{
  Rengine re;
  
  List<List<ObservationsAtOneTimePoint>> timeseries;
  
  String rootDirectoryPath;
  
    
  public TimeSeriesPlotPainterInR(List<List<ObservationsAtOneTimePoint>> timeseries, String rootDirectoryPath)
  {
    this.re = Rengine.getMainEngine();
    
    if(this.re == null)
    {
       this.re = new Rengine(new String[] {"--vanilla"}, false, null);
    }
    
    if (!this.re.waitForR()) 
    {
      System.out.println("Cannot load R");
    }
    
    
    this.timeseries=timeseries;
    
    this.rootDirectoryPath = rootDirectoryPath;
    
    this.prepareData();
  }
  
  public void endREngine()
  {
    this.re.end();
  } 
  
  
  private void prepareData()
  { 
    for(int j=0;j<this.timeseries.size();j++)
    {
     String commandForR_timeseriesData = "";	
    	
     for(int i=0;i<this.timeseries.get(j).size();i++)
     {                                                                                     //thus far, we consider Response time
       commandForR_timeseriesData = commandForR_timeseriesData+(String.valueOf(this.timeseries.get(j).get(i).getResponseTime()));
       if(i!=(this.timeseries.get(j).size()-1))
       {
         commandForR_timeseriesData = commandForR_timeseriesData+",";
       }
     }
     
     this.re.eval("timeseriesData<-c("+commandForR_timeseriesData+")");
     
     this.re.eval("timeseries"+j+"<- ts(timeseriesData)");
    } 
  }
  
  
  public void plotOriginalTimeseriesFigures()
  { 
	String directoryPath = this.rootDirectoryPath + "/Original Time Series Plots";
	this.makeDirectory(directoryPath);
	
	  
	for(int i=0;i<this.timeseries.size();i++)
	{
      this.re.eval("png(filename=\""+directoryPath+"/TimeSeries"+i+".png\")");
    
      this.re.eval("plot(timeseries"+i+", main=\"Dynamic QoS Time Series Plot\", xlab=\"Time Points\", ylab=\"Response Time\", ylim = c(3000, 25000))");
    
      this.re.eval("dev.off()");
	}
  }
  
  
  public void plotDifferencedTimeseriesFigure()
  { 
	String directoryPath = this.rootDirectoryPath + "/Differenced Time Series Plots";
    this.makeDirectory(directoryPath);  
	  
    
    for(int i=0;i<this.timeseries.size();i++)
	{
     this.re.eval("png(filename=\""+directoryPath+"/DifferencedTimeSeries"+i+".png\")");
        
     this.re.eval("plot(diff(timeseries"+i+"), main=\"QoS Variation Plot\", xlab=\"Points\",ylab=\"Amount\", ylim = c(-10000, 10000))");
    
     this.re.eval("dev.off()");
	}
  }
  
  
  private void makeDirectory(String directoryPath)
  {    
	File targetdDirectory=new File(directoryPath);
	targetdDirectory.mkdir();  
  }
  
}
