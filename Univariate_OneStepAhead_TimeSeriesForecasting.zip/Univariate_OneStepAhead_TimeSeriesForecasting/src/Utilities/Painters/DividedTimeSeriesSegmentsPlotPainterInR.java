package Utilities.Painters;

import java.io.File;
import java.util.List;

import org.rosuda.JRI.Rengine;

import Utilities.DatasetProcessingModules.ObservationsAtOneTimePoint;

public class DividedTimeSeriesSegmentsPlotPainterInR
{
	Rengine re;
	
	String rootDirectoryPath;  
	String mainDirectoryPath;
	String name;
	private List<List<List<Double>>> dividedTimeSeriesToPlot;
	
	
	public DividedTimeSeriesSegmentsPlotPainterInR( String rootDirectoryPath)
	{
	    this.re = Rengine.getMainEngine();
	    
	    if(this.re == null)
	    {
	       this.re = new Rengine(new String[] {"--vanilla"}, false, null);
	    }
	    
	    if (!this.re.waitForR()) 
	    {
	      System.out.println("Cannot load R");
	    }
	    
	    this.rootDirectoryPath = rootDirectoryPath;
	}
	  
	public void endREngine()
	{
	    this.re.end();
	} 
	
	
	public void setDividedTimeSeriesToPlot(List<List<List<Double>>> DividedTimeSeriesToPlot, String name)
	{
		this.dividedTimeSeriesToPlot = DividedTimeSeriesToPlot;
		this.name = name;
	}
	
	public void plotDividedTimeSeriesPlot()
	{
		this.createDirectories();
		this.plot();
	}
	
	
	private void createDirectories()
	{
		this.mainDirectoryPath = this.rootDirectoryPath + "/Divided Time Series Segments/Divided Time Series Segments Plots";
		this.makeDirectory(this.mainDirectoryPath);	
		
		for(int i=0;i<this.dividedTimeSeriesToPlot.size();i++)
		{
			String secondDirectoryPath = this.mainDirectoryPath + "/" + "TS"+i;
			this.makeDirectory(secondDirectoryPath);
		}
	}
	
	private void makeDirectory(String directoryPath)
	{    
		File directory=new File(directoryPath);
		directory.mkdir();  
	}
	
	
	private void plot()
	{
		for(int i=0;i<this.dividedTimeSeriesToPlot.size();i++)
		{
			List<List<Double>> OneTimeSeriesSegments = this.dividedTimeSeriesToPlot.get(i);
			
			for(int j=0;j<OneTimeSeriesSegments.size();j++)
			{
				List<Double> segment = OneTimeSeriesSegments.get(j);
				
				String commandForR = "";
				
				for(int k=0;k<segment.size();k++)
				{
					commandForR = commandForR + segment.get(k);
					if(k!=(segment.size()-1))
					{
						commandForR = commandForR + ",";
					}
				}
				
				this.re.eval("timeseriesData<-c("+commandForR+")");
			    this.re.eval("timeseries <- ts(timeseriesData)");
			    
			    this.re.eval("png(filename=\""+this.mainDirectoryPath+"/TS"+i+"/"+this.name+"_TS"+i+"_"+"Seg."+j+".png\")");
			    this.re.eval("plot(timeseries, main=\"Time Series Plot\", xlab=\"Time Points\", ylab=\"Value\", ylim = c(3000, 25000))");
			    this.re.eval("dev.off()");
			}
		}
	}
}
