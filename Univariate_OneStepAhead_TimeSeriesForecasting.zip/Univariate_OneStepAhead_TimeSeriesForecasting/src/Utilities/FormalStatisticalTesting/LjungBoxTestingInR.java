package Utilities.FormalStatisticalTesting;

import org.rosuda.JRI.REXP;
import org.rosuda.JRI.Rengine;

public class LjungBoxTestingInR 
{//about Ljung-Box Test, refer to Rob J Hyndman and George A.   P.P.56
 // we refer to https://robjhyndman.com/hyndsight/ljung-box-test/ to choose the number of lags used in the test	
 // P value is the larger the better  (resemble a white noise)
	
	 private Rengine re;
	 
 
	 public LjungBoxTestingInR()
	 {
	     this.re = Rengine.getMainEngine();
	    
	     if(this.re == null)
	     {
	       this.re = new Rengine(new String[] {"--vanilla"}, false, null);
	     }
	    
	    
	     if (!this.re.waitForR()) 
	     {
	       System.out.println("Cannot load R");
	     }
	 }
	  
	 public void endREngine()
	 {
	     this.re.end();
	 } 
	  
	 
	 public double calculateLjungBoxTestingPValue(double[] residuals)
	 {
		this.re.assign("residuals", residuals);//assign data into R environment
		this.re.eval("residualsTS<-ts(residuals)"); 
		 
		this.re.eval("result<-Box.test(residualsTS,type=\"Ljung-Box\", lag="+ Math.min(10, (int)(residuals.length/5))  +")$p.value");  
		REXP x = this.re.eval("result");
		return x.asDouble(); 
	 }
}
