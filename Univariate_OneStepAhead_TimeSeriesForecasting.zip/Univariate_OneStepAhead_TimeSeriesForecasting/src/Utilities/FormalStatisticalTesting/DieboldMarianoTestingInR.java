/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Utilities.FormalStatisticalTesting;

import org.rosuda.JRI.REXP;
import org.rosuda.JRI.Rengine;

/**
 *
 * @author YangSyu
 */
public class DieboldMarianoTestingInR 
{
  Rengine re;
    
  public void prepareREngine()
  {
    this.re = Rengine.getMainEngine();
    
    if(this.re == null)
    {
       this.re = new Rengine(new String[] {"--vanilla"}, false, null);
    }
    
    
    if (!this.re.waitForR()) 
    {
      System.out.println("Cannot load R");
    }
 
   
    this.re.eval("library(\"forecast\")");//loading package "forecast"
  }
  
  public void endREngine()
  {
    this.re.end();
  } 
  
  public void cleanAllVariables()
  {
    this.re.eval("rm(list=ls())");
  }
  
  public void formalAccuracyTest(double[][][] ForecastErrorsSet_GP, double[][][] ForecastErrorsSet_ComparedMethod)throws NullPointerException        
  {
    REXP x=null; 
    
    int h=1;
    int power=1;
    
    String[] alternativeHypothesises={"less", "greater", "two.sided"};
    double pvalue=0;
    
    
    for(int i=0;i<ForecastErrorsSet_GP.length;i++)//services
    {
      for(int j=0;j<ForecastErrorsSet_GP[i].length;j++)//segments
      { 
        re.assign("GPForecastErrors", ForecastErrorsSet_GP[i][j]);
        re.eval("GPForecastErrorsTS<-ts(GPForecastErrors)");
        
        re.assign("ComparedMethodForecastErrors", ForecastErrorsSet_ComparedMethod[i][j]);
        re.eval("ComparedMethodForecastErrorsTS<-ts(ComparedMethodForecastErrors)");
        
        System.out.println("Service: "+i+" Segment: "+j);
        
        for(int k=0;k<alternativeHypothesises.length;k++)
        {
          //p-value
          x=re.eval("dm.test(ComparedMethodForecastErrorsTS, GPForecastErrorsTS, alternative="
                   +"c(\""+alternativeHypothesises[k]+"\"), h="+h+", power="+power+")[4]");
       
          pvalue=x.asVector().at(0).asDouble();
        
          System.out.print("Alter. Hypoth.:"+alternativeHypothesises[k]+"  p_value:"+pvalue+"  ");
        
          if(pvalue>0.05)
          {
           System.out.println("True");
          }
          else
          {
           System.out.println("False");
          }
        }
        long t=System.nanoTime();
      }
    }
  }
}
