package Utilities.FormalStatisticalTesting;

import org.apache.commons.math.stat.descriptive.DescriptiveStatistics;
import org.rosuda.JRI.REXP;
import org.rosuda.JRI.Rengine;

public class KolmogorovSmirnovTestingInR 
{  //"Normality: The approach has used K-S test [11] to test whether the WS1(RT) data is
   //drawn from normal distribution and concluded that it is normally distributed, where p-value equals to 0.393."
	
	
   private Rengine re;	
   
   
   public KolmogorovSmirnovTestingInR()
   {
	     this.re = Rengine.getMainEngine();
	    
	     if(this.re == null)
	     {
	       this.re = new Rengine(new String[] {"--vanilla"}, false, null);
	     }
	    
	    
	     if (!this.re.waitForR()) 
	     {
	       System.out.println("Cannot load R");
	     }
   }
	
   
   public double calculateKolmogorovSmirnovTestPValue(double[] residuals)
   {
	    DescriptiveStatistics stat = new DescriptiveStatistics();
	    
	    for(double residual:residuals) 
	    {
		   stat.addValue(residual);
	    }
	 
	    
		this.re.assign("residuals", residuals);//assign data into R environment
		this.re.eval("residualsTS<-ts(residuals)"); 
	
		this.re.eval("result<-ks.test(residualsTS, \"pnorm\", mean=0, sd="+stat.getStandardDeviation()+")");  
		REXP x = this.re.eval("result$p.value");
		return x.asDouble(); 
   } 
}
