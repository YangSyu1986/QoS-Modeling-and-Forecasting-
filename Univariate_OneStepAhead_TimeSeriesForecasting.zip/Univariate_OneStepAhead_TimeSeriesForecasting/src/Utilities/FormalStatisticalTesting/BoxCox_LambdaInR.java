package Utilities.FormalStatisticalTesting;

import org.rosuda.JRI.REXP;
import org.rosuda.JRI.Rengine;

public class BoxCox_LambdaInR 
{//for testing the constant variance of residual values
 //https://stackoverflow.com/questions/43259669/constant-variance-for-a-time-series-data-in-r	
 //"if lambda was around 1, then you do not need any power transform"	
	
	private Rengine re;
	 
	
	public BoxCox_LambdaInR()
	{
		 this.re = Rengine.getMainEngine();
	    
	     if(this.re == null)
	     {
	       this.re = new Rengine(new String[] {"--vanilla"}, false, null);
	     }
	    
	    
	     if (!this.re.waitForR()) 
	     {
	       System.out.println("Cannot load R");
	     }
	     
	     this.re.eval("library(\"forecast\")");//loading package "forecast"
	}
	
	
	public double calculateBoxCox_LambdaValue(double[] residuals)
	{
		this.re.assign("residuals", residuals);//assign data into R environment
		this.re.eval("residualsTS<-ts(residuals)"); 
		 
		this.re.eval("result<- BoxCox.lambda(residualsTS)");  
		REXP x = this.re.eval("result");
		return x.asDouble(); 
	}
}
