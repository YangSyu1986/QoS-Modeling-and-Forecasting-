package Utilities.FormalStatisticalTesting;

import org.rosuda.JRI.Rengine;

public class ResidualIndependenceTestingInR 
{
     private Rengine re;
	 
	 private double[] dataToTesting;
	    
	 
	 public void prepareREngine()
	 {
	     this.re = Rengine.getMainEngine();
	    
	     if(this.re == null)
	     {
	       this.re = new Rengine(new String[] {"--vanilla"}, false, null);
	     }
	    
	    
	     if (!this.re.waitForR()) 
	     {
	       System.out.println("Cannot load R");
	     }
	 }
	  
	 public void endREngine()
	 {
	     this.re.end();
	 } 
	  
	 public void cleanAllVariables()
	 {
	     this.re.eval("rm(list=ls())");
	 }
	 
	 
	 public void setData(double[] data)
	 {
		 this.dataToTesting = data;
	 }
	 
	 
}
