package Utilities.FormalStatisticalTesting;

import org.rosuda.JRI.REXP;
import org.rosuda.JRI.Rengine;

public class StatisticalTestingIntseries 
{
	 private Rengine re;
	 
	 private double[] dataToTesting;
	    
	 
	 public void prepareREngine()
	 {
	     this.re = Rengine.getMainEngine();
	    
	     if(this.re == null)
	     {
	       this.re = new Rengine(new String[] {"--vanilla"}, false, null);
	     }
	    
	    
	     if (!this.re.waitForR()) 
	     {
	       System.out.println("Cannot load R");
	     }
	 
	   
	     this.re.eval("library(\"tseries\")");//loading package "tseries"
	 }
	  
	 public void endREngine()
	 {
	     this.re.end();
	 } 
	  
	 public void cleanAllVariables()
	 {
	     this.re.eval("rm(list=ls())");
	 }
	 
	 
	 public void setData(double[] data)
	 {
		 this.dataToTesting = data;
	 }
//"p-value越小，H0(null hypothesis)越不可能為真"  "P值越小，棄卻H0的理由越充分"   "p為在H0為真的前提下，能觀察這批樣本數據的機率)"
//"p-value：若(前提) H0 為真，則 test statistic 出現的可能性。(若p-value越小，表示抽樣樣本越(極端)不可能出現，因此推翻前提，棄卻H0)。"
//"p-value：以現有的抽樣所進行的推論，可能犯 type I error 的機率。(若p-value越小，表示棄卻H0不太可能錯，因此棄卻H0)。"	 
	 private double calculatestatisticalTestingIntseries(String statisticalTestingInstruction)
	 {
		 REXP x = null; 
		 
		 this.re.assign("data", this.dataToTesting);
	     this.re.eval("dataTS<-ts(data)");
	     
	     this.re.eval(statisticalTestingInstruction);
		 
	     x = this.re.eval("result$p.value");
  
	     return x.asDouble();
	 }
	 
	 public double calculateKPSS_Level()
	 { //to interpret the result of KPSS testing, refer to "http://stats.stackexchange.com/questions/13213/how-to-interpret-kpss-results"
	   //"Assuming you are using the 5% level, then a p-value above 0.05 means you have no evidence that it is not trend stationary. That is not the same as saying that it is trend stationary. – Rob Hyndman" 
			   //the null hypothesis that x is level stationary
	     return this.calculatestatisticalTestingIntseries("result<-kpss.test(dataTS, null=\"Level\")");
	 }
	 
	 public double calculateKPSS_Trend()
	 {         //the null hypothesis that x is trend stationary
	     return this.calculatestatisticalTestingIntseries("result<-kpss.test(dataTS, null=\"Trend\")");
	 }
	 
	 public double calculateTerasvirta_test()
	 {        //The null is the hypotheses of linearity in “mean”
	     return this.calculatestatisticalTestingIntseries("result<-terasvirta.test(dataTS)");
	 }
	 
	 public double calculateWhite_test()
	 {       //The null is the hypotheses of linearity in “mean”.
	     return this.calculatestatisticalTestingIntseries("result<-white.test(dataTS)");
	 }
}
