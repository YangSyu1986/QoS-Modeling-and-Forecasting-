package Utilities.ResidualDiagnosis;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.List;

import Utilities.DataStructures.ForecastingOutcomeOfASegment;
import Utilities.DataStructures.Residuals;
import Utilities.ExcelMakers.ResidualFileMaker;
import Utilities.Painters.ResidualPlotPainterInR;

public class MainDiagnostician 
{
   List<Residuals[][]> outcomeOfDiverseMethods_Residuals;
   
   String rootDirectoryPath;
	
	
   public MainDiagnostician(String filePath, String directoryName, List<ForecastingOutcomeOfASegment[][]> outcomeOfDiverseMethods_ForecastingOutcomes) throws NoSuchMethodException, SecurityException, IllegalAccessException, IllegalArgumentException, InvocationTargetException, IOException
   {
	  System.out.println("Perform Residual Diagnosis");  
	  
	  
	  this.makeResiduals(outcomeOfDiverseMethods_ForecastingOutcomes);//calculate the residuals of each approach
	  
	  
	  this.rootDirectoryPath = filePath + "/" + directoryName;
	  this.makeDirectory(this.rootDirectoryPath);
	  
	  
	  (new ResidualFileMaker(this.outcomeOfDiverseMethods_Residuals, this.rootDirectoryPath, "ResidualAnalysis")).MakeFile();//residual means
	  (new ResidualPlotPainterInR(this.rootDirectoryPath, "Residual Plots", this.outcomeOfDiverseMethods_Residuals)).plot();//diverse residual plots (ACF, histogram, residual plot)
	  
	  
	  System.out.println("Done !!");
   }
	
   
   
   private void makeResiduals(List<ForecastingOutcomeOfASegment[][]> outcomeOfDiverseMethods_ForecastingOutcomes)
   {
	   this.outcomeOfDiverseMethods_Residuals = new ArrayList<Residuals[][]>();
	   
	   
	   for(ForecastingOutcomeOfASegment[][] outcomeOfAMethod:outcomeOfDiverseMethods_ForecastingOutcomes)//different approaches
	   {
		   Residuals[][] residualsOfAMethod = new Residuals[outcomeOfAMethod.length][];
		   
		   for(int i = 0 ; i < outcomeOfAMethod.length; i++)
		   {
			   Residuals[] residualsOfATimeSeries = new Residuals[outcomeOfAMethod[i].length];
			   
			   for(int j = 0; j < outcomeOfAMethod[i].length; j++)
			   {
				   residualsOfATimeSeries[j] = new Residuals(
						                                     outcomeOfAMethod[i][j].getExperimentNumber(), 
						                                     this.calculateResiduals(outcomeOfAMethod[i][j].getTrainingObservations(),outcomeOfAMethod[i][j].getTrainingPredictions()), 
						                                     this.calculateResiduals(outcomeOfAMethod[i][j].getTestingObservations(), outcomeOfAMethod[i][j].getTestingPredictions())
						                                    );   
			   }
			   
			   residualsOfAMethod[i] = residualsOfATimeSeries;
		   }
		   
		   
		   this.outcomeOfDiverseMethods_Residuals.add(residualsOfAMethod);
	   }
   }
   
   
   private double[] calculateResiduals(double[] observations, double[] predictions)
   {
	   if(observations.length != predictions.length)
	   {
		   System.out.println("The lengths of input observations and predictions are different !!");
		   
		   return null;
	   }
	   
	   
	   double[] result = new double[observations.length];
	   
	   for(int i = 0; i < result.length; i++)
	   {
		   result[i] = observations[i] - predictions[i];
	   }
	   
	   return result;
   }
	
   
   private void makeDirectory(String directoryPath)
   {    
	   File directory = new File(directoryPath);
	   directory.mkdir();  
   }
}
