package Utilities.PredictionExperimentsForComparedMethods;

import java.util.List;


import ProposedTimeSeriesMethod_GP.Tools.ForecastingOutcomesProcessor;
import Utilities.CommonSetting.TimeSeriesIntervalsIndicesSet;
import Utilities.DataStructures.ForecastingOutcomeOfASegment;
import Utilities.DatasetProcessingModules.ObservationsAtOneTimePoint;
import Utilities.ForecastingAccuracyMeasures.DiverseErrorsOfASegment;
import Utilities.ForecastingAccuracyMeasures.DiverseMeasuringResultsOfASegment;
import Utilities.ForecastingCostMeasures.TimeCost;

public abstract class PredictionExperiments 
{
  List<List<ObservationsAtOneTimePoint>> timeSeries;
  int numberOfTimeseries;
  int[][][] trainingDataIntervalsSet;
  int[][][] testingDataIntervalsSet;


  List<ForecastingOutcomeOfASegment[][]> outcomeOfDiverseMethods_ForecastingOutcomes;
  List<DiverseErrorsOfASegment[][]> outcomeOfDiverseMethods_DiverseErrors; 
  List<DiverseMeasuringResultsOfASegment[][]> outcomeOfDiverseMethods_AccuracyMeasures; 
  List<TimeCost[][]> outcomeOfDiverseMethods_TimeCosts;
	
	
  public PredictionExperiments(List<List<ObservationsAtOneTimePoint>> timeSeries, int numberOfTimeseries,
		                       TimeSeriesIntervalsIndicesSet timeSeriesIntervalsIndicesSet,
		                          
		                       List<ForecastingOutcomeOfASegment[][]> outcomeOfDiverseMethods_ForecastingOutcomes,
		                       List<DiverseErrorsOfASegment[][]> outcomeOfDiverseMethods_DiverseErrors, 
                               List<DiverseMeasuringResultsOfASegment[][]> outcomeOfDiverseMethods_AccuracyMeasures, 
                               List<TimeCost[][]> outcomeOfDiverseMethods_TimeCosts
		                      )
  {
	 this.timeSeries = timeSeries;
	 this.numberOfTimeseries = numberOfTimeseries;
	 this.trainingDataIntervalsSet = timeSeriesIntervalsIndicesSet.getTrainingIntervalsIndicesSet();
	 this.testingDataIntervalsSet = timeSeriesIntervalsIndicesSet.getTestingIntervalsIndicesSet();
	 
	 this.outcomeOfDiverseMethods_ForecastingOutcomes = outcomeOfDiverseMethods_ForecastingOutcomes;
	 this.outcomeOfDiverseMethods_DiverseErrors = outcomeOfDiverseMethods_DiverseErrors;
	 this.outcomeOfDiverseMethods_AccuracyMeasures = outcomeOfDiverseMethods_AccuracyMeasures;
	 this.outcomeOfDiverseMethods_TimeCosts = outcomeOfDiverseMethods_TimeCosts;
  }

  public void runExperiments(String methodName,  Object method) throws Exception
  {
	 ForecastingOutcomeOfASegment[][] results = new ForecastingOutcomeOfASegment[this.numberOfTimeseries][];
	  
	 for(int i = 0; i < this.numberOfTimeseries; i++)
	 {
		results[i] = new ForecastingOutcomeOfASegment[this.trainingDataIntervalsSet.length]; 
		 
		for(int j = 0; j < this.trainingDataIntervalsSet.length; j++)
		{
		  System.out.println(method.getClass().getSimpleName() + "  TS  " + i + "  Segment  " + j);	
			
		  ForecastingOutcomeOfASegment forecastingOutcomeOfASegment = new ForecastingOutcomeOfASegment(i, j, 0, methodName); 
		  
		  
		  results[i][j] = this.invokeMethod(method, timeSeries.get(i), this.trainingDataIntervalsSet[j], this.testingDataIntervalsSet[j], forecastingOutcomeOfASegment);
		}
	 }
	  
	 
	 outcomeOfDiverseMethods_ForecastingOutcomes.add(results);
	 
	 DiverseErrorsOfASegment[][] diverseErrorsOfASegment = ForecastingOutcomesProcessor.generateDiverseErrorsOfASegment(results);
	 outcomeOfDiverseMethods_DiverseErrors.add(diverseErrorsOfASegment); 
		   
	 DiverseMeasuringResultsOfASegment[][] diverseMeasuringResultsOfASegment = ForecastingOutcomesProcessor.generateDiverseMeasuringResultsOfASegment(diverseErrorsOfASegment);
	 outcomeOfDiverseMethods_AccuracyMeasures.add(diverseMeasuringResultsOfASegment); 
		    
	 TimeCost[][] timeCostOfASegment = ForecastingOutcomesProcessor.generateDiverseTimeCostOfASegment(results);
	 outcomeOfDiverseMethods_TimeCosts.add(timeCostOfASegment);   
   }
  
  
  
   protected abstract ForecastingOutcomeOfASegment invokeMethod(Object method, List<ObservationsAtOneTimePoint> timeSeries, int[][] trainingDataIntervalsSet, int[][] testingDataIntervalsSet,ForecastingOutcomeOfASegment result) throws Exception;
}
