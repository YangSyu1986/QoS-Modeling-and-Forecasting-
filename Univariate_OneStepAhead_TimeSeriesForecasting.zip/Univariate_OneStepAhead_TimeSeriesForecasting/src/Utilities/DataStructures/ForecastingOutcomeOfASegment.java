package Utilities.DataStructures;

public class ForecastingOutcomeOfASegment 
{
   private ExperimentNumber experimentNumber;
   
	
   private double[] trainingObservations;
   private double[] trainingPredictions;
   private double[] testingObservations;
   private double[] testingPredictions;  

   
   private double predictorProductionTime;
  
   private double trainingForecastsProductionTime;
   private double testingForecastsProductionTime;
   
   
   public ForecastingOutcomeOfASegment(int timeseriesNumber, int segmentNumber, int repeatNumber, String methodName)
   {
	   this.experimentNumber = new ExperimentNumber(timeseriesNumber, segmentNumber, repeatNumber, methodName); 
   }

   public ExperimentNumber getExperimentNumber()
   {
	   return this.experimentNumber;
   }
   
   public double[] getTrainingObservations()
   {
	   return trainingObservations;
   }

   public void setTrainingObservations(double[] trainingObservations) 
   {
	   this.trainingObservations = trainingObservations; 
   }

   public double[] getTrainingPredictions() 
   {
	   return trainingPredictions;
   }

   public void setTrainingPredictions(double[] trainingPredictions) 
   {
	   this.trainingPredictions = trainingPredictions; 
   }

   public double[] getTestingObservations() 
   {
	   return testingObservations;
   }

   public void setTestingObservations(double[] testingObservations) 
   {
	   this.testingObservations = testingObservations;  
   }

   public double[] getTestingPredictions() 
   {
	   return testingPredictions;
   }

   public void setTestingPredictions(double[] testingPredictions)
   {
	   this.testingPredictions = testingPredictions;  
   }

   public double getPredictorProductionTime()
   {
	  return predictorProductionTime;
   }

   public void setPredictorProductionTime(double predictorProductionTime)
   {
	  this.predictorProductionTime = predictorProductionTime;
   }

   public double getTestingForecastsProductionTime() 
   {
	  return testingForecastsProductionTime;
   }

   public void setTestingForecastsProductionTime(double testingForecastsProductionTime)
   {
	  this.testingForecastsProductionTime = testingForecastsProductionTime;
   }
   
   public double getTrainingForecastsProductionTime() 
   {
	  return this.trainingForecastsProductionTime;
   }

   public void setTrainingForecastsProductionTime(double trainingForecastsProductionTime)
   {
	  this.trainingForecastsProductionTime = trainingForecastsProductionTime;
   }
}
