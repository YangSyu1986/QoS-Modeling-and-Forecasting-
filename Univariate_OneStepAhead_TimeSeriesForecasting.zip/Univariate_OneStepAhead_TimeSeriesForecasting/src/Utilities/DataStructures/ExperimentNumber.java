package Utilities.DataStructures;

public class ExperimentNumber 
{
	 int timeseriesNumber;
	 int segmentNumber;
	 int repeatNumber;
	 String methodName;
	 
	 public ExperimentNumber(int timeseriesNumber, int segmentNumber, int repeatNumber, String methodName)
	 {
	   this.timeseriesNumber = timeseriesNumber;
	   this.segmentNumber = segmentNumber;
	   this.repeatNumber = repeatNumber; 
	   this.methodName = methodName;
	 }
	 
	 public int getTimeseriesNumber() 
	 {
	    return this.timeseriesNumber;
	 }

	 public int getSegmentNumber() 
	 {
	    return this.segmentNumber;
	 }

	 public int getRepeatNumber() 
	 {
	    return this.repeatNumber;
	 }  
	 
	 public String getMethodName()
	 {
	    return this.methodName;
	 }
}
