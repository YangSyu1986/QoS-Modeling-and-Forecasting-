package Utilities.DataStructures;

import Utilities.FormalStatisticalTesting.BoxCox_LambdaInR;
import Utilities.FormalStatisticalTesting.KolmogorovSmirnovTestingInR;
import Utilities.FormalStatisticalTesting.LjungBoxTestingInR;

public class Residuals 
{
   private ExperimentNumber experimentNumber;	
	
   private double[] trainingResiduals;
   private double[] testingResiduals; 
   
   private double trainingResidualMean;
   private double testingResidualMean; 
   
   private double trainingLjungBoxTestPValue;
   private double testingLjungBoxTestPValue;


   private double trainingBoxCoxLambdaValue;
   private double testingBoxCoxLambdaValue;

   private double trainingKolmogorovSmirnovTestPValue;
   private double testingKolmogorovSmirnovTestPValue;
   

   public Residuals(ExperimentNumber experimentNumber, double[] trainingResiduals, double[] testingResiduals)
   {
	  this.experimentNumber = experimentNumber;
	  
	  this.trainingResiduals = trainingResiduals;
	  this.testingResiduals = testingResiduals;
	  
	  this.trainingResidualMean = this.calculateResidualMean(this.trainingResiduals);
	  this.testingResidualMean = this.calculateResidualMean(this.testingResiduals);
	  
	  this.trainingLjungBoxTestPValue = this.calculateLjungBoxTestPValue(this.trainingResiduals);
	  this.testingLjungBoxTestPValue = this.calculateLjungBoxTestPValue(this.testingResiduals);
	  
	  this.trainingBoxCoxLambdaValue = this.calculateBoxCoxLambdaValue(this.trainingResiduals);
	  this.testingBoxCoxLambdaValue = this.calculateBoxCoxLambdaValue(this.testingResiduals);
	  
	  this.trainingKolmogorovSmirnovTestPValue = this.calculateKolmogorovSmirnovTestPValue(this.trainingResiduals);
	  this.testingKolmogorovSmirnovTestPValue = this.calculateKolmogorovSmirnovTestPValue(this.testingResiduals);
   }
   
   

   public ExperimentNumber getExperimentNumber()
   {
	 return this.experimentNumber;
   }


   public double[] getTrainingResiduals() 
   {
	 return this.trainingResiduals;
   }

   public double[] getTestingResiduals()
   {
	 return this.testingResiduals;
   }

   
   public double getTrainingResidualMean() 
   {
	 return trainingResidualMean;
   }

   public double getTestingResidualMean() 
   {
	 return testingResidualMean;
   }
   
   
   public double getTrainingLjungBoxTestPValue()
   {
	 return trainingLjungBoxTestPValue;
   }

   public double getTestingLjungBoxTestPValue()
   {
	 return testingLjungBoxTestPValue;
   }

   
   public double getTrainingBoxCoxLambdaValue() 
   {
	 return trainingBoxCoxLambdaValue;
   }


   public double getTestingBoxCoxLambdaValue() 
   {
	 return testingBoxCoxLambdaValue;
   }

   
   public double getTrainingKolmogorovSmirnovTestPValue()
   {   
	 return trainingKolmogorovSmirnovTestPValue;
   }



   public double getTestingKolmogorovSmirnovTestPValue() 
   {
	 return testingKolmogorovSmirnovTestPValue;
   }
   
   
   private double calculateResidualMean(double[] values)
   {
	   double mean = 0;
	   
	   for(double value:values)
	   {
		   mean = mean + value;
	   }
	   
	   return mean/values.length;
   }
   
   
   private double calculateLjungBoxTestPValue(double[] residuals)
   {
	   LjungBoxTestingInR tester = new LjungBoxTestingInR();
	   
	   double PValue = tester.calculateLjungBoxTestingPValue(residuals);
 
	   return PValue;
   }
   
   
   private double calculateBoxCoxLambdaValue(double[] residuals)
   {
	   BoxCox_LambdaInR  tester = new BoxCox_LambdaInR ();
	   
	   double lambdaValue = tester.calculateBoxCox_LambdaValue(residuals);
 
	   return lambdaValue;
   }
   
   
   private double calculateKolmogorovSmirnovTestPValue(double[] residuals)
   {
	   KolmogorovSmirnovTestingInR   tester = new KolmogorovSmirnovTestingInR();
	   
	   double PValue = tester.calculateKolmogorovSmirnovTestPValue(residuals);
 
	   return PValue;
   }
}
