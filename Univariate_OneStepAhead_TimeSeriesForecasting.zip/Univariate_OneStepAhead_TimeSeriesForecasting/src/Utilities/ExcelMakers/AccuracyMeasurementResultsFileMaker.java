package Utilities.ExcelMakers;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;

import org.apache.poi.ss.usermodel.Workbook;
import org.apache.commons.math.stat.descriptive.DescriptiveStatistics;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import Utilities.ForecastingAccuracyMeasures.DiverseErrorsOfASegment;
import Utilities.ForecastingAccuracyMeasures.DiverseMeasuringResultsOfASegment;

public class AccuracyMeasurementResultsFileMaker
{
   String filePath;
   String fileName;
   FileOutputStream fileOutputStream;
   
   List<DiverseMeasuringResultsOfASegment[][]> outcomeOfDiverseMethods_AccuracyMeasures;
   
   Workbook workbook;
   
   
   
   public AccuracyMeasurementResultsFileMaker(String filePath, String fileName, List<DiverseMeasuringResultsOfASegment[][]> outcomeOfDiverseMethods_AccuracyMeasures) throws FileNotFoundException
   {
	  this.filePath = filePath;
	  this.fileName = fileName;
	  this.outcomeOfDiverseMethods_AccuracyMeasures = outcomeOfDiverseMethods_AccuracyMeasures;
   }
   
   
   public void MakeAccuracyFile() throws IOException, NoSuchMethodException, SecurityException, IllegalAccessException, IllegalArgumentException, InvocationTargetException
   {
	  System.out.println("Make Accuracy Measurement Result Files"); 
	   
	  //make training accuracy measuring excel file 
	  this.workbook = new XSSFWorkbook(); 
	  this.fileOutputStream = new FileOutputStream(this.filePath + "/" + this.fileName+"_Training.xlsx");
	  
      createASheetForAMeasure("TrainingMeanAbsoluteError");
    //  createASheetForAMeasure("TrainingGeometricMeanAbsoluteError");
	//  createASheetForAMeasure("TrainingMedianAbsoluteError");
	//  createASheetForAMeasure("TrainingMeanSquaredError");
      createASheetForAMeasure("TrainingRootMeanSquaredError");
      createASheetForAMeasure("TrainingMeanAbsolutePercentageError");
	//  createASheetForAMeasure("TrainingMedianAbsolutePercentageError");
    //  createASheetForAMeasure("TrainingRootMeanSquaredPercentageError");
	//  createASheetForAMeasure("TrainingRootMedianSquaredPercentageError");
      createASheetForAMeasure("TrainingSymmetricMeanAbsolutePercentageError");
	//  createASheetForAMeasure("TrainingSymmetricMedianAbsolutePercentageError");
	//  createASheetForAMeasure("TrainingMeanRelativeAbsoluteError");
	//  createASheetForAMeasure("TrainingMedianRelativeAbsoluteError");
	//  createASheetForAMeasure("TrainingGeometricMeanRelativeAbsoluteError");
      createASheetForAMeasure("TrainingMeanAbsoluteScaledError");    //the scaled version of MAE
      createASheetForAMeasure("TrainingRootMeanSquaredScaledError"); //the scaled version of RMSE
	//  createASheetForAMeasure("TrainingMedianAbsoluteScaledError");
	 
	  this.close();
	  
	  
	  //make testing accuracy measuring excel file 
	  this.workbook = new XSSFWorkbook(); 
	  this.fileOutputStream = new FileOutputStream(this.filePath + "/" + this.fileName+"_Testing.xlsx");
	  
	  createASheetForAMeasure("TestingMeanAbsoluteError");
	 // createASheetForAMeasure("TestingGeometricMeanAbsoluteError");
	 // createASheetForAMeasure("TestingMedianAbsoluteError");
	 // createASheetForAMeasure("TestingMeanSquaredError");
	  createASheetForAMeasure("TestingRootMeanSquaredError");
	  createASheetForAMeasure("TestingMeanAbsolutePercentageError");
	 // createASheetForAMeasure("TestingMedianAbsolutePercentageError");
	 // createASheetForAMeasure("TestingRootMeanSquaredPercentageError");
	 // createASheetForAMeasure("TestingRootMedianSquaredPercentageError");
	  createASheetForAMeasure("TestingSymmetricMeanAbsolutePercentageError");
	 // createASheetForAMeasure("TestingSymmetricMedianAbsolutePercentageError");
	 //  createASheetForAMeasure("TestingMeanRelativeAbsoluteError");
	 // createASheetForAMeasure("TestingMedianRelativeAbsoluteError");
	 // createASheetForAMeasure("TestingGeometricMeanRelativeAbsoluteError");
	  createASheetForAMeasure("TestingMeanAbsoluteScaledError");
	  createASheetForAMeasure("TestingRootMeanSquaredScaledError");
	 // createASheetForAMeasure("TestingMedianAbsoluteScaledError");
	   
	  this.close();
	  
	  System.out.println("Done !!");
   }
   
   private void createASheetForAMeasure(String measureName) throws NoSuchMethodException, SecurityException, IllegalAccessException, IllegalArgumentException, InvocationTargetException
   {
	  
	  List<DiverseMeasuringResultsOfASegment[][]> accuracyMeasuresToDisplay = new ArrayList<DiverseMeasuringResultsOfASegment[][]>();
	  
	  for(int i = 0; i < this.outcomeOfDiverseMethods_AccuracyMeasures.size(); i++)
	  {    //do not display the training results of selection approaches in tables
		 if(measureName.contains("Training") &&  this.outcomeOfDiverseMethods_AccuracyMeasures.get(i)[0][0].getExperimentNumber().getMethodName().contains("Select"))
		 { 
		 }
		 else
		 {
			 accuracyMeasuresToDisplay.add(this.outcomeOfDiverseMethods_AccuracyMeasures.get(i));
		 }
	  }
	  
	  
	  //prepare a sheet
	  Sheet sheet = this.workbook.createSheet(measureName);
	  sheet.setDefaultColumnWidth(13);
	  List<Row> rows = new ArrayList<Row>();
	
	  
	  int numberOfForecastingMethods = accuracyMeasuresToDisplay.size();
	 
	 
	  
	  //create first column
	  Row title = sheet.createRow(0);
	  title.createCell(0).setCellValue(" ");
	  rows.add(title);

	  for(int i = 0; i < numberOfForecastingMethods; i++)
	  {	  
		 Row method = sheet.createRow(i + 1);
		 method.createCell(0).setCellValue(((accuracyMeasuresToDisplay.get(i))[0][0]).getExperimentNumber().getMethodName());
		 rows.add(method);
	  }
	  
	  
	  int rowJump = 3;
	  int columnJump = 1;
	  
	  
	  for(int i = 0; i < numberOfForecastingMethods; i++)
	  {
		 Row NthBestMethod = sheet.createRow(numberOfForecastingMethods + rowJump + i);
		 NthBestMethod.createCell(0).setCellValue(i + 1);
		 rows.add(NthBestMethod);
	  }
	  
	  
	  //create second and subsequent columns
	  double[][] errorValues = new double[numberOfForecastingMethods][accuracyMeasuresToDisplay.get(0).length * accuracyMeasuresToDisplay.get(0)[0].length];
	  List<ArrayList<MethodNameAndItsErrorValuePair>> rankingResults = new ArrayList<ArrayList<MethodNameAndItsErrorValuePair>>();
	  int currentColumnNumber = 1;
	  
	  for(int i = 0; i < accuracyMeasuresToDisplay.get(0).length; i++)
	  {
		for(int j = 0; j < accuracyMeasuresToDisplay.get(0)[i].length; j++)
		{
			rows.get(0).createCell(currentColumnNumber).setCellValue("TS. " + i + "  Seg. " + j);
		
			
			List<MethodNameAndItsErrorValuePair> methodNameAndItsErrorValuePairs = new ArrayList<MethodNameAndItsErrorValuePair>();
			
		    for(int k = 0; k < numberOfForecastingMethods; k++)
		    {
		       Method method = accuracyMeasuresToDisplay.get(k)[i][j].getClass().getMethod("get" + measureName, null);
			   double value = ((double) method.invoke(accuracyMeasuresToDisplay.get(k)[i][j], null));//get error value	
		    	
			   if(Double.isNaN(value) || Double.isInfinite(value)) // if the error result is not a valid value
			   {
				   value = Double.MAX_VALUE;
			   }
			
		       rows.get(k+1).createCell(currentColumnNumber).setCellValue(value);
		       errorValues[k][currentColumnNumber - 1] = value;
		       
		       
		       methodNameAndItsErrorValuePairs.add(new MethodNameAndItsErrorValuePair(accuracyMeasuresToDisplay.get(k)[i][j].getExperimentNumber().getMethodName(), value));
		    }
		    
		    
		    Collections.sort(methodNameAndItsErrorValuePairs); 
		   
		    
		    for(int w = 0; w < methodNameAndItsErrorValuePairs.size(); w++)
		    {
		      rows.get(numberOfForecastingMethods + 1 + w).createCell(currentColumnNumber).setCellValue(methodNameAndItsErrorValuePairs.get(w).getMethodName());
		    }
		    
		    
		    rankingResults.add((ArrayList<MethodNameAndItsErrorValuePair>)methodNameAndItsErrorValuePairs);
		    currentColumnNumber++;
		}
	  }
	  
	  
	  
	  //set mean, min, max, SD of each method
	  rows.get(0).createCell(currentColumnNumber + columnJump + 1).setCellValue("Mean");
	  rows.get(0).createCell(currentColumnNumber + columnJump + 2).setCellValue("Min");
	  rows.get(0).createCell(currentColumnNumber + columnJump + 3).setCellValue("Max");
	  rows.get(0).createCell(currentColumnNumber + columnJump + 4).setCellValue("SD");
	  
	  for(int i = 0; i < numberOfForecastingMethods; i++)//label method names
	  {
		  rows.get(i + 1).createCell(currentColumnNumber + columnJump).setCellValue(((accuracyMeasuresToDisplay.get(i))[0][0]).getExperimentNumber().getMethodName());
	  }
	  
	  
	  List<MethodNameAndItsErrorValuePair> methodNameAndItsErrorValuePairs_mean = new ArrayList<MethodNameAndItsErrorValuePair>();
	  List<MethodNameAndItsErrorValuePair> methodNameAndItsErrorValuePairs_min = new ArrayList<MethodNameAndItsErrorValuePair>();	
	  List<MethodNameAndItsErrorValuePair> methodNameAndItsErrorValuePairs_max = new ArrayList<MethodNameAndItsErrorValuePair>();
	  List<MethodNameAndItsErrorValuePair> methodNameAndItsErrorValuePairs_sd = new ArrayList<MethodNameAndItsErrorValuePair>();
	  
	  
	  for(int i = 0; i < errorValues.length; i++)//different methods
	  {
		  DescriptiveStatistics stats = new DescriptiveStatistics(); 
		  
		  for(int j = 0; j < errorValues[i].length; j++)
		  {
			if(Double.isNaN(errorValues[i][j]) == false && errorValues[i][j] != Double.MAX_VALUE)
			{
			  stats.addValue(errorValues[i][j]);
			}
		  }
		  
		  
		  double mean = stats.getMean();
		  double min = stats.getMin();
		  double max = stats.getMax();
		  double sd = stats.getStandardDeviation();
		  
		  
		  methodNameAndItsErrorValuePairs_mean.add(new MethodNameAndItsErrorValuePair(accuracyMeasuresToDisplay.get(i)[0][0].getExperimentNumber().getMethodName(), mean));
		  methodNameAndItsErrorValuePairs_min.add(new MethodNameAndItsErrorValuePair(accuracyMeasuresToDisplay.get(i)[0][0].getExperimentNumber().getMethodName(), min));
		  methodNameAndItsErrorValuePairs_max.add(new MethodNameAndItsErrorValuePair(accuracyMeasuresToDisplay.get(i)[0][0].getExperimentNumber().getMethodName(), max));
		  methodNameAndItsErrorValuePairs_sd.add(new MethodNameAndItsErrorValuePair(accuracyMeasuresToDisplay.get(i)[0][0].getExperimentNumber().getMethodName(), sd));
		  
		 
		  rows.get(i + 1).createCell(currentColumnNumber + columnJump + 1).setCellValue(mean);
		  rows.get(i + 1).createCell(currentColumnNumber + columnJump + 2).setCellValue(min);
		  rows.get(i + 1).createCell(currentColumnNumber + columnJump + 3).setCellValue(max);
		  rows.get(i + 1).createCell(currentColumnNumber + columnJump + 4).setCellValue(sd);
	  }
	  
	  
	  Collections.sort(methodNameAndItsErrorValuePairs_mean); 
	  Collections.sort(methodNameAndItsErrorValuePairs_min); 
	  Collections.sort(methodNameAndItsErrorValuePairs_max); 
	  Collections.sort(methodNameAndItsErrorValuePairs_sd); 
	  
	  
	  for(int w = 0; w < methodNameAndItsErrorValuePairs_mean.size(); w++)
	  {
	     rows.get(numberOfForecastingMethods + 1 + w).createCell(currentColumnNumber + columnJump + 1).setCellValue(methodNameAndItsErrorValuePairs_mean.get(w).getMethodName());
	     rows.get(numberOfForecastingMethods + 1 + w).createCell(currentColumnNumber + columnJump + 2).setCellValue(methodNameAndItsErrorValuePairs_min.get(w).getMethodName());
	     rows.get(numberOfForecastingMethods + 1 + w).createCell(currentColumnNumber + columnJump + 3).setCellValue(methodNameAndItsErrorValuePairs_max.get(w).getMethodName());
	     rows.get(numberOfForecastingMethods + 1 + w).createCell(currentColumnNumber + columnJump + 4).setCellValue(methodNameAndItsErrorValuePairs_sd.get(w).getMethodName());	      
	  }
	  
	  
	  
	  //set the number of ranking X of each method
	  currentColumnNumber = (currentColumnNumber + columnJump + 4) + columnJump + 1;
	  
	  for(int i = 0; i < numberOfForecastingMethods; i++)//label method names
	  {
		  rows.get(i + 1).createCell(currentColumnNumber ).setCellValue(((accuracyMeasuresToDisplay.get(i))[0][0]).getExperimentNumber().getMethodName());
	  }
	  
	  currentColumnNumber++;
	  
	  
	  for(int i = 0; i < numberOfForecastingMethods; i++)//for each ranking order
	  {
		 rows.get(0).createCell(currentColumnNumber + i).setCellValue("Num. of ran. " + (i + 1)); 
		 
		
		 List<MethodNameAndItsCountingInTheSpecificRankingOrderPair> methodNameAndItsCountingInTheSpecificRankingOrderPairs = new ArrayList<MethodNameAndItsCountingInTheSpecificRankingOrderPair>();
		 
		 for(int j = 0 ; j < numberOfForecastingMethods; j++)
		 {
			 MethodNameAndItsCountingInTheSpecificRankingOrderPair methodNameAndItsCountingInTheSpecificRankingOrderPair = 
		       new MethodNameAndItsCountingInTheSpecificRankingOrderPair( accuracyMeasuresToDisplay.get(j)[0][0].getExperimentNumber().getMethodName());
			
			 methodNameAndItsCountingInTheSpecificRankingOrderPairs.add(methodNameAndItsCountingInTheSpecificRankingOrderPair); 
		 }
		 
		 
		 //counting for each ranking and each method
		 for(int j = 0; j < rankingResults.size(); j++ )
		 {
			 for(MethodNameAndItsCountingInTheSpecificRankingOrderPair methodNameAndItsCountingInTheSpecificRankingOrderPair : methodNameAndItsCountingInTheSpecificRankingOrderPairs)
			 {
				if(methodNameAndItsCountingInTheSpecificRankingOrderPair.getMethodName().equals( rankingResults.get(j).get(i).getMethodName() ))
				{
					methodNameAndItsCountingInTheSpecificRankingOrderPair.increaseCounting();
					break;
				}
			 }
			 
		 }
		 
		 for(int j = 0; j < methodNameAndItsCountingInTheSpecificRankingOrderPairs.size(); j++)
		 {
			   rows.get(j + 1).createCell(currentColumnNumber + i).setCellValue(methodNameAndItsCountingInTheSpecificRankingOrderPairs.get(j).getCounting());
		 }
		 
		 //sorting according to the counting number
		 Collections.sort(methodNameAndItsCountingInTheSpecificRankingOrderPairs);//ranking according to the number of in that order 
		 
		 for(int j = 0; j < methodNameAndItsCountingInTheSpecificRankingOrderPairs.size(); j++)
		 {
			   rows.get(numberOfForecastingMethods + 1 + j).createCell(currentColumnNumber + i).setCellValue(methodNameAndItsCountingInTheSpecificRankingOrderPairs.get(j).getMethodName());
		 }
		 
	  }
   }
   
   
   private void close() throws IOException 
   { 
      this.workbook.write(this.fileOutputStream);
      this.fileOutputStream.close();
   }
}





class MethodNameAndItsErrorValuePair implements Comparable<MethodNameAndItsErrorValuePair>
{
	String methodName;
	double errorValue;
	
	MethodNameAndItsErrorValuePair(String methodName, double errorValue)
	{
	    this.methodName = methodName;
	    this.errorValue = errorValue;
	}
	
	
	public String getMethodName()
	{
		return this.methodName;
	}
	
	public double getErrorValue()
	{
		return this.errorValue;
	}


	@Override
	public int compareTo(MethodNameAndItsErrorValuePair pair) 
	{
		if(this.errorValue == pair.errorValue)//equally accurate
		{
			return 0;
		}
		else if(this.errorValue > pair.errorValue)//less accurate
		{
			return 1;
		}
		else //more accurate
		{
			return -1;
		}	
	}
}




class MethodNameAndItsCountingInTheSpecificRankingOrderPair implements Comparable<MethodNameAndItsCountingInTheSpecificRankingOrderPair>
{
	String methodName;
	int counting;
	
	MethodNameAndItsCountingInTheSpecificRankingOrderPair(String methodName)
	{
	    this.methodName = methodName;
	    this.counting = 0;
	}
	
	
	public void increaseCounting()
	{
		this.counting = this.counting + 1;
	}
	
	
	public String getMethodName()
	{
		return this.methodName;
	}
	
	public double getCounting()
	{
		return this.counting;
	}


	@Override
	public int compareTo(MethodNameAndItsCountingInTheSpecificRankingOrderPair pair) 
	{
		if(this.counting == pair.counting)
		{
			return 0;
		}
		else if(this.counting < pair.counting)
		{
			return 1;
		}
		else 
		{
			return -1;
		}	
	}
}
