package Utilities.ExcelMakers;


import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;

import org.apache.poi.ss.usermodel.Workbook;
import org.apache.commons.math.stat.descriptive.DescriptiveStatistics;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import Utilities.ForecastingCostMeasures.TimeCost;


public class TimeCostResultsFileMaker 
{
	   String pathAndFileName;
	   FileOutputStream fileOutputStream;
	   Workbook workbook = new XSSFWorkbook();	
		
	   List<TimeCost[][]> outcomeOfDiverseMethods_TimeCosts; 
		
	   public TimeCostResultsFileMaker (String filePath, String fileName, List<TimeCost[][]> outcomeOfDiverseMethods_TimeCosts) throws FileNotFoundException
	   {
		  this.pathAndFileName = filePath + "/" + fileName;
	      this.fileOutputStream = new FileOutputStream(this.pathAndFileName+".xlsx");
		   
		  this.outcomeOfDiverseMethods_TimeCosts = outcomeOfDiverseMethods_TimeCosts;
	   }
	   
	   public void MakeFile() throws IOException, NoSuchMethodException, SecurityException, IllegalAccessException, IllegalArgumentException, InvocationTargetException
	   {
		  System.out.println("Make Time Cost Result File"); 
		   
		  createASheetForACost("PredictorProductionTime");
		  createASheetForACost("TrainingForecastsProductionTime");
		  createASheetForACost("TestingForecastsProductionTime");
		   
		  this.close();
		  
		  System.out.println("Done !!");
	   }
	   
	   private void createASheetForACost(String costName) throws NoSuchMethodException, SecurityException, IllegalAccessException, IllegalArgumentException, InvocationTargetException
	   {
		  Sheet sheet = this.workbook.createSheet(costName);
		  sheet.setDefaultColumnWidth(13);
		  List<Row> rows = new ArrayList<Row>();
		  
		  int numberOfForecastingMethods = this.outcomeOfDiverseMethods_TimeCosts.size();
		  
		  //create first column
		  Row title = sheet.createRow(0);
		  title.createCell(0).setCellValue(" ");
		  rows.add(title);

		  for(int i = 0;i<numberOfForecastingMethods;i++)
		  {
			  Row method = sheet.createRow(i+1);
			  method.createCell(0).setCellValue(((this.outcomeOfDiverseMethods_TimeCosts.get(i))[0][0]).getExperimentNumber().getMethodName());
			  rows.add(method);
		  }
		  
		  
		  Row bestMethod = sheet.createRow(numberOfForecastingMethods + 2);
		  bestMethod.createCell(0).setCellValue("BestMethod");
		  rows.add(bestMethod);
		  
		  
		  //create second and subsequent column
		  double[][] costValues = new double[numberOfForecastingMethods][this.outcomeOfDiverseMethods_TimeCosts.get(0).length * this.outcomeOfDiverseMethods_TimeCosts.get(0)[0].length];
		  int currentColumnNumber = 1;
		  
		  for(int i = 0;i<this.outcomeOfDiverseMethods_TimeCosts.get(0).length;i++)
		  {
			for(int j = 0;j<this.outcomeOfDiverseMethods_TimeCosts.get(0)[i].length;j++)
			{
				rows.get(0).createCell(currentColumnNumber).setCellValue("TS. "+i+"  Seg. "+j);
				
				//for identifying best method in this segment
				String methodWithBestResult = this.outcomeOfDiverseMethods_TimeCosts.get(0)[i][j].getExperimentNumber().getMethodName();
				Method firstMethod = this.outcomeOfDiverseMethods_TimeCosts.get(0)[i][j].getClass().getMethod("get" + costName, null);
				double bestResult = ((double) firstMethod.invoke(this.outcomeOfDiverseMethods_TimeCosts.get(0)[i][j], null));	
				
				
			    for(int k = 0;k<numberOfForecastingMethods;k++)
			    {
			       Method method = this.outcomeOfDiverseMethods_TimeCosts.get(k)[i][j].getClass().getMethod("get" + costName, null);
				   double value = ((double) method.invoke(this.outcomeOfDiverseMethods_TimeCosts.get(k)[i][j], null));	
			    	
			       rows.get(k+1).createCell(currentColumnNumber).setCellValue(value);	
			       costValues[k][currentColumnNumber - 1] = value;
			       
			       
			       if(value < bestResult)
			       {   //find a method with better result (lower error)
			    	   methodWithBestResult = this.outcomeOfDiverseMethods_TimeCosts.get(k)[i][j].getExperimentNumber().getMethodName();
			    	   bestResult = value;
			       }
			    }
			    
			    //set best method
			    rows.get(rows.size() - 1).createCell(currentColumnNumber).setCellValue(methodWithBestResult);
			    
			    currentColumnNumber++;
			}
		 }
		  

		 //set mean, min, max, SD of each method
		 rows.get(0).createCell(currentColumnNumber + 1).setCellValue("Mean");
		 rows.get(0).createCell(currentColumnNumber + 2).setCellValue("Min");
		 rows.get(0).createCell(currentColumnNumber + 3).setCellValue("Max");
		 rows.get(0).createCell(currentColumnNumber + 4).setCellValue("SD");
		  
		  
		 String bestMean = "";
		 String bestMin = "";
		 String bestMax = "";
		 String bestSD = "";
		  
		 double bestMeanValue = Double.MAX_VALUE;
		 double bestMinValue = Double.MAX_VALUE;
		 double bestMaxValue = Double.MAX_VALUE;
		 double bestSDValue = Double.MAX_VALUE;
		  
		  
		 for(int i = 0; i < costValues.length; i++)//different methods
		 {
			DescriptiveStatistics stats = new DescriptiveStatistics(); 
			  
			for(int j = 0; j < costValues[i].length; j++)
			{
			  stats.addValue(costValues[i][j]);
			}
			  
			double mean = stats.getMean();
			double min = stats.getMin();
			double max = stats.getMax();
			double sd = stats.getStandardDeviation();
			  
			rows.get(i + 1).createCell(currentColumnNumber + 1).setCellValue(mean);
			rows.get(i + 1).createCell(currentColumnNumber + 2).setCellValue(min);
			rows.get(i + 1).createCell(currentColumnNumber + 3).setCellValue(max);
			rows.get(i + 1).createCell(currentColumnNumber + 4).setCellValue(sd);
			  
			  
			if(mean < bestMeanValue)
			{
			   bestMean = this.outcomeOfDiverseMethods_TimeCosts.get(i)[0][0].getExperimentNumber().getMethodName();
			   bestMeanValue = mean;
			}
			  
			if(min < bestMinValue)
			{
				bestMin = this.outcomeOfDiverseMethods_TimeCosts.get(i)[0][0].getExperimentNumber().getMethodName();
				bestMinValue = min;
			}
			  
			if(max < bestMaxValue)
			{
				bestMax = this.outcomeOfDiverseMethods_TimeCosts.get(i)[0][0].getExperimentNumber().getMethodName();
				bestMaxValue = max;
			}
			  
			if(sd < bestSDValue)
			{
				bestSD = this.outcomeOfDiverseMethods_TimeCosts.get(i)[0][0].getExperimentNumber().getMethodName();
				bestSDValue = sd; 
			}
		 }
		  
		 rows.get(rows.size() - 1).createCell(currentColumnNumber + 1).setCellValue(bestMean);
		 rows.get(rows.size() - 1).createCell(currentColumnNumber + 2).setCellValue(bestMin);
		 rows.get(rows.size() - 1).createCell(currentColumnNumber + 3).setCellValue(bestMax);
		 rows.get(rows.size() - 1).createCell(currentColumnNumber + 4).setCellValue(bestSD);		  
	   }
	   
	   
	   private void close() throws IOException 
	   { 
	      this.workbook.write(this.fileOutputStream);
	      this.fileOutputStream.close();
	   }
}
