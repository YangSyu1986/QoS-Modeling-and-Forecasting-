package Utilities.ExcelMakers;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.math.stat.descriptive.DescriptiveStatistics;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import Utilities.DataStructures.Residuals;

public class ResidualFileMaker 
{
  List<Residuals[][]> outcomeOfDiverseMethods_Residuals;
	
  
  Workbook workbook = new XSSFWorkbook();	
  
  String pathAndFileName;
  FileOutputStream fileOutputStream;
  
	
  public  ResidualFileMaker( List<Residuals[][]> outcomeOfDiverseMethods_Residuals, String rootDirectoryPath, String fileName) throws FileNotFoundException
  {
	  this.outcomeOfDiverseMethods_Residuals = outcomeOfDiverseMethods_Residuals;
	  
	  this.pathAndFileName = rootDirectoryPath + "/" + fileName;
      this.fileOutputStream = new FileOutputStream(this.pathAndFileName+".xlsx");
  }
  
  public void MakeFile() throws IOException, NoSuchMethodException, SecurityException, IllegalAccessException, IllegalArgumentException, InvocationTargetException
  { 
	  this.createASheetForAResidualMean("TrainingResidualMean");
	  this.createASheetForAResidualMean("TestingResidualMean");
	  
	  this.createASheetForAResidualMean("TrainingLjungBoxTestPValue");
	  this.createASheetForAResidualMean("TestingLjungBoxTestPValue");
	  
	  this.createASheetForAResidualMean("TrainingBoxCoxLambdaValue");
	  this.createASheetForAResidualMean("TestingBoxCoxLambdaValue");
	  
	  this.createASheetForAResidualMean("TrainingKolmogorovSmirnovTestPValue");
	  this.createASheetForAResidualMean("TestingKolmogorovSmirnovTestPValue");
	   
	  this.close();
  }
  
  private void createASheetForAResidualMean(String residualType) throws NoSuchMethodException, SecurityException, IllegalAccessException, IllegalArgumentException, InvocationTargetException
  {
	  Sheet sheet = this.workbook.createSheet(residualType);
	  sheet.setDefaultColumnWidth(13);
	  List<Row> rows = new ArrayList<Row>();
	  
	  int numberOfMethods = this.outcomeOfDiverseMethods_Residuals.size();
	  
	  //create first column
	  Row title = sheet.createRow(0);
	  title.createCell(0).setCellValue(" ");
	  rows.add(title);

	  for(int i = 0; i < numberOfMethods; i++)
	  {
		  Row method = sheet.createRow(i + 1);
		  
		  if(((this.outcomeOfDiverseMethods_Residuals.get(i))[0][0]).getExperimentNumber().getMethodName().contains("GP"))
		  {
			method.createCell(0).setCellValue(((this.outcomeOfDiverseMethods_Residuals.get(i))[0][0]).getExperimentNumber().getMethodName() + "_" + ((this.outcomeOfDiverseMethods_Residuals.get(i))[0][0]).getExperimentNumber().getRepeatNumber() ); 
		  }
		  else
		  {
			method.createCell(0).setCellValue(((this.outcomeOfDiverseMethods_Residuals.get(i))[0][0]).getExperimentNumber().getMethodName());
		  }
		  
		  rows.add(method);
	  }
	  
	  
	  //prepare statistical objects
	  DescriptiveStatistics[] stats = new DescriptiveStatistics[numberOfMethods]; 
	  for(int i = 0; i < stats.length; i++)
	  {
		  stats[i] = new DescriptiveStatistics();
	  }
	  
	  
	  //create second and subsequent column
	  int currentColumnNumber = 1;
	  
	  for(int i = 0; i < this.outcomeOfDiverseMethods_Residuals.get(0).length; i++)
	  {
		for(int j = 0; j < this.outcomeOfDiverseMethods_Residuals.get(0)[i].length; j++)
		{
			rows.get(0).createCell(currentColumnNumber).setCellValue("TS. "+i+"  Seg. "+j);
			
			
		    for(int k = 0; k < numberOfMethods; k++)
		    {
		       Method method = this.outcomeOfDiverseMethods_Residuals.get(k)[i][j].getClass().getMethod("get" + residualType, null);
			   double value = ((double) method.invoke(this.outcomeOfDiverseMethods_Residuals.get(k)[i][j], null));	
		    	
		       rows.get(k+1).createCell(currentColumnNumber).setCellValue(value);	
		      
		       stats[k].addValue(value);
		    }
		    
		    
		    currentColumnNumber++;
		}
	 }
	  
	  
	 //statistical results 
	/** rows.get(0).createCell(currentColumnNumber + 2).setCellValue("Mean");
	 rows.get(0).createCell(currentColumnNumber + 3).setCellValue("Min");
	 rows.get(0).createCell(currentColumnNumber + 4).setCellValue("Max");
	 rows.get(0).createCell(currentColumnNumber + 5).setCellValue("SD"); 
	 
	 for(int i = 0; i < numberOfMethods; i++)//label method names
	 {
		rows.get(i + 1).createCell(currentColumnNumber + 1).setCellValue(((this.outcomeOfDiverseMethods_Residuals.get(i))[0][0]).getExperimentNumber().getMethodName());
	 }
	 
	 
	  for(int i = 0; i < numberOfMethods; i++)//different methods
	  { 
		rows.get(i + 1).createCell(currentColumnNumber + 2).setCellValue(stats[i].getMean());
		rows.get(i + 1).createCell(currentColumnNumber + 3).setCellValue(stats[i].getMin());
		rows.get(i + 1).createCell(currentColumnNumber + 4).setCellValue(stats[i].getMax());
		rows.get(i + 1).createCell(currentColumnNumber + 5).setCellValue(stats[i].getStandardDeviation());
	  }*/
  }
  
  
  private void close() throws IOException 
  { 
     this.workbook.write(this.fileOutputStream);
     this.fileOutputStream.close();
  }
	
}
