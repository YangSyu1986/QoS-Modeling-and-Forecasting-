package Utilities.TimeSeriesAnalysis;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.math.stat.descriptive.DescriptiveStatistics;

public class AnalyzingResults 
{   
	String statisticalMethod;
	List<List<Double>> analyzingNumericalResults;
	

	double mean;
	double minimun;
	double maximum;
	double standardDeviation;
	
	
	public String getStatisticalMethod() 
	{
		return statisticalMethod;
	}

	public AnalyzingResults(String statisticalMethod)
	{
		this.statisticalMethod = statisticalMethod;
	}
	
	public List<List<Double>> getAnalyzingNumericalResults() 
	{
		return analyzingNumericalResults;
	}
	
	public void setAnalyzingNumericalResultsAndCalculateTheirStatisticalResults(List<List<Double>> analyzingNumericalResults) 
	{
		 this.analyzingNumericalResults = analyzingNumericalResults;
		
		
		 DescriptiveStatistics stats = new DescriptiveStatistics(); 
		
		 for(List<Double> timeSeries : analyzingNumericalResults)
		 {	     
			 for(Double value : timeSeries)
			 {				
				  stats.addValue(value);
			 }
		 }
		 
		 this.mean = stats.getMean();
		 this.minimun = stats.getMin();
		 this.maximum = stats.getMax();
		 this.standardDeviation = stats.getStandardDeviation();
	}
	
	
	
	public double getMean() 
	{
		return mean;
	}

	public double getMinimun() 
	{
		return minimun;
	}

	public double getMaximum() 
	{
		return maximum;
	}
	
	public double getStandardDeviation() 
	{
		return standardDeviation;
	}

}
