package Utilities.TimeSeriesAnalysis;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class AnalyzingOutcomeOutputToExcelFile 
{
	private List<AnalyzingResults> outcomeToOutput;
	
	private String rootDirectoryPath;  
	private String directoryPath;
	private String fileName;
	private FileOutputStream fileOutputStream;
	
	private Workbook workbook;
	private Sheet sheet;
    

	public AnalyzingOutcomeOutputToExcelFile(String rootDirectoryPath)
	{
		this.rootDirectoryPath = rootDirectoryPath;
	}
	
	public void setAnalyzingOutcomeToOutput(List<AnalyzingResults> analyzingOutcomeToOutput) 
	{
		this.outcomeToOutput = analyzingOutcomeToOutput;
	}
	
	public void outputExcelFile(String fileName) throws IOException
	{
		this.fileName = fileName;
		this.directoryPath = this.rootDirectoryPath + "/Divided Time Series Segments/Time Series Analysis Outcome";
		
		this.makeDirectory();
		this.createFile();
		this.createExcelAndFormat();
		this.writeExcel();
		this.close();
		
	}
	
	private void makeDirectory()
	{
		File targetdDirectory=new File(this.directoryPath);
		targetdDirectory.mkdir(); 
	}
	
	private void createFile() throws FileNotFoundException
	{
		this.fileOutputStream = new FileOutputStream(this.directoryPath+"/"+this.fileName+".xlsx");
	}
	
	private void createExcelAndFormat() throws IOException
	{
		this.workbook =  new XSSFWorkbook();
		
		this.sheet = this.workbook.createSheet();  
	    this.sheet.setDefaultColumnWidth(20);
		
	    Row titleRow = this.sheet.createRow(0);
		
		(titleRow.createCell(0)).setCellValue("Statis. Method");
		
		
		List<List<Double>> analyzingNumericalResults = this.outcomeToOutput.get(0).getAnalyzingNumericalResults();
		
		int titleIndex = 1;
		
		for(int i=0;i<analyzingNumericalResults.size();i++)
		{
			for(int j=0;j<analyzingNumericalResults.get(0).size();j++)
			{
				(titleRow.createCell(titleIndex)).setCellValue("TS "+i+", Seg. "+j);
				titleIndex++;
			}
		}
		
		
		titleIndex = titleIndex + 1;
		(titleRow.createCell(titleIndex + 1)).setCellValue("Mean");
		(titleRow.createCell(titleIndex + 2)).setCellValue("Minimun");
		(titleRow.createCell(titleIndex + 3)).setCellValue("Maximum");
		(titleRow.createCell(titleIndex + 4)).setCellValue("StandardDeviation");
	}
	
	private void writeExcel()
	{
		for(int i=0;i<this.outcomeToOutput.size();i++)
		{
			AnalyzingResults result = this.outcomeToOutput.get(i);
			
			Row titleRow = this.sheet.createRow(i+1);
			(titleRow.createCell(0)).setCellValue(result.getStatisticalMethod());
			
			List<List<Double>> data = result.getAnalyzingNumericalResults();
			
			int index = 1;
			
			for(int j=0;j<data.size();j++)
			{
				for(int k=0;k<data.get(j).size();k++)
				{
					(titleRow.createCell(index)).setCellValue(data.get(j).get(k));
					index++;
				}
			}
			
			
			(titleRow.createCell(index + 1)).setCellValue(result.getStatisticalMethod());
			(titleRow.createCell(index + 2)).setCellValue(result.getMean());
			(titleRow.createCell(index + 3)).setCellValue(result.getMinimun());
			(titleRow.createCell(index + 4)).setCellValue(result.getMaximum());
			(titleRow.createCell(index + 5)).setCellValue(result.getStandardDeviation());
			
			index=0;
		}
		
	}
	
	private void close() throws IOException
	{
		this.workbook.write(this.fileOutputStream);
	    this.fileOutputStream.close();
	}
}
