package Utilities.TimeSeriesAnalysis;

import java.io.File;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.math.stat.descriptive.DescriptiveStatistics;

import Utilities.DatasetProcessingModules.ObservationsAtOneTimePoint;
import Utilities.FormalStatisticalTesting.StatisticalTestingIntseries;

public class TimeSeriesAnalyzer 
{   //original time series
   private List<List<ObservationsAtOneTimePoint>> timeSeriesSet;
   
    //index set of training, validating, and testing data 
   private int[][][] trainingDataIntervalsSets;
   private int[][][] validatingDataIntervalsSets;
   private int[][][] testingDataIntervalsSets;
   
    //processed time series sets  (services, segments, data)
   private List<List<List<Double>>> trainingTimeSeriesSets;
   private List<List<List<Double>>> validatingTimeSeriesSets;
   private List<List<List<Double>>> testingTimeSeriesSets;
   
    //analyzing results
   private List<AnalyzingResults> trainingSegmentsAnalyzingResults;
   private List<AnalyzingResults> validatingSegmentsAnalyzingResults;
   private List<AnalyzingResults> testingSegmentsAnalyzingResults;
   

   public TimeSeriesAnalyzer(List<List<ObservationsAtOneTimePoint>> timeSeriesSet, int[][][] trainingDataIntervalsSets,
		                     int[][][] validatingDataIntervalsSets, int[][][] testingDataIntervalsSets)
   {
	 this.timeSeriesSet = timeSeriesSet;
	 
	 this.trainingDataIntervalsSets = trainingDataIntervalsSets;
	 this.validatingDataIntervalsSets = validatingDataIntervalsSets;
	 this.testingDataIntervalsSets = testingDataIntervalsSets;
   }
   
   public void performeAnalysis() throws NoSuchMethodException, SecurityException, IllegalAccessException, IllegalArgumentException, InvocationTargetException
   {
	 this.trainingTimeSeriesSets = this.processAndBuildDividedTimeSeries(this.trainingDataIntervalsSets);
	 this.validatingTimeSeriesSets = this.processAndBuildDividedTimeSeries(this.validatingDataIntervalsSets);
	 this.testingTimeSeriesSets = this.processAndBuildDividedTimeSeries(this.testingDataIntervalsSets);
	  
	 this.trainingSegmentsAnalyzingResults = this.analyzeTimeSeries(this.trainingTimeSeriesSets);
	 this.validatingSegmentsAnalyzingResults = this.analyzeTimeSeries(this.validatingTimeSeriesSets);
	 this.testingSegmentsAnalyzingResults = this.analyzeTimeSeries(this.testingTimeSeriesSets);
	 
	 File directory = new File("/Users/YangSyu/Desktop/Time Series Experiment/Divided Time Series Segments");
	 directory.mkdir();
   }
   
   
   private List<List<List<Double>>> processAndBuildDividedTimeSeries(int[][][] intervalSets)
   {
	 List<List<List<Double>>> dividedTimeSeriesSets = new ArrayList<List<List<Double>>>();    
	   
	 for(int i=0;i<this.timeSeriesSet.size();i++)
	 {
		 List<ObservationsAtOneTimePoint> timeSeries=this.timeSeriesSet.get(i);
		 List<List<Double>> timeSeriesSegments = new ArrayList<List<Double>>();
		 
		 for(int[][] intervals : intervalSets)
		 {
			 List<Double> timeSeriesSegment=new ArrayList<Double>();
			 
			 for(int[] interval : intervals)
			 {
				 for(int s=interval[0];s<=interval[1];s++)
				 {
				   timeSeriesSegment.add((double)timeSeries.get(s).getResponseTime());
				 } 
			 }
			 
			 timeSeriesSegments.add(timeSeriesSegment);
		 }
		 
		 dividedTimeSeriesSets.add(timeSeriesSegments);
	 }
	 
	 return dividedTimeSeriesSets;
   }
   	
   
   private List<AnalyzingResults> analyzeTimeSeries(List<List<List<Double>>> analyzingTargets) throws NoSuchMethodException, SecurityException, IllegalAccessException, IllegalArgumentException, InvocationTargetException
   {
	 //Descriptive Statistic analysis  
	 List<AnalyzingResults> results = new ArrayList<AnalyzingResults>();
	  
	 AnalyzingResults minimum = new AnalyzingResults("Minimum");
	 minimum.setAnalyzingNumericalResultsAndCalculateTheirStatisticalResults(this.calculate_DescriptiveStatistics("getMin", analyzingTargets));
	 results.add(minimum);
	 
	 AnalyzingResults maximum = new AnalyzingResults("Maximum");
	 maximum.setAnalyzingNumericalResultsAndCalculateTheirStatisticalResults(this.calculate_DescriptiveStatistics("getMax", analyzingTargets));
	 results.add(maximum);
	 
	 AnalyzingResults mean = new AnalyzingResults("Mean");
	 mean.setAnalyzingNumericalResultsAndCalculateTheirStatisticalResults(this.calculate_DescriptiveStatistics("getMean", analyzingTargets));
	 results.add(mean);
	 
	 AnalyzingResults standardDeviation = new AnalyzingResults("StandardDeviation");
	 standardDeviation.setAnalyzingNumericalResultsAndCalculateTheirStatisticalResults(this.calculate_DescriptiveStatistics("getStandardDeviation", analyzingTargets));
	 results.add(standardDeviation);
	 
	 AnalyzingResults variance = new AnalyzingResults("Variance");
	 variance.setAnalyzingNumericalResultsAndCalculateTheirStatisticalResults(this.calculate_DescriptiveStatistics("getVariance", analyzingTargets));
	 results.add(variance);
	 
	 AnalyzingResults skewness = new AnalyzingResults("Skewness");
	 skewness.setAnalyzingNumericalResultsAndCalculateTheirStatisticalResults(this.calculate_DescriptiveStatistics("getSkewness", analyzingTargets));
	 results.add(skewness);
	
	 AnalyzingResults kurtosis = new AnalyzingResults("Kurtosis");
	 kurtosis.setAnalyzingNumericalResultsAndCalculateTheirStatisticalResults(this.calculate_DescriptiveStatistics("getKurtosis", analyzingTargets));
	 results.add(kurtosis);
	 
	
	 //Statistical Testing analysis  
	 AnalyzingResults KPSS_Level = new AnalyzingResults("KPSS_Level");
	 KPSS_Level.setAnalyzingNumericalResultsAndCalculateTheirStatisticalResults(this.calculate_StatisticalTesting("KPSS_Level", analyzingTargets));
	 results.add(KPSS_Level);
	 
	 AnalyzingResults KPSS_Trend = new AnalyzingResults("KPSS_Trend");
	 KPSS_Trend.setAnalyzingNumericalResultsAndCalculateTheirStatisticalResults(this.calculate_StatisticalTesting("KPSS_Trend", analyzingTargets));
	 results.add(KPSS_Trend);
	 
	 AnalyzingResults Terasvirta_test = new AnalyzingResults("Terasvirta_test");
	 Terasvirta_test.setAnalyzingNumericalResultsAndCalculateTheirStatisticalResults(this.calculate_StatisticalTesting("Terasvirta_test", analyzingTargets));
	 results.add(Terasvirta_test);
	 
	 AnalyzingResults White_test = new AnalyzingResults("White_test");
	 White_test.setAnalyzingNumericalResultsAndCalculateTheirStatisticalResults(this.calculate_StatisticalTesting("White_test", analyzingTargets));
	 results.add(White_test);
	 
	 return results; 
   }
   
   private List<List<Double>> calculate_DescriptiveStatistics(String statisticalMethodName, List<List<List<Double>>> analyzingTargets) throws NoSuchMethodException, SecurityException, IllegalAccessException, IllegalArgumentException, InvocationTargetException
   {
	   DescriptiveStatistics stats = new DescriptiveStatistics();
	    
	   List<List<Double>> allResults = new ArrayList<List<Double>>();
	   
	   
	   for(List<List<Double>> timeSeriesSegments : analyzingTargets)
	   {
		 List<Double> segmentResults = new ArrayList<Double>();
			     
		 for(List<Double> segment : timeSeriesSegments)
		 {			
			for(Double value : segment)
			{
			  stats.addValue(value);
			}
			
			Method method = stats.getClass().getMethod(statisticalMethodName, null);
			Double result = new Double((double) method.invoke(stats, null)); 
			
			segmentResults.add(result);
				
			stats.clear();
		 }	
		 
		 allResults.add(segmentResults);
		}
	   
	   return allResults;
   }
   
   
   private List<List<Double>> calculate_StatisticalTesting(String statisticalMethodName, List<List<List<Double>>> analyzingTargets) throws NoSuchMethodException, SecurityException, IllegalAccessException, IllegalArgumentException, InvocationTargetException
   {
	   StatisticalTestingIntseries  stats = new StatisticalTestingIntseries();
	   stats.prepareREngine();
	    
	   List<List<Double>> allResults = new ArrayList<List<Double>>();
	   
	   
	   for(List<List<Double>> timeSeriesSegments : analyzingTargets)
	   {
		 List<Double> segmentResults = new ArrayList<Double>();
			     
		 for(List<Double> segment : timeSeriesSegments)
		 {		
			double[] dataInArray = new double[segment.size()]; 
			 
			for(int i = 0; i < dataInArray.length; i++)
			{
				dataInArray[i] = segment.get(i);
			}
			
			stats.setData(dataInArray);
			
			Method method = stats.getClass().getMethod("calculate" + statisticalMethodName, null);
			Double result = new Double((double) method.invoke(stats, null)); 
			
			segmentResults.add(result);
		 }	
		 
		 allResults.add(segmentResults);
		}
	   
	   return allResults;
   }
   
   
   public List<AnalyzingResults> getTrainingSegmentsAnalyzingResults() 
   {
	 return trainingSegmentsAnalyzingResults;
   }

   public List<AnalyzingResults> getValidatingSegmentsAnalyzingResults() 
   {
	 return validatingSegmentsAnalyzingResults;
   }

   public List<AnalyzingResults> getTestingSegmentsAnalyzingResults() 
   {
    return testingSegmentsAnalyzingResults;
   }
   
   
   public List<List<List<Double>>> getTrainingTimeSeriesSets() 
   {
	return trainingTimeSeriesSets;
   }

   public List<List<List<Double>>> getValidatingTimeSeriesSets() 
   {
	return validatingTimeSeriesSets;
   }

   public List<List<List<Double>>> getTestingTimeSeriesSets() 
   {
	return testingTimeSeriesSets;
   }
}
