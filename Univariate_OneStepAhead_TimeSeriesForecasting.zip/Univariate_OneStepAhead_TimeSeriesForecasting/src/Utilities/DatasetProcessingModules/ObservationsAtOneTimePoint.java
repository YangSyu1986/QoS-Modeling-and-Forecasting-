/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Utilities.DatasetProcessingModules;

/**
 *
 * @author YangSyu
 */
public class ObservationsAtOneTimePoint 
{
  
    private String date;
    private int size;
    private float responseTime;
    private double throughPut;
    private boolean error;

    
    public String getDate()
    {
        return date;
    }

    public void setDate(String date)
    {
        this.date = date;
    }

    public int getSize()
    {
        return size;
    }

    public void setSize(int size)
    {
        this.size = size;
    }

    public float getResponseTime() 
    {
        return responseTime;
    }

    public void setResponseTime(float responseTime) 
    {
        this.responseTime = responseTime;
    }

    public double getThroughPut() 
    {
        return throughPut;
    }

    public void setThroughPut(double throughPut) 
    {
        this.throughPut = throughPut;
    }

    public boolean isError()
    {
        return error;
    }

    public void setError(boolean error) 
    {
        this.error = error;
    }
    
    
}
