package Utilities.DatasetProcessingModules.SelfCollectedQoSTimeSeries;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import Utilities.DatasetProcessingModules.ObservationsAtOneTimePoint;

public class DatasetProcessor
{
	private int jump = 1;//for different time granularity
	
	
	public DatasetProcessor()
	{
	}
	
	public DatasetProcessor(int jump)
	{
	  this.jump = jump;
	}
	
	public List<List<ObservationsAtOneTimePoint>> getFourQoSTimeSeries() throws FileNotFoundException, IOException
    {
      String directoryPath="/Users/YangSyu/Google Drive/DataSets/Self Collected QoS Time Series";    
      File directoryWithSourceFiles=new File(directoryPath);  
      String[] sourceFiles= directoryWithSourceFiles.list();
  
      List<List<ObservationsAtOneTimePoint>> dataset = new ArrayList<List<ObservationsAtOneTimePoint>>(); //for storing acquired dataset
      
      
      for(int i = 0; i < sourceFiles.length; i++)//read all four QoS time series from hard disk
      {
        System.out.println("Service " + (i) + " : " + sourceFiles[i]);
        
        String targetQoSTimeSeriesFilePath = directoryPath+"/"+sourceFiles[i]; 
        
        List<ObservationsAtOneTimePoint> newQoSTimeSeries = this.readSourceDataFileAndGenerateTimeSeries(targetQoSTimeSeriesFilePath);
        
        System.out.println("The length : " + newQoSTimeSeries.size());
        
        dataset.add(newQoSTimeSeries);
      }
      
      return dataset;
    }
    
	
	private List<ObservationsAtOneTimePoint> readSourceDataFileAndGenerateTimeSeries(String filePath) throws FileNotFoundException, IOException
    {
      List<ObservationsAtOneTimePoint> QoSTimeSeries = new ArrayList<ObservationsAtOneTimePoint>();//for storing a service's time series 
      
        
      BufferedReader reader = new BufferedReader(new FileReader(filePath));
      
      
      String line;
      
      float responseTime = 0;

      int tempJump = this.jump;//for different time granularity
      
      
      while (((line = reader.readLine()) != null))//read data line by line
      {  
    	tempJump--; //for different time granularity 
    	  
    	if(tempJump == 0)  //for different time granularity 
    	{  
          ObservationsAtOneTimePoint timePointData = new ObservationsAtOneTimePoint();
        
          responseTime = Float.parseFloat(line);
            
          if(responseTime > 0.0)
          {
        	 timePointData.setResponseTime(responseTime);
          }
        
        
          QoSTimeSeries.add(timePointData);
          
          
          tempJump = this.jump;
    	}
      }
        
      reader.close();
        
      return QoSTimeSeries;  
    }
}
