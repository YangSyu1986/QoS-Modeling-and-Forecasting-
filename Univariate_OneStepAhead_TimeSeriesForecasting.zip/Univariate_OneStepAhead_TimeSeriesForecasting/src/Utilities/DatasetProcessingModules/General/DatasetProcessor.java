package Utilities.DatasetProcessingModules.General;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import Utilities.DatasetProcessingModules.ObservationsAtOneTimePoint;

public class DatasetProcessor 
{
	public List<List<ObservationsAtOneTimePoint>> getTimeSeries(String file) throws FileNotFoundException, IOException
	{
	      File sourceFile = new File(file);  
	  
	      return  this.readSourceDataFileAndGenerateTimeseries(sourceFile.getAbsolutePath());
	}
	
	
	private List<List<ObservationsAtOneTimePoint>> readSourceDataFileAndGenerateTimeseries(String filePath) throws FileNotFoundException, IOException
	{
	      BufferedReader reader = new BufferedReader(new FileReader(filePath));	      
	      
	      
	      List<List<ObservationsAtOneTimePoint>> dataset = new ArrayList<List<ObservationsAtOneTimePoint>>();
	      List<ObservationsAtOneTimePoint> timeSeries = new ArrayList<ObservationsAtOneTimePoint>();
	      
	      String line;
	     
	      while (((line = reader.readLine()) != null))//read data line by line
	      {  
	    	  ObservationsAtOneTimePoint timePointData = new ObservationsAtOneTimePoint();
			  timePointData.setResponseTime(Float.parseFloat(line)); 
			 
			  timeSeries.add(timePointData);
	      }
	     
	      
	      dataset.add(timeSeries);//for saving last time series
	     
	      
	      reader.close();  
	      
	     
	      System.out.println("The number of total time series: " + dataset.size());
	      
	      System.out.println("The length : " + timeSeries.size());
	      
	      return dataset;
	 }
}
