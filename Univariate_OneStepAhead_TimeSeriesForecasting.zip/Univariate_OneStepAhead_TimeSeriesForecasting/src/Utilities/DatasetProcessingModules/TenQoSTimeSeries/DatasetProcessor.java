/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Utilities.DatasetProcessingModules.TenQoSTimeSeries;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import Utilities.DatasetProcessingModules.ObservationsAtOneTimePoint;

/**
 *
 * @author YangSyu
 */
public class DatasetProcessor 
{
 
    public List<List<ObservationsAtOneTimePoint>> getTenQoSTimeSeries() throws FileNotFoundException, IOException
    {
      String directoryPath="/Users/YangSyu/Google Drive/DataSets/QoS Time Series Datasets_10 services";    
      File directoryWithSourceFiles=new File(directoryPath);  
      String[] sourceFiles= directoryWithSourceFiles.list();
      
      List<List<ObservationsAtOneTimePoint>> dataset = new ArrayList<List<ObservationsAtOneTimePoint>>(); //for storing acquired dataset
      
      
      for(int i=1;i<sourceFiles.length;i++)//read all ten QoS time series from hard disk
      {
        System.out.println("Service "+(i-1)+" : "+sourceFiles[i]);
        
        String targetQoSTimeSeriesFilePath = directoryPath+"/"+sourceFiles[i]; 
        
        List<ObservationsAtOneTimePoint> newQoSTimeSeries = this.readSourceDataFileAndGenerateTimeSeries(targetQoSTimeSeriesFilePath);
        
        System.out.println("The length : " + newQoSTimeSeries.size());
        
        dataset.add(newQoSTimeSeries);
      }
      
      return dataset;
    }
    
    
    private List<ObservationsAtOneTimePoint> readSourceDataFileAndGenerateTimeSeries(String filePath) throws FileNotFoundException, IOException
    {
      List<ObservationsAtOneTimePoint> QoSTimeSeries = new ArrayList<ObservationsAtOneTimePoint>();//for storing a service's time series 
      
        
      BufferedReader reader = new BufferedReader(new FileReader(filePath));
      
      
      for(int i=0;i<11;i++) //skip the first line ("TIME,SIZE,RESP,TH,ERROR", the first line in each CSV file)
      {                     //skip the time series data at the first ten time points             
        reader.readLine();
      }
   
      
      String line;
      Scanner scanner;
      int index = 0;
      
      while (((line = reader.readLine()) != null) )//read data line by line
      {    
        scanner = new Scanner(line);
        scanner.useDelimiter(",");
        index = 0;
       
        ObservationsAtOneTimePoint timePointData = new ObservationsAtOneTimePoint();
       
        while (scanner.hasNext())//separate observations in a line
        {
          String data = scanner.next();
                
          if(index == 0)
             timePointData.setDate(data);
          else if(index == 1)
             timePointData.setSize(Integer.parseInt(data));
          else if(index == 2)
             timePointData.setResponseTime(Float.parseFloat(data));
          else if (index == 3)
             timePointData.setThroughPut(Double.parseDouble(data));
          else if (index == 4)
          {
             String error=data;
            
             if(error.equals("NO"))
                timePointData.setError(false);
             else
                timePointData.setError(true);
          }
          
          index++;
         }
        
         QoSTimeSeries.add(timePointData);
        }
        
        reader.close();
        
        
        return QoSTimeSeries;  
    }
}
