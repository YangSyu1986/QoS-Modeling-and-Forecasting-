package Utilities.DatasetProcessingModules.WSDreamDatasets;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Scanner;

import Utilities.DatasetProcessingModules.ObservationsAtOneTimePoint;

public class TimeAwareDatasetProcessor 
{
	float[][][] tensor = new float[142][4532][64]; //the dimensions of the dataset (tensor) are (142 Users) X (4532 WSs) X (64 TimeSlices) according to the original paper
	
	public void processDatasetAndSerializeTensor() throws FileNotFoundException, IOException
    {
      String directoryPath="/Users/YangSyu/Google Drive/DataSets/WSDream Datasets/dataset2";    
      File directoryWithSourceFiles=new File(directoryPath);  
      String[] sourceFiles= directoryWithSourceFiles.list();
      
      String targetResponseTimeDatasetFilePath = directoryPath+"/"+sourceFiles[1];//Response-Time dataset is the second file in the folder 
       
         
      this.readSourceDatasetAndCreateAndSerializeTensor(targetResponseTimeDatasetFilePath);
    }
	
	
	private void readSourceDatasetAndCreateAndSerializeTensor(String filePath) throws FileNotFoundException, IOException
    {
      BufferedReader reader = new BufferedReader(new FileReader(filePath));
      
      String line;
      Scanner scanner;
      
      while (((line = reader.readLine()) != null) )//read data line by line
      {    
    	 scanner = new Scanner(line);
         scanner.useDelimiter(" ");
          
         //fill the data tensor 
         this.tensor[ Integer.parseInt(scanner.next()) ] [ Integer.parseInt(scanner.next()) ] [ Integer.parseInt(scanner.next()) ] 
        		 = (Float.parseFloat(scanner.next()) * 1000); 
         
      }
        
      reader.close();  
      
      
      //serialize the tensor into HD
      try
      {
          FileOutputStream fos = new FileOutputStream("/Users/YangSyu/Google Drive/DataSets/WSDream Datasets/dataset2/tensor.dat");
          ObjectOutputStream oos = new ObjectOutputStream(fos);
          oos.writeObject(this.tensor);  
      } 
      catch(Exception e)
      {}
    }
	
	public List<List<ObservationsAtOneTimePoint>> deserializeAndGetQoSTimeseries()
	{
	   try//deserialize the tensor from HD and re-construct the tensor
	   {	
		 FileInputStream fis = new FileInputStream("/Users/YangSyu/Google Drive/DataSets/WSDream Datasets/dataset2/tensor.dat");
         ObjectInputStream iis = new ObjectInputStream(fis);
         this.tensor = (float[][][]) iis.readObject();	
	   }
	   catch(Exception e)
	   {}
         
	   
	   //construct QoS time series
	   List<List<ObservationsAtOneTimePoint>> QoSTimeSeries = new ArrayList<List<ObservationsAtOneTimePoint>>();
		
	   for(int i = 0; i < this.tensor.length; i++)
	   {
		   for(int j = 0; j < this.tensor[i].length; j++)
		   {
			   List<ObservationsAtOneTimePoint> singleTimeSeries = new ArrayList<ObservationsAtOneTimePoint>();
			   boolean isValidTS = true;
			   
			   //for(int k = 0; k < this.tensor[i][j].length; k = k + 4)   //for hourly interval
			   //for(int k = 0; k < this.tensor[i][j].length; k = k + 2)   //for 30-minutes interval
			   for(int k = 0; k < this.tensor[i][j].length; k++)   //for 15-minutes interval
			   {
				 float QoSValue = this.tensor[i][j][k];
				 
				 if(QoSValue <= 0.0 ||  QoSValue >= 20000.0)
				 {
					isValidTS = false;
					break; 
				 }
				 else
				 {
					ObservationsAtOneTimePoint timePointData = new ObservationsAtOneTimePoint();
					timePointData.setResponseTime(QoSValue);
					
					singleTimeSeries.add(timePointData);
				 }
			   } 
			   
			   
			   if(isValidTS)
			   {
				   QoSTimeSeries.add(singleTimeSeries);
			   }	   
		   }
	   }   
	   
	   
	   System.out.println("The number of total time series: " + (this.tensor.length * this.tensor[0].length));   
	   System.out.println("The number of valid time series: " +  QoSTimeSeries.size());
	 
	   Collections.shuffle(QoSTimeSeries);//shuffle the set of time series
	   
	   QoSTimeSeries = QoSTimeSeries.subList(0, 2000);
	   
	   this.tensor = null;//for releasing memory
	   
	   return QoSTimeSeries;
	}
}
