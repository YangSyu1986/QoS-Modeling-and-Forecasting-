package Utilities.DatasetProcessingModules.AminDataset;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Scanner;

import Utilities.DatasetProcessingModules.ObservationsAtOneTimePoint;

public class DatasetProcessor 
{
	  public List<List<ObservationsAtOneTimePoint>> getTimeSeries() throws FileNotFoundException, IOException
	  {
	      String directoryPath="/Users/YangSyu/Google Drive/DataSets/AminDatasets/RealWSsResponseTimes";    
	      File directoryWithSourceFiles=new File(directoryPath);  
	      String[] sourceFiles= directoryWithSourceFiles.list();
	      
	      String targetResponseTimeDatasetFilePath = directoryPath+"/"+sourceFiles[1];//Response Time (cvs) dataset 
	      
	      return  this.readSourceDataFileAndGenerateTimeseries(targetResponseTimeDatasetFilePath);
	  }
	  
	  
	  private List<List<ObservationsAtOneTimePoint>> readSourceDataFileAndGenerateTimeseries(String filePath) throws FileNotFoundException, IOException
	  {
	      BufferedReader reader = new BufferedReader(new FileReader(filePath));
	      
	      String line;
	      Scanner scanner;
	      
	      reader.readLine();//for skipping the first row of the excel file (column names)
	      scanner = (new Scanner( reader.readLine()).useDelimiter(","));
	      scanner.next(); scanner.next(); 
	      String CurrentWSId =  scanner.next();//first WS Id
	      
	      
	      reader = new BufferedReader(new FileReader(filePath));
	      reader.readLine();//for skipping the first row of the excel file (column names)
	      
	      
	      List<List<ObservationsAtOneTimePoint>> dataset = new ArrayList<List<ObservationsAtOneTimePoint>>();
	      List<ObservationsAtOneTimePoint> timeSeries = new ArrayList<ObservationsAtOneTimePoint>();
	      
	      while (((line = reader.readLine()) != null) )//read data line by line
	      {    
	    	 scanner = new Scanner(line);
	         scanner.useDelimiter(",");
	          
	         scanner.next(); scanner.next(); 
	         String WSId = scanner.next(); //current WS Id
	         String responseTime =  scanner.next(); //current response time
	         
	         
	         if( !CurrentWSId.equals(WSId) )//if true, this is another WS
	         {
	        	 dataset.add(timeSeries);//for the previous time series
	        	 timeSeries = new ArrayList<ObservationsAtOneTimePoint>();//for new time series
	    	      	 
	        	 CurrentWSId = WSId;//chnage old WS Id to new WS Id
	         }
	         
	         
	         ObservationsAtOneTimePoint timePointData = new ObservationsAtOneTimePoint();
			 timePointData.setResponseTime(Float.parseFloat(responseTime)); 
			 
			 timeSeries.add(timePointData);
	      }
	      
	      dataset.add(timeSeries);//for saving last time series
	        
	      reader.close();  
	      
	      
	      System.out.println("The number of total time series: " + dataset.size());
	      
	      
	      Collections.shuffle(dataset);//shuffle the set of time series
	      
	      
	      return dataset;
	  }
}
