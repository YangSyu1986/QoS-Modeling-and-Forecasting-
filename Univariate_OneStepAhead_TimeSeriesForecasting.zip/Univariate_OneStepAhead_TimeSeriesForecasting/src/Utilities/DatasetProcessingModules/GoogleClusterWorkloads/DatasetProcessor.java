package Utilities.DatasetProcessingModules.GoogleClusterWorkloads;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import Utilities.DatasetProcessingModules.ObservationsAtOneTimePoint;

public class DatasetProcessor 
{
	
	
	public List<List<ObservationsAtOneTimePoint>> getTimeSeries() throws FileNotFoundException, IOException
    {
      String directoryPath = "/Users/YangSyu/Google Drive/DataSets/Google Cluster Workloads";    
      File directoryWithSourceFiles = new File(directoryPath);  
      String[] sourceFiles = directoryWithSourceFiles.list();
  
      List<List<ObservationsAtOneTimePoint>> dataset = new ArrayList<List<ObservationsAtOneTimePoint>>(); //for storing acquired dataset
      
      String targetTimeSeriesFilePath = "";
      
      
      for(int i = 0; i < sourceFiles.length; i++)
      {
        if(sourceFiles[i].contains("Cluster") && sourceFiles[i].contains("Jobs") &&
           sourceFiles[i].contains("60_minutes"))
        {
        	targetTimeSeriesFilePath = directoryPath + "/" + sourceFiles[i]; 
        	
        	break;
        }  
      }
      
      
      System.out.println(targetTimeSeriesFilePath);
      
      List<ObservationsAtOneTimePoint> timeSeries = this.readSourceDataFileAndGenerateTimeSeries(targetTimeSeriesFilePath);
      
      System.out.println("Size: " + timeSeries.size());
      
      dataset.add(timeSeries);
      
      
      return dataset;
    }
    
	
	private List<ObservationsAtOneTimePoint> readSourceDataFileAndGenerateTimeSeries(String filePath) throws FileNotFoundException, IOException
    {
      List<ObservationsAtOneTimePoint> timeSeries = new ArrayList<ObservationsAtOneTimePoint>();//for storing a service's time series 
      
        
      BufferedReader reader = new BufferedReader(new FileReader(filePath));
      
      
      String line;
      
      float responseTime = 0;

      
      while (((line = reader.readLine()) != null))//read data line by line
      {  
    	  
          ObservationsAtOneTimePoint timePointData = new ObservationsAtOneTimePoint();
        
          responseTime = Float.parseFloat(line);
            
          if(responseTime > 0.0)
          {
        	 timePointData.setResponseTime(responseTime);
          }
        
        
          timeSeries.add(timePointData);
      }
        
      reader.close();
        
      return timeSeries;  
    }
}
