import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import org.jgap.Configuration;
import org.jgap.InvalidConfigurationException;

import ComparedTimeSeriesMethod_Weka.PredictionExperiments_Weka;
import ComparedTimeSeriesMethod_Weka.Weka_ANN;
import ComparedTimeSeriesMethod_Weka.Weka_DecisionTree;
import ComparedTimeSeriesMethod_Weka.Weka_GaussianProcess;
import ComparedTimeSeriesMethod_Weka.Weka_ProcessBasis;
import ComparedTimeSeriesMethod_Weka.Weka_SVR;
import ComparedTimeSeriesMethod_libsvm.PredictionExperiments_SVR;
import ComparedTimeSeriesMethod_libsvm.SVR_AutoregressiveBased;
import ComparedTimeSeriesMethod_libsvm.SVR_TimeIndexBased;
import ComparedTimeSeriesMethods_CrossApproachesSelection.Selection_Approaches;
import ComparedTimeSeriesMethods_R.R_ProcessBasis;
import ComparedTimeSeriesMethods_R.PredictionExperiments_R;
import ComparedTimeSeriesMethods_R.ARFIMAModels.ARFIMA_forecast;
import ComparedTimeSeriesMethods_R.ARIMAModels.AR;
import ComparedTimeSeriesMethods_R.ARIMAModels.ARIMA;
import ComparedTimeSeriesMethods_R.ARIMAModels.ARMA;
import ComparedTimeSeriesMethods_R.ARIMAModels.MA;
import ComparedTimeSeriesMethods_R.BenchmarkMethodss.Average;
import ComparedTimeSeriesMethods_R.BenchmarkMethodss.DailySeasonalNaive;
import ComparedTimeSeriesMethods_R.BenchmarkMethodss.Drift;
import ComparedTimeSeriesMethods_R.BenchmarkMethodss.Naive;
import ComparedTimeSeriesMethods_R.BenchmarkMethodss.WeeklySeasonalNaive;
import ComparedTimeSeriesMethods_R.ExponentionalSmoothingMethods.BestExponentialSmoothing;
import ComparedTimeSeriesMethods_R.ExponentionalSmoothingMethods.HoltMethod;
import ComparedTimeSeriesMethods_R.ExponentionalSmoothingMethods.HoltWintersMethod;
import ComparedTimeSeriesMethods_R.ExponentionalSmoothingMethods.SimpleExponentionalSmoothing;
import ComparedTimeSeriesMethods_R.GARCHMethods.ARFIMA_GARCH;
import ComparedTimeSeriesMethods_R.GARCHMethods.ARMA_GARCH;
import ComparedTimeSeriesMethods_R.GARCHMethods.PureGARCH;
import ComparedTimeSeriesMethods_R.MachineLearningMethods.ANN_GMDH;
import ComparedTimeSeriesMethods_R.MachineLearningMethods.ANN_forecast;
import ComparedTimeSeriesMethods_R.MachineLearningMethods.ANN_tsDyn;
import ComparedTimeSeriesMethods_R.MachineLearningMethods.PartitioningTree_rpart;
import ComparedTimeSeriesMethods_R.ModelSelection.ModelSelection;
import ComparedTimeSeriesMethods_R.OtherMethods.DoubleSeasonalHoltWinters;
import ComparedTimeSeriesMethods_R.OtherMethods.Theta;
import ComparedTimeSeriesMethods_R.RegressionMethods.MultipleLinearRegression;
import ComparedTimeSeriesMethods_R.RegressionMethods.MultipleNonLinearRegression;
import ComparedTimeSeriesMethods_R.RegressionMethods.NonLinearPolynomialRegression;
import ComparedTimeSeriesMethods_R.RegressionMethods.PolynomialRegression;
import ComparedTimeSeriesMethods_R.RegressionMethods.SimpleLinearRegression;
import ComparedTimeSeriesMethods_R.RegressionMethods.SimpleNonLinearRegression;
import ComparedTimeSeriesMethods_R.ThresholdMethods.SETARwithSingleThreshold;
import ComparedTimeSeriesMethods_R.ThresholdMethods.SETARwithTwoThresholds;
import ProposedTimeSeriesMethod_GP.FitnessFunctions.FitnessFunction_MAE;
import ProposedTimeSeriesMethod_GP.FitnessFunctions.WeightBased.WeightedMAEInspiredBySES;
import ProposedTimeSeriesMethod_GP.Setting.DiverseSetting;
import ProposedTimeSeriesMethod_GP.Setting.GPEvaluationSetting;
import ProposedTimeSeriesMethod_GP.Tools.BestPredictorTreeDrawler;
import ProposedTimeSeriesMethod_GP.Tools.ExcelMaker;
import ProposedTimeSeriesMethod_GP.Tools.ForecastingOutcomesProcessor;
import ProposedTimeSeriesMethod_GP.Tools.SettingFileMaker;
import ProposedTimeSeriesMethod_GP.Tools.ThePercentageOfValidObservationsAndPredictionsFileMaker;
import ProposedTimeSeriesMethod_GP.prediction.GPPredictionConfiguration;
import ProposedTimeSeriesMethod_GP.prediction.PredictionExperiments;
import RandomSearch.RandomSearchByGP;
import Utilities.CommonSetting.TimeSeriesIntervalsIndicesSet;
import Utilities.DataStructures.ForecastingOutcomeOfASegment;
import Utilities.DatasetProcessingModules.ObservationsAtOneTimePoint;
import Utilities.DatasetProcessingModules.TenQoSTimeSeries.DatasetProcessor;
import Utilities.ExcelMakers.AccuracyMeasurementResultsFileMaker;
import Utilities.ExcelMakers.ErrorStandardDeviationResultsFileMaker;
import Utilities.ExcelMakers.TimeCostResultsFileMaker;
import Utilities.ForecastingAccuracyMeasures.DiverseErrorsOfASegment;
import Utilities.ForecastingAccuracyMeasures.DiverseMeasuringResultsOfASegment;
import Utilities.ForecastingCostMeasures.TimeCost;
import Utilities.Painters.BoxplotsPainterInR;
import Utilities.Painters.DiverseErrorsPlotPainterInR;
import Utilities.Painters.ForecastsAndObservationsPlotPainterInR;
import Utilities.ResidualDiagnosis.MainDiagnostician;
import Utilities.TimeSeriesAnalysis.AnalyzingOutcomeOutputToExcelFile;
import Utilities.TimeSeriesAnalysis.TimeSeriesAnalyzer;



public class ExperimentalZone 
{
     public static void main(String[] args) throws FileNotFoundException, IOException, InvalidConfigurationException, Exception 
	 { 
        System.out.println("Allocated java heap size: " + Runtime.getRuntime().maxMemory() / (1024*1024));
    	 
	      //the path and creation of Time Series Experiment directory (the root directory)	 
	      String TimeSeriesExperimentDirectoryPath = "/Users/YangSyu/Desktop/Time Series Experiment";
	      (new File(TimeSeriesExperimentDirectoryPath)).mkdir();
	   
  //QoS time series	for subsequent experiments 
	      
	
	   //self-collected four QoS time series   
	// List<List<ObservationsAtOneTimePoint>> timeSeriesSet = (new Utilities.DatasetProcessingModules.SelfCollectedQoSTimeSeries.DatasetProcessor()).getFourQoSTimeSeries();
	   
	   //WSDream time-aware (three-dimensional) dataset   
	   //(new Utilities.DatasetProcessingModules.WSDreamDatasets.TimeAwareDatasetProcessor()).processDatasetAndSerializeTensor();
    //List<List<ObservationsAtOneTimePoint>> timeSeriesSet = (new Utilities.DatasetProcessingModules.WSDreamDatasets.TimeAwareDatasetProcessor()).deserializeAndGetQoSTimeseries();
	  
	   //Amin's 800 WSs response-time time series 
	  // List<List<ObservationsAtOneTimePoint>> timeSeriesSet = (new Utilities.DatasetProcessingModules.AminDataset.DatasetProcessor()).getTimeSeries();
	   
	      
  //Workload research datasets	      
	      
	  //WikiPedia's workload (pageview number)    //SETAR models did not work for this dataset
	  //List<List<ObservationsAtOneTimePoint>> timeSeriesSet = (new Utilities.DatasetProcessingModules.General.DatasetProcessor()).getTimeSeries("/Users/YangSyu/Google Drive/DataSets/Wiki Page Views/Wiki Page View Workload.txt");
	 
	  //World Cup 98 workload (number of Http requests hourly)
	   //List<List<ObservationsAtOneTimePoint>> timeSeriesSet = (new Utilities.DatasetProcessingModules.General.DatasetProcessor()).getTimeSeries("/Users/YangSyu/Google Drive/DataSets/World Cup 98/Hourly HTTP Requests.txt");
	 	
	  //StackOverflow Workload    
	    //List<List<ObservationsAtOneTimePoint>> timeSeriesSet = (new Utilities.DatasetProcessingModules.General.DatasetProcessor()).getTimeSeries("/Users/YangSyu/Google Drive/DataSets/StackOverflow/Hourly Requests.txt");
	 	
	  //Twitter 1 
	    //List<List<ObservationsAtOneTimePoint>> timeSeriesSet = (new Utilities.DatasetProcessingModules.General.DatasetProcessor()).getTimeSeries("/Users/YangSyu/Google Drive/DataSets/Twitter/Hourly Requests.txt");
	  //Twitter 2  (Standford's  467 million Twitter tweets)	
	    //List<List<ObservationsAtOneTimePoint>> timeSeriesSet = (new Utilities.DatasetProcessingModules.General.DatasetProcessor()).getTimeSeries("/Users/YangSyu/Google Drive/DataSets/Twitter/SNAP.txt");
	 	
	 
	    //not changed yet   //Google Cluster Usage Trace
	  List<List<ObservationsAtOneTimePoint>> timeSeriesSet = (new Utilities.DatasetProcessingModules.GoogleClusterWorkloads.DatasetProcessor()).getTimeSeries();   
	
//System.exit(0);	  
	  
	  /**    
	   //paint original and differenced time series plots
	   TimeSeriesPlotPainterInR  painter=new TimeSeriesPlotPainterInR (timeSeriesSet, TimeSeriesExperimentDirectoryPath);
	   painter.plotOriginalTimeseriesFigures();
	   painter.plotDifferencedTimeseriesFigure();
	  */
	   
	   //GP setting
	   DiverseSetting diverseSetting = new DiverseSetting();
	   
	   
	   //time series segment (intervals) indices
	   TimeSeriesIntervalsIndicesSet timeSeriesIntervalsIndicesSet = new TimeSeriesIntervalsIndicesSet (diverseSetting.getNumberOfPreviousTimePointsAllowedToUse());
			                                                        
	  ///** 
	   //analyze time series segments
	   TimeSeriesAnalyzer QoStimeSeriesAnalyzer=new TimeSeriesAnalyzer(timeSeriesSet, 
			                                                           timeSeriesIntervalsIndicesSet.getTrainingIntervalsIndicesSet(), 
			                                                           timeSeriesIntervalsIndicesSet.getValidatingIntervalsIndicesSet(),
			                                                           timeSeriesIntervalsIndicesSet.getTestingIntervalsIndicesSet());
	   QoStimeSeriesAnalyzer.performeAnalysis();
	 //*/
	   
	   /** 
	   //plot time series segments
	   DividedTimeSeriesSegmentsPlotPainterInR dividedTSSegmentsPainter = new DividedTimeSeriesSegmentsPlotPainterInR(TimeSeriesExperimentDirectoryPath);
	   dividedTSSegmentsPainter.setDividedTimeSeriesToPlot(QoStimeSeriesAnalyzer.getTrainingTimeSeriesSets(),"Training" );
	   dividedTSSegmentsPainter.plotDividedTimeSeriesPlot();
	   dividedTSSegmentsPainter.setDividedTimeSeriesToPlot(QoStimeSeriesAnalyzer.getValidatingTimeSeriesSets(),"Validating" );
	   dividedTSSegmentsPainter.plotDividedTimeSeriesPlot();
	   dividedTSSegmentsPainter.setDividedTimeSeriesToPlot(QoStimeSeriesAnalyzer.getTestingTimeSeriesSets(),"Testing" );
	   dividedTSSegmentsPainter.plotDividedTimeSeriesPlot();
	    */
	 
	 ///**
	   //write analyzing outcome to excel files
	   AnalyzingOutcomeOutputToExcelFile analyzingOutcomeOutputer = new AnalyzingOutcomeOutputToExcelFile(TimeSeriesExperimentDirectoryPath);
	   analyzingOutcomeOutputer.setAnalyzingOutcomeToOutput(QoStimeSeriesAnalyzer.getTrainingSegmentsAnalyzingResults());
	   analyzingOutcomeOutputer.outputExcelFile("Training");
	   analyzingOutcomeOutputer.setAnalyzingOutcomeToOutput(QoStimeSeriesAnalyzer.getValidatingSegmentsAnalyzingResults());
	   analyzingOutcomeOutputer.outputExcelFile("Validating");
	   analyzingOutcomeOutputer.setAnalyzingOutcomeToOutput(QoStimeSeriesAnalyzer.getTestingSegmentsAnalyzingResults());
	   analyzingOutcomeOutputer.outputExcelFile("Testing");
	 // */
	   
//System.exit(0);	
	   
	   //GP configuration
	   GPPredictionConfiguration GPConfiguration = new GPPredictionConfiguration(diverseSetting);
	   
	   //training FF (Fitness Function), validating FF, testing FF
	   GPEvaluationSetting gpEvaluationSetting = new GPEvaluationSetting(GPConfiguration, new FitnessFunction_MAE());
	  
	   

	       
	      //the root path of the experimental outcome
	      String experimentalOutcomeRootPath = TimeSeriesExperimentDirectoryPath + "/Experimental Outcome";
	      (new File(experimentalOutcomeRootPath)).mkdir();       
	           
	      //the path of two experimental outcome groups (the proposed GP and the compared methods)
	      String proposedMethodDirectory = experimentalOutcomeRootPath + "/Proposed Method_GP";
	      (new File(proposedMethodDirectory)).mkdir();
	      String comparedMethodsDirectory = experimentalOutcomeRootPath + "/Compared Methods";
	      (new File(comparedMethodsDirectory)).mkdir();
	     
	    
	   
	    //generate parameters setting file
	    new SettingFileMaker(experimentalOutcomeRootPath, diverseSetting, gpEvaluationSetting, timeSeriesIntervalsIndicesSet);
	    
	    //best GP predictor tree drawler
	    BestPredictorTreeDrawler.setRootPath(proposedMethodDirectory); 
	    
	    
	    
	    //for storing diverse forecasting outcomes of diverse methods
	    List<ForecastingOutcomeOfASegment[][]> outcomeOfDiverseMethods_ForecastingOutcomes = new ArrayList<ForecastingOutcomeOfASegment[][]>();
	    //for storing diverse forecasting error results of diverse methods
	    List<DiverseErrorsOfASegment[][]> outcomeOfDiverseMethods_DiverseErrors = new ArrayList<DiverseErrorsOfASegment[][]>();
	    //for storing accuracy measuring results of diverse methods
	    List<DiverseMeasuringResultsOfASegment[][]> outcomeOfDiverseMethods_AccuracyMeasures = new ArrayList<DiverseMeasuringResultsOfASegment[][]>();
	    //for storing time cost results of diverse methods
	    List<TimeCost[][]> outcomeOfDiverseMethods_TimeCosts = new ArrayList<TimeCost[][]>();
	    
	    
     
//GP part
	   
	  ///* 
	    String GPName = "GP";  
	   
	    PredictionExperiments experiments = new PredictionExperiments
	            (GPName,
	            		
	             GPConfiguration,timeSeriesSet,
	            		
	             timeSeriesIntervalsIndicesSet,
	             
	             gpEvaluationSetting,  //fitness functions
	             
	             new ExcelMaker(proposedMethodDirectory, GPName + "_Best Predictor_MAE", 7), //for GP to record its evolution process
	             new ExcelMaker(proposedMethodDirectory, GPName +"_Best Predictor_MAPE", 7)
	            );  
	     
	    ForecastingOutcomesProcessor.performFinalProcessing(experiments.runExperiments(), outcomeOfDiverseMethods_ForecastingOutcomes, outcomeOfDiverseMethods_DiverseErrors, outcomeOfDiverseMethods_AccuracyMeasures, outcomeOfDiverseMethods_TimeCosts);
	 //*/
	    
	  /** 
	    //second GP design 
	    Configuration.reset();
	    
	    GPName = "GP_W"; 	  
		gpEvaluationSetting = new GPEvaluationSetting(new GPPredictionConfiguration(diverseSetting), new WeightedMAEInspiredBySES());
		 
		experiments = new PredictionExperiments
	            (GPName,
	            		
	             GPConfiguration,timeSeriesSet,
	            		
	             timeSeriesIntervalsIndicesSet,
	             
	             gpEvaluationSetting,  //fitness functions
	             
	             new ExcelMaker(proposedMethodDirectory, GPName + "_Best Predictor_MAE", 7), //for GP to record its evolution process
	             new ExcelMaker(proposedMethodDirectory, GPName +"_Best Predictor_MAPE", 7)
	            );  
	     
	   // ForecastingOutcomesProcessor.performFinalProcessing(experiments.runExperiments(), outcomeOfDiverseMethods_ForecastingOutcomes, outcomeOfDiverseMethods_DiverseErrors, outcomeOfDiverseMethods_AccuracyMeasures, outcomeOfDiverseMethods_TimeCosts);
	  */
	// */       
//the end of GP part

	 
/**	      
	//Random Search part    
	    ForecastingOutcomeOfASegment[][] forecastingOutcomeOfASegment = new RandomSearchByGP(timeSeriesSet, timeSeriesIntervalsIndicesSet, GPConfiguration, gpEvaluationSetting).runRandomSearchByGP(); 
	      outcomeOfDiverseMethods_ForecastingOutcomes.add(forecastingOutcomeOfASegment);
	      
	    DiverseErrorsOfASegment[][]  diverseErrorsOfASegment = ForecastingOutcomesProcessor.generateDiverseErrorsOfASegment(forecastingOutcomeOfASegment);
	      outcomeOfDiverseMethods_DiverseErrors.add(diverseErrorsOfASegment); 
	      
	    diverseMeasuringResultsOfASegment = ForecastingOutcomesProcessor.generateDiverseMeasuringResultsOfASegment(diverseErrorsOfASegment);
	      outcomeOfDiverseMethods_AccuracyMeasures.add(diverseMeasuringResultsOfASegment);
	    
	    timeCostOfASegment = ForecastingOutcomesProcessor.generateDiverseTimeCostOfASegment(forecastingOutcomeOfASegment);
	      outcomeOfDiverseMethods_TimeCosts.add(timeCostOfASegment); 
	    
	//the end of Random Search    
 */	    
	      
	    PredictionExperiments_R predictionExperiments_R = new PredictionExperiments_R(timeSeriesSet, GPConfiguration.getDiverseSetting().getNumberOfTimeSeries(), timeSeriesIntervalsIndicesSet,
	    		                                                                         outcomeOfDiverseMethods_ForecastingOutcomes, outcomeOfDiverseMethods_DiverseErrors, outcomeOfDiverseMethods_AccuracyMeasures, outcomeOfDiverseMethods_TimeCosts);
	    		
	    PredictionExperiments_SVR predictionExperiments_SVR = new PredictionExperiments_SVR(timeSeriesSet, GPConfiguration.getDiverseSetting().getNumberOfTimeSeries(), timeSeriesIntervalsIndicesSet,
	    		                                                                              outcomeOfDiverseMethods_ForecastingOutcomes,  outcomeOfDiverseMethods_DiverseErrors, outcomeOfDiverseMethods_AccuracyMeasures, outcomeOfDiverseMethods_TimeCosts);
	    
	    PredictionExperiments_Weka predictionExperiments_Weka = new PredictionExperiments_Weka(timeSeriesSet, GPConfiguration.getDiverseSetting().getNumberOfTimeSeries(), timeSeriesIntervalsIndicesSet,
                outcomeOfDiverseMethods_ForecastingOutcomes,  outcomeOfDiverseMethods_DiverseErrors, outcomeOfDiverseMethods_AccuracyMeasures, outcomeOfDiverseMethods_TimeCosts);

/**
 predictionExperiments_Weka.runExperiments("WekaANN", new Weka_ANN(diverseSetting) );
 predictionExperiments_Weka.runExperiments("Weka_DecTree", new Weka_DecisionTree(diverseSetting) );
 predictionExperiments_Weka.runExperiments("Weka_SVR", new Weka_SVR(diverseSetting) );
 predictionExperiments_Weka.runExperiments("Weka_GaussianProcess", new  Weka_GaussianProcess(diverseSetting) );
*/  
	    
	    
	//machine learning approaches  
	    predictionExperiments_R.runExperiments("ANNs", new ANN_forecast());
	    
	   // predictionExperiments_R.runExperiments("ANN2", new ANN_tsDyn());
	    
	//    predictionExperimentsInR.runExperiments("ANN3", new ANN_GMDH());//still problematic
	   
	    
	    predictionExperiments_Weka.runExperiments("DTs", new Weka_DecisionTree(diverseSetting));   
	   
	    
	    predictionExperiments_SVR.runExperiments("SVRs", new SVR_TimeIndexBased(false));//SVR Time Index based
	   // predictionExperiments_SVR.runExperiments("SVR_Index2", new SVR_TimeIndexBased(true));//SVR Time Index based
	    
	    //predictionExperiments_SVR.runExperiments("SVR_Auto1", new SVR_AutoregressiveBased(false));//SVR Time Index based 
	    //predictionExperiments_SVR.runExperiments("SVR_Auto2", new SVR_AutoregressiveBased(true));//SVR Time Index based 
	//End of machine learning approaches    
//*/ 
	 
	 
	//Benchmark Forecasting methods part
 // /**	 
	  //Average method   
	    predictionExperiments_R.runExperiments("Ave.", new Average());
	   
	  //Naive method 
	    predictionExperiments_R.runExperiments("Nai.", new Naive());
	   
	  //Daily Seasonal Naive
	   // predictionExperiments_R.runExperiments("DSN", new DailySeasonalNaive());
	   
	  //Weekly Seasonal Naive
	   // predictionExperiments_R.runExperiments("WSN", new WeeklySeasonalNaive());
	   
	  //Drift 
	    predictionExperiments_R.runExperiments("Dri.", new Drift());
	//the end of Benchmark Forecasting methods part  
//*/	   
///**	    
	//Regression methods part
	  //Simple Linear Regression 
	   // predictionExperiments_R.runExperiments("SLR",new SimpleLinearRegression());
	   
	  //Simple Non-Linear Regression (log) 
	    //predictionExperiments_R.runExperiments("SNR", new SimpleNonLinearRegression());
	   
	  //Polynomial Regression 
	    //predictionExperiments_R.runExperiments("PR", new PolynomialRegression());
	   
	  //Nonlinear Polynomial Regression  
	   // predictionExperiments_R.runExperiments("NPR", new NonLinearPolynomialRegression());
	   
	  //Multiple Linear Regression 
	   // predictionExperiments_R.runExperiments("MLR", new MultipleLinearRegression());
	  
	  //Multiple Non-Linear Regression 
	   // predictionExperiments_R.runExperiments("MNR", new MultipleNonLinearRegression());
	   
	/**    
		ModelSelection regression = new ModelSelection("Regres.",timeSeriesSet, GPConfiguration.getDiverseSetting().getNumberOfTimeSeries(), timeSeriesIntervalsIndicesSet,
                                                        outcomeOfDiverseMethods_ForecastingOutcomes, outcomeOfDiverseMethods_DiverseErrors, outcomeOfDiverseMethods_AccuracyMeasures, outcomeOfDiverseMethods_TimeCosts);
		
		regression.addCandidates(new SimpleLinearRegression());
		regression.addCandidates(new SimpleNonLinearRegression());
		regression.addCandidates(new PolynomialRegression());
		regression.addCandidates(new NonLinearPolynomialRegression());
		//regression.addCandidates(new MultipleLinearRegression());
		//regression.addCandidates(new MultipleNonLinearRegression());
		
		regression.runRgressionModelSelection();
	    */
	//The end of Regression methods part
//*/	    

///**	    
	//ARIMA family approaches
    
	  //  predictionExperiments_R.runExperiments("AR", new AR()); 
	    
	  //  predictionExperiments_R.runExperiments("MA", new MA());
	    
	  //  predictionExperiments_R.runExperiments("ARMA", new ARMA());
    
	    predictionExperiments_R.runExperiments("ARIMA", new ARIMA());
	    
	//end of ARIMA family approaches
//*/    
	    
	//exponential smoothing approaches	  
	  //  predictionExperimentsInR.runExperiments("SES", new SimpleExponentionalSmoothing());
	    
	  //  predictionExperimentsInR.runExperiments("Holt", new HoltMethod());
	    
	   // predictionExperimentsInR.runExperiments("HW", new HoltWintersMethod());
	    
	    predictionExperiments_R.runExperiments("ES", new BestExponentialSmoothing());
	    
	//end of exponential smoothing approaches
	    
	    
	   //ARFIMA models  
	   // predictionExperiments_R.runExperiments("ARFIMA", new ARFIMA_forecast()); 
	   	    
	     
	    
	//GARCH family approaches
	   // predictionExperimentsInR.runExperiments("pure GARCH", new PureGARCH());
	    
	   // predictionExperimentsInR.runExperiments("ARMA_GARCH", new ARMA_GARCH());
	    
	  //  predictionExperiments_R.runExperiments("ARFIMA_GARCH", new ARFIMA_GARCH());
	  /**  
	    ModelSelection GARCH = new ModelSelection("GARCH",timeSeriesSet, GPConfiguration.getDiverseSetting().getNumberOfTimeSeries(), timeSeriesIntervalsIndicesSet,
                outcomeOfDiverseMethods_ForecastingOutcomes, outcomeOfDiverseMethods_DiverseErrors, outcomeOfDiverseMethods_AccuracyMeasures, outcomeOfDiverseMethods_TimeCosts);
        
	    GARCH.addCandidates(new PureGARCH());
        GARCH.addCandidates(new ARMA_GARCH());
        GARCH.addCandidates(new ARFIMA_GARCH());

        GARCH.runRgressionModelSelection();
        */
	//End of GARCH family approaches
//*/	
        
///**
   //Threshold approaches
     // predictionExperiments_R.runExperiments("Sin. Thres. SETAR", new SETARwithSingleThreshold());
    	      
     // predictionExperimentsInR.runExperiments("Dou. Thres. SETAR", new SETARwithTwoThresholds());
    	    
    /**  
    	ModelSelection SETAR = new ModelSelection("SETAR",timeSeriesSet, GPConfiguration.getDiverseSetting().getNumberOfTimeSeries(), timeSeriesIntervalsIndicesSet,
                outcomeOfDiverseMethods_ForecastingOutcomes, outcomeOfDiverseMethods_DiverseErrors, outcomeOfDiverseMethods_AccuracyMeasures, outcomeOfDiverseMethods_TimeCosts);
            
    	SETAR.addCandidates(new SETARwithSingleThreshold());
        SETAR.addCandidates(new SETARwithTwoThresholds());

        SETAR.runRgressionModelSelection();
    */
   //End of threshold approaches    
//*/    
        
        
///**	    
    //Other methods
	   //Theta method 
		//predictionExperiments_R.runExperiments("Theta", new Theta());
		    
    //End of other methods    
//*/

///**	    
    //forecasting approaches using selection strategy
        //String[] excludedApproachesAbbreviations = {"GP", "SVR_Index2"};//during selection process, these approaches will not be considered
        String[] excludedApproachesAbbreviations = {};
        Selection_Approaches selection_Approaches = new Selection_Approaches (excludedApproachesAbbreviations, outcomeOfDiverseMethods_DiverseErrors, outcomeOfDiverseMethods_AccuracyMeasures, outcomeOfDiverseMethods_TimeCosts);
     
      //selection approaches based on training accuracy  
        selection_Approaches.runDependingOnTrainingAccuracyApproach("MeanAbsoluteError", "MAE" );
        
        selection_Approaches.runDependingOnTrainingAccuracyApproach("RootMeanSquaredError", "RMSE");
        
        selection_Approaches.runDependingOnTrainingAccuracyApproach("MeanAbsolutePercentageError", "MAPE");
        
        selection_Approaches.runDependingOnTrainingAccuracyApproach("MeanAbsoluteScaledError", "MASE");
        
      //end of the selection approaches based on training accuracy    
        
        selection_Approaches.endSelectionBasedOnTrainingAccuracyApproaches();
    //end of the forecasting approaches using selection strategy    
  //*/
	    
   
	    
        // new MainDiagnostician(experimentalOutcomeRootPath,"Residual Diagnosis" , outcomeOfDiverseMethods_ForecastingOutcomes);
	   // new DiverseErrorsPlotPainterInR(experimentalOutcomeRootPath, "Diverse Errors Plots", outcomeOfDiverseMethods_DiverseErrors).plot();
         new AccuracyMeasurementResultsFileMaker( experimentalOutcomeRootPath, "Accuracy Measuring Results", outcomeOfDiverseMethods_AccuracyMeasures).MakeAccuracyFile();
         new ErrorStandardDeviationResultsFileMaker(experimentalOutcomeRootPath, "Error Standard Deviation Results",outcomeOfDiverseMethods_DiverseErrors).MakeStandardDeviationFile();
         new TimeCostResultsFileMaker( experimentalOutcomeRootPath, "Time Cost Results", outcomeOfDiverseMethods_TimeCosts).MakeFile();
	   // new BoxplotsPainterInR(experimentalOutcomeRootPath, "Boxplots_DiverseErrors", outcomeOfDiverseMethods_DiverseErrors).plot();
	    new ForecastsAndObservationsPlotPainterInR(experimentalOutcomeRootPath,"Observations And Forecasts Plots" , outcomeOfDiverseMethods_ForecastingOutcomes).plot();
	     
	    
	    System.exit(0);
	 }
}
