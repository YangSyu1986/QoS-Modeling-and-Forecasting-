/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package ComparedTimeSeriesMethods_R.ThresholdMethods;

import org.rosuda.JRI.Rengine;

import ComparedTimeSeriesMethods_R.R_ProcessBasis;

/**
 *
 * @author YangSyu
 */
public class SETARwithSingleThreshold extends tsDynPackage
{

    @Override
    protected void generateForecastingModel(Rengine re)
    {   
        int m = 2;//search between orders 0/1 ~ m
          //search for the best hyper parameters that are needed by SETAR models
        re.eval("paras<-selectSETAR(trainingDataTS,m=" + m + ",thDelay=c(0:" + ( m - 1 ) + "))");
        re.eval("bestParas<-paras$bests");
        
         //generate a SETAR model
         //thDelay is threshold delay, th is threshold value, mL is the order number of low regime, and  mH is the order number of high regime
        re.eval("model<-setar(trainingDataTS,thDelay=bestParas[1],th=bestParas[2],mL=bestParas[4],mH=bestParas[5])");
    }

   
    
    
    
    
    
    
    @Override
    protected void mode2Implementation(Rengine re, int numberOfFutureForecastPoints) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    protected void forecastForFutureOnePointImplementation(Rengine re) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
}
