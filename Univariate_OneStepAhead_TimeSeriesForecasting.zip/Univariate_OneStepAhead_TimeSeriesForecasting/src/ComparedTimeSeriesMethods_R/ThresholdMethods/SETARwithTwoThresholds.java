/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package ComparedTimeSeriesMethods_R.ThresholdMethods;

import org.rosuda.JRI.Rengine;

/**
 *
 * @author YangSyu
 */
public class SETARwithTwoThresholds extends tsDynPackage
{

    @Override
    protected void generateForecastingModel(Rengine re) 
    {
       int m=2; 
       //generate a SETAR model
       //thDelay is threshold delay, nthresh is the number of thresholds,  m is the order number 
       re.eval("model<-setar(trainingDataTS,m=" + m + ",nthresh=2,thDelay=0:"+(m-1)+")");
    }

    

    
    
    
    
    
    
    
    @Override
    protected void mode2Implementation(Rengine re, int numberOfFutureForecastPoints) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    protected void forecastForFutureOnePointImplementation(Rengine re) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
}
