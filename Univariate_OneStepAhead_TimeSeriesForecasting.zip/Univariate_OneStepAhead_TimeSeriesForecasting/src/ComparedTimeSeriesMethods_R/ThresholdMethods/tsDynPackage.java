/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package ComparedTimeSeriesMethods_R.ThresholdMethods;

import org.rosuda.JRI.REXP;
import org.rosuda.JRI.Rengine;

import ComparedTimeSeriesMethods_R.R_ProcessBasis;

/**
 *
 * @author YangSyu
 */
public abstract class tsDynPackage extends R_ProcessBasis
{
	// R package "tsDyn"  for SETAR models

	protected void produceOneForecast(REXP x, double[] forecastResult, int index)
	{ 
	   x = re.eval("predict(model,trainingDataTS)[1]"); 
	   if(x == null)
	   {
		   forecastResult[index] = 1; 
	   }
	   else
	   {
		   forecastResult[index] = x.asDouble();  
	   }
	   
	}
	
	
	@Override
    protected void predictIncrementallyWithTheSameForecastingModel(Rengine re) 
    {
       //no need to do any anything 
    }
	
	
	protected void setAIC(Rengine re)
	{
		 //set the AIC value of the generated model
	  if(re.eval("AIC(model)") != null)
	  {
	    this.AICValue = re.eval("AIC(model)").asDouble();
	  }
	}
}
