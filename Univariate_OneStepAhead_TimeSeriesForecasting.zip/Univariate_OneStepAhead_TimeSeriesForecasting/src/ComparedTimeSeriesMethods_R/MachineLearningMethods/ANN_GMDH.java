package ComparedTimeSeriesMethods_R.MachineLearningMethods;

import org.rosuda.JRI.Rengine;

public class ANN_GMDH  extends GMDHPackage
{
	 protected void generateForecastingModel(Rengine re)
	 {
		 re.eval("model<-fcast(trainingDataTS,f.number=1)");
	 }

	 
	 
	 
	 
	 
	@Override
	protected void mode2Implementation(Rengine re, int numberOfFutureForecastPoints) {
		// TODO Auto-generated method stub
		
	}

	@Override
	protected void forecastForFutureOnePointImplementation(Rengine re) {
		// TODO Auto-generated method stub
		
	}
}
