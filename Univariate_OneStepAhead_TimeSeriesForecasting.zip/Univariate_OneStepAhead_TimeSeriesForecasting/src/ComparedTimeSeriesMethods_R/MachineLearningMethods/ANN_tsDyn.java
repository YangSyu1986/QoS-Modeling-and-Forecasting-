package ComparedTimeSeriesMethods_R.MachineLearningMethods;

import org.rosuda.JRI.Rengine;

import ComparedTimeSeriesMethods_R.ThresholdMethods.tsDynPackage;

public class ANN_tsDyn extends tsDynPackage
{
	@Override
    protected void generateForecastingModel(Rengine re)
    {     //use the best AR order (p) to be the number of the input nodes of the fitted ANN model  (m)
		  //use (m+1) to be the number of nodes contained in the hidden layer (size)
		  //such method is similar to the method used in the nnetar function provided by the R package "forecast"
		  //auto-regressive ANN 
		re.eval("numberOfInputNodes<-arimaorder(auto.arima(trainingDataTS, max.q=0, max.d=0))[1]");
		re.eval("model<-nnetTs(trainingDataTS, m=numberOfInputNodes, size=numberOfInputNodes+1)");
    }
	
	
	
 
	
	
    
    @Override
    protected void mode2Implementation(Rengine re, int numberOfFutureForecastPoints) 
    {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    protected void forecastForFutureOnePointImplementation(Rengine re)
    {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}
