package ComparedTimeSeriesMethods_R.MachineLearningMethods;

import org.rosuda.JRI.REXP;
import org.rosuda.JRI.Rengine;

import ComparedTimeSeriesMethods_R.R_ProcessBasis;


public class PartitioningTree_rpart extends R_ProcessBasis
{
	protected void generateForecastingModel(Rengine re)
    {
      re.eval("model<-rpart(trainingDataTS~., data=trainingDataTS)");
    }

   
    protected void predictIncrementallyWithTheSameForecastingModel(Rengine re) 
    {
      
    }
   
    
	protected void produceOneForecast(REXP x, double[] forecastResult, int index) 
	{
		re.eval("forecast<-predict(model)");
	}
    
    
	protected void setAIC(Rengine re)
	{
		 //set the AIC value of the generated model
	  if(re.eval("AIC(model)") != null)
	  {
	    this.AICValue = re.eval("AIC(model)").asDouble();
	  }
	}
    
    
    protected void mode2Implementation(Rengine re, int numberOfFutureForecastPoints)
    {
      
    }


	


	@Override
	protected void forecastForFutureOnePointImplementation(Rengine re) {
		// TODO Auto-generated method stub
		
	}

}
