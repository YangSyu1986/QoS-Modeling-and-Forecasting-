/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package ComparedTimeSeriesMethods_R.MachineLearningMethods;

import java.util.List;
import org.rosuda.JRI.REXP;
import org.rosuda.JRI.Rengine;

import ComparedTimeSeriesMethods_R.R_ProcessBasis;
import ComparedTimeSeriesMethods_R.forecastPackage;
import Utilities.DatasetProcessingModules.ObservationsAtOneTimePoint;

/**
 *
 * @author YangSyu
 */
public class ANN_forecast extends forecastPackage
{    //provided by R package "forecast"
	//auto-regressive ANN
    protected void generateForecastingModel(Rengine re)
    {
      re.eval("model<-nnetar(trainingDataTS)");
    }

   
    protected void predictIncrementallyWithTheSameForecastingModel(Rengine re) 
    {
      re.eval("model$x<-trainingDataTS");
    }
   
    
    
    
    
    protected void mode2Implementation(Rengine re, int numberOfFutureForecastPoints)
    {
      re.eval("annModel<-nnetar(trainingDataTS)");
      re.eval("forecasts<-forecast(annModel,h="+numberOfFutureForecastPoints+")");
    }

   
    protected void forecastForFutureOnePointImplementation(Rengine re) 
    {
      re.eval("annModel<-nnetar(trainingDataTS)");
      re.eval("forecasts<-forecast(annModel,h=1)");
    }
    
}
