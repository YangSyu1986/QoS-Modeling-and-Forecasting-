package ComparedTimeSeriesMethods_R.MachineLearningMethods;

import org.rosuda.JRI.REXP;
import org.rosuda.JRI.Rengine;

import ComparedTimeSeriesMethods_R.R_ProcessBasis;

public abstract class GMDHPackage extends R_ProcessBasis
{
	protected void produceOneForecast(REXP x, double[] forecastResult, int index)
	{ System.out.println(index);
	   x = re.eval("model$mean"); 
	   forecastResult[index] = x.asDouble();  
	   
	}
	
	
	@Override
    protected void predictIncrementallyWithTheSameForecastingModel(Rengine re) 
    {
	   re.eval("model<-fcast(trainingDataTS,f.number=1)");//update predictor each time. But This is not what we want
    }
	
	
	protected void setAIC(Rengine re)
	{
		 //set the AIC value of the generated model
	  if(re.eval("AIC(model)") != null)
	  {
	    this.AICValue = re.eval("AIC(model)").asDouble();
	  }
	}
}
