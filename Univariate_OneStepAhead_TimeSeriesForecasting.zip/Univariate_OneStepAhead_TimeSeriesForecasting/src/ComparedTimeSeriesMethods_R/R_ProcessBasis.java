/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package ComparedTimeSeriesMethods_R;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;
import org.rosuda.JRI.REXP;
import org.rosuda.JRI.Rengine;

import Utilities.DataStructures.ForecastingOutcomeOfASegment;
import Utilities.DatasetProcessingModules.ObservationsAtOneTimePoint;

/**
 *
 * //to set up JRI on Mac (with eclipse) refer to  "http://www.cnblogs.com/mavlarn/archive/2012/12/24/2831688.html"
//regarding how to set R_HOME environment variable in Netbeans, refer to "https://cuprak.wordpress.com/2014/11/13/using-r-from-java-using-a-netbeans-project/"

 */
public abstract class R_ProcessBasis 
{
   protected Rengine re;
   
   
   protected double AICValue = Double.MAX_VALUE;
   
   

   public void prepareREngine()
   {
     this.re = Rengine.getMainEngine();
    
     if(this.re == null)
     {
       this.re = new Rengine(new String[] {"--vanilla"}, false, null);
     }
    
    
     if (!this.re.waitForR()) 
     {
       System.out.println("Cannot load R");
     }
 
   
     this.re.eval("library(\"forecast\")");//loading package "forecast"
     this.re.eval("library(\"tsDyn\")");//loading package "tsDyn"  for SETAR models
     this.re.eval("library(\"rugarch\")");//loading package "ruGarch"  for GARCH models
     this.re.eval("library(\"fracdiff\")");//loading package "fracdiff"  for ARFIMA models
     
     
     
     this.re.eval("library(\"GMDH\")");
   }
  
   public void endREngine()
   {
     this.re.end();
   } 
  
   public void cleanAllVariables()
   {
     this.re.eval("rm(list=ls())");
   }
  
   
   public ForecastingOutcomeOfASegment predict_Mode1(List<ObservationsAtOneTimePoint> timeSeries, int[][] trainingDataIndeces, int[][] testingDataIndeces, ForecastingOutcomeOfASegment forecastingOutcomeOfASegment) throws NullPointerException     
   {
     REXP x = null;
     
     
     //preparing training data (training observations)
     double[] trainingObservationsInArray = this.getDataInArray(timeSeries, trainingDataIndeces, 0);
   
     forecastingOutcomeOfASegment.setTrainingObservations(trainingObservationsInArray);//set training observations 
     
     
     //call R to generate predictor
     this.re.assign("trainingData", trainingObservationsInArray);//assign data into R environment
     this.re.eval("trainingDataTS<-ts(trainingData)");
     
     
         this.re.eval("start<-proc.time()");//used for marking the starting time of predictor production 
    
     this.generateForecastingModel(this.re);//call R to generate a predictor
     
         this.re.eval("end<-proc.time()");//used for marking the ending time of predictor production
         x = this.re.eval("(end-start)[1]");
         double userTime = x.asDouble();
         x = this.re.eval("(end-start)[2]");
         double systemTime = x.asDouble();
      
         
     this.setAIC(re);    
        System.out.println("criteria:  "+this.AICValue  );      
         
     
     forecastingOutcomeOfASegment.setPredictorProductionTime(userTime + systemTime);//set predictor production time
          
  
     //use the generated predictor to produce forecasts (testing predictions) 
     double[] testingObservationsInArray = this.getDataInArray(timeSeries, testingDataIndeces, 0);
     
     forecastingOutcomeOfASegment.setTestingObservations(testingObservationsInArray);
      
     double[] testingPredictions = new double[testingObservationsInArray.length];//for containing testing predictions
    
        
         this.re.eval("start<-proc.time()");
        
     for(int i = 0; i < testingPredictions.length; i++)//generate the testing predictions
     { 
        double[] predictorInputsForTestingPredictions = this.getDataInArray(timeSeries, trainingDataIndeces, i);//prepare predictor inputs (incrementally)	
           
        this.re.assign("trainingData", predictorInputsForTestingPredictions);       
        this.re.eval("trainingDataTS<-ts(trainingData)");
           
        this.predictIncrementallyWithTheSameForecastingModel(this.re);//set predictor inputs
         
        this.produceOneForecast(x, testingPredictions, i);//generate a testing prediction
     }
    
         this.re.eval("end<-proc.time()");
         x = this.re.eval("(end-start)[1]");
         userTime = x.asDouble();
         x = this.re.eval("(end-start)[2]");
         systemTime = x.asDouble();
    
     forecastingOutcomeOfASegment.setTestingPredictions(testingPredictions); 
     forecastingOutcomeOfASegment.setTestingForecastsProductionTime(userTime + systemTime);
  
     
     //use the generated predictor to produce forecasts (training predictions) 
     double[] trainingPredictions = new double[trainingObservationsInArray.length];//for containing training predictions
     
     int index = 0;//to be the index of prediction position    
     
           this.re.eval("start<-proc.time()");
     
     
     for(int j = trainingDataIndeces[0][0]; j <= trainingDataIndeces[0][1]; j++)//the indexes contained in the interval
     {
        List<Double> predictorInputsForTrainingPredictions = new ArrayList<Double>();//for containing predictor inputs
         
        for(int k = 0; k < j ; k++)      //set predictor inputs
        {
          predictorInputsForTrainingPredictions.add((double)timeSeries.get(k).getResponseTime()); 
        }
    
        double[] predictorInputsForTrainingPredictionsInArray = new double[predictorInputsForTrainingPredictions.size()];
        for(int q = 0; q < predictorInputsForTrainingPredictions.size(); q++)
        {
       	  predictorInputsForTrainingPredictionsInArray[q] =  predictorInputsForTrainingPredictions.get(q);
        } 
         
         
        re.assign("trainingData", predictorInputsForTrainingPredictionsInArray);//assign data into R environment
        re.eval("trainingDataTS<-ts(trainingData)");
 
        this.predictIncrementallyWithTheSameForecastingModel(this.re);//set predictor inputs
        this.produceOneForecast(x, trainingPredictions, index);//generate a testing prediction
         
        index++;//go to next (training) prediction position
     }
     
       
          this.re.eval("end<-proc.time()");
          x = this.re.eval("(end-start)[1]");
          userTime = x.asDouble();
          x = this.re.eval("(end-start)[2]");
          systemTime = x.asDouble();
     
       
     forecastingOutcomeOfASegment.setTrainingPredictions(trainingPredictions); 
     forecastingOutcomeOfASegment.setTrainingForecastsProductionTime(userTime + systemTime); 
     
     
     
     return forecastingOutcomeOfASegment;
  }
  
   
  protected abstract void generateForecastingModel(Rengine re);
  
  protected abstract void predictIncrementallyWithTheSameForecastingModel(Rengine re);
  
  protected abstract void produceOneForecast(REXP x, double[] forecastResult, int index);
  
  protected abstract void setAIC(Rengine re);
  
  
 
  
  private double[] getDataInArray(List<ObservationsAtOneTimePoint> timeSeries, int[][] dataIndeces, int incrementNumber)
  {
	  List<ObservationsAtOneTimePoint> data = new ArrayList<ObservationsAtOneTimePoint>();
	     
	  for(int i = 0; i < dataIndeces.length; i++)  
	  {  
	     for(int j = dataIndeces[i][0]; j <= dataIndeces[i][1]; j++)
	     {
	        data.add(timeSeries.get(j));
	     }
	  }
	     
	  
	  if(incrementNumber != 0)
	  {
		  for(int i = 1; i <= incrementNumber; i++)
		  {
			  data.add(timeSeries.get(dataIndeces[dataIndeces.length - 1][1] + i)); 
		  }
	  }
	  
	  
	  double[] dataInArray = new double[data.size()];
	     
	  for(int i = 0; i < dataInArray.length; i++) 
	  {
	     dataInArray[i] = data.get(i).getResponseTime();
	  }
	  
	  
	  return dataInArray;
  }
 
  
  
  
 
  
  
  
  
  
  
  
  
  
  public double[] predict_Mode2(List<ObservationsAtOneTimePoint> data, int[][] trainingDataIndeces,int[][] testingDataIndeces)
  { 
    REXP x; 
    
    List<ObservationsAtOneTimePoint> trainingData=data.subList(trainingDataIndeces[0][0],(trainingDataIndeces[0][1]+1));//must be modified if there are multiple training data intervals
  
    double[] trainingDataInArray=new double[trainingData.size()];
    for(int i=0;i<trainingData.size();i++) 
      trainingDataInArray[i]=trainingData.get(i).getResponseTime();
    
    int numberOfFutureForecastPoints=(testingDataIndeces[0][1]-testingDataIndeces[0][0])+1;
    
    re.assign("trainingData", trainingDataInArray);
    re.eval("trainingDataTS<-ts(trainingData)");
    
    this.mode2Implementation(this.re, numberOfFutureForecastPoints);
    
    x=re.eval("summary(forecasts)");
    double[] forecastResult=x.asVector().at(0).asDoubleArray();
    
    return forecastResult;
  }
  
  protected abstract void mode2Implementation(Rengine re,int numberOfFutureForecastPoints);
          
  
  
  public double[] predict_Mode3(List<ObservationsAtOneTimePoint> data, int[][] trainingDataIndeces,int[][] testingDataIndeces)
  {
    REXP x;
    
    int numberOfFutureForecastPoints=(testingDataIndeces[0][1]-testingDataIndeces[0][0])+1;
    
    double[] forecastResult=new double[numberOfFutureForecastPoints];
   
    
    for(int i=0;i<numberOfFutureForecastPoints;i++)
    {    //training dataset is incrementally enlarged
     List<ObservationsAtOneTimePoint> trainingData=data.subList(trainingDataIndeces[0][0],(trainingDataIndeces[0][1]+1+i));
   
     double[] trainingDataInArray=new double[trainingData.size()];
     for(int j=0;j<trainingDataInArray.length;j++) 
        trainingDataInArray[j]=trainingData.get(j).getResponseTime();
 
     re.assign("trainingData", trainingDataInArray);
     re.eval("trainingDataTS<-ts(trainingData)");
    
     this.forecastForFutureOnePointImplementation(this.re);
     
     x=re.eval("summary(forecasts)");
     forecastResult[i]=x.asVector().at(0).asDouble();
    }
     
    return forecastResult;
  }
  
  protected abstract void forecastForFutureOnePointImplementation(Rengine re);
  
  public double[] predict_Mode4(List<ObservationsAtOneTimePoint> data, int[][] trainingDataIndeces,int[][] testingDataIndeces)
  {
    REXP x;
    
    int numberOfFutureForecastPoints=(testingDataIndeces[0][1]-testingDataIndeces[0][0])+1;
    
    double[] forecastResult=new double[numberOfFutureForecastPoints];
   
    
    for(int i=0;i<numberOfFutureForecastPoints;i++)
    { 
     List<ObservationsAtOneTimePoint> trainingData=data.subList(trainingDataIndeces[0][0]+i,(trainingDataIndeces[0][1]+1+i));
     double[] trainingDataInArray=new double[trainingData.size()];
     for(int j=0;j<trainingDataInArray.length;j++) 
        trainingDataInArray[j]=trainingData.get(j).getResponseTime();
 
     re.assign("trainingData", trainingDataInArray);
     re.eval("trainingDataTS<-ts(trainingData)");
     
     this.forecastForFutureOnePointImplementation(this.re);
     
     x=re.eval("summary(forecasts)");
     forecastResult[i]=x.asVector().at(0).asDouble();
    }
     
    return forecastResult;
  } 
  
  
  
  
  public double getAICValue() 
  {
	 return AICValue; 
  }
}
