package ComparedTimeSeriesMethods_R.OtherMethods;

import org.rosuda.JRI.Rengine;

import ComparedTimeSeriesMethods_R.forecastPackage;

public class Theta extends forecastPackage
{
	//provided by R package "forecast"
    protected void generateForecastingModel(Rengine re)
    {
      re.eval("model<-thetaf(trainingDataTS)");
    }

   
    protected void predictIncrementallyWithTheSameForecastingModel(Rengine re) 
    {
      re.eval("model$x<-trainingDataTS");
    }
   
    
    
    
    
    protected void mode2Implementation(Rengine re, int numberOfFutureForecastPoints)
    {
      
    }

   
    protected void forecastForFutureOnePointImplementation(Rengine re) 
    {
     
    }
}
