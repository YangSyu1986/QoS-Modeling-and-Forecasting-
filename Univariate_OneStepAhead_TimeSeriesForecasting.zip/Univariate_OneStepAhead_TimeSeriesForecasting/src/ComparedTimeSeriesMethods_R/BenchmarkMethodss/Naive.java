/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package ComparedTimeSeriesMethods_R.BenchmarkMethodss;

import java.util.List;
import org.rosuda.JRI.REXP;
import org.rosuda.JRI.Rengine;

import ComparedTimeSeriesMethods_R.R_ProcessBasis;
import ComparedTimeSeriesMethods_R.forecastPackage;
import Utilities.DatasetProcessingModules.ObservationsAtOneTimePoint;

/**
 *
 * @author YangSyu
 */
public class Naive extends forecastPackage
{
    protected void generateForecastingModel(Rengine re)
    {
      re.eval("model<-naive(trainingDataTS,h=1)");
    }

    protected void predictIncrementallyWithTheSameForecastingModel(Rengine re) 
    {
      re.eval("model<-naive(trainingDataTS,h=1)");
    }
    
    
    protected void mode2Implementation(Rengine re, int numberOfFutureForecastPoints)
    {
    }

    protected void forecastForFutureOnePointImplementation(Rengine re) 
    {
    }
}
