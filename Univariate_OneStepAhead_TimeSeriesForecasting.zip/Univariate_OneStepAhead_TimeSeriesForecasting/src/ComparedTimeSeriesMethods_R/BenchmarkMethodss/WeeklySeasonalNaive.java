/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package ComparedTimeSeriesMethods_R.BenchmarkMethodss;

import org.rosuda.JRI.Rengine;

import ComparedTimeSeriesMethods_R.R_ProcessBasis;
import ComparedTimeSeriesMethods_R.forecastPackage;

/**
 *
 * @author YangSyu
 */
public class WeeklySeasonalNaive extends forecastPackage
{
    protected void generateForecastingModel(Rengine re)
    {
      re.eval("trainingDataTS<-msts(trainingData, seasonal.periods=c(168))");
      re.eval("model<-snaive(trainingDataTS,h=1)");
    }

    protected void predictIncrementallyWithTheSameForecastingModel(Rengine re) 
    {
      re.eval("trainingDataTS<-msts(trainingData, seasonal.periods=c(168))");
      re.eval("model<-snaive(trainingDataTS,h=1)");
    }
    
       
    protected void mode2Implementation(Rengine re, int numberOfFutureForecastPoints)
    {
    }

    protected void forecastForFutureOnePointImplementation(Rengine re) 
    {
    }
}
