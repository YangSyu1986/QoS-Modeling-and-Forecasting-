/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package ComparedTimeSeriesMethods_R.GARCHMethods;

import org.rosuda.JRI.REXP;
import org.rosuda.JRI.Rengine;

import ComparedTimeSeriesMethods_R.R_ProcessBasis;

/**
 *
 * @author YangSyu
 */
public abstract class ruGARCHPackage extends R_ProcessBasis
{
	//R package "ruGarch"  for GARCH models	
	

    @Override
    protected void predictIncrementallyWithTheSameForecastingModel(Rengine re)
    {
        re.eval("model@model$modeldata$data<-trainingDataTS");
    }
    
    
    protected void produceOneForecast(REXP x, double[] forecastResult, int index)
	{
	    this.re.eval("forecast<-ugarchforecast(model, n.ahead = 1)"); 
	    x = re.eval("fitted(forecast)[1]");
	    
	    if(x == null)//in case of no prediction result (no predictor was generated, and thus, no prediction is able to be produced )
	    {
	       forecastResult[index] = Double.MAX_VALUE;   	
	    }
	    else
	    {	
	       forecastResult[index] = x.asDouble();  
	    }
	}
    
    
    protected void setAIC(Rengine re)
	{
		 //set the AIC value of the generated model
	  if(re.eval("infocriteria(model)") != null)
	  {
	    this.AICValue = re.eval("infocriteria(model)").asDouble();
	  }
	}
}
