/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package ComparedTimeSeriesMethods_R.GARCHMethods;

import org.rosuda.JRI.Rengine;

import ComparedTimeSeriesMethods_R.R_ProcessBasis;

/**
 *
 * @author YangSyu
 */
public class PureGARCH extends ruGARCHPackage
{
    @Override
    protected void generateForecastingModel(Rengine re)
    {                              
        re.eval("spec<-ugarchspec(mean.model = list(armaOrder = c(0, 0)) )");
        re.eval("model <- ugarchfit(spec=spec, data=trainingDataTS, solver = 'hybrid')"); 
    }

   
    
    

    @Override
    protected void mode2Implementation(Rengine re, int numberOfFutureForecastPoints) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    protected void forecastForFutureOnePointImplementation(Rengine re) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
}
