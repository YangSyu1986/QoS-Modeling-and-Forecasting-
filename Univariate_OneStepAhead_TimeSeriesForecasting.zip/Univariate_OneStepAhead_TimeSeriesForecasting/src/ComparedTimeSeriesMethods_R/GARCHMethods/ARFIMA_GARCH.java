/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package ComparedTimeSeriesMethods_R.GARCHMethods;

import org.rosuda.JRI.Rengine;

/**
 *
 * @author YangSyu
 */
public class ARFIMA_GARCH extends ruGARCHPackage
{
     @Override
    protected void generateForecastingModel(Rengine re)
    {     
        //find out best AR and MA orders by using auto.arima function
        re.eval("armaModel<-auto.arima(trainingDataTS)");
        re.eval("arOrder<-armaModel$arma[1]");
        re.eval("maOrder<-armaModel$arma[2]");
        
        re.eval("spec<-ugarchspec(mean.model = list(armaOrder = c(arOrder, maOrder),arfima=TRUE))");
        re.eval("model <- ugarchfit(spec=spec, data=trainingDataTS, solver = 'hybrid')");
    }

    
     
     
     

    @Override
    protected void mode2Implementation(Rengine re, int numberOfFutureForecastPoints) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    protected void forecastForFutureOnePointImplementation(Rengine re) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}
