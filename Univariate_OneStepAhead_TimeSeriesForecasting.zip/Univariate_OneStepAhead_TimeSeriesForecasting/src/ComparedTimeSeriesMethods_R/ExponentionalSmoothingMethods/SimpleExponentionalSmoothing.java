package ComparedTimeSeriesMethods_R.ExponentionalSmoothingMethods;

import org.rosuda.JRI.Rengine;

import ComparedTimeSeriesMethods_R.forecastPackage;

public class SimpleExponentionalSmoothing extends forecastPackage
{
	 protected void generateForecastingModel(Rengine re)
	 {
	    re.eval("model<-ets(trainingDataTS, model=\"ZNN\")");
	 }

	   
	 protected void predictIncrementallyWithTheSameForecastingModel(Rengine re) 
	 {
	    re.eval("model$x<-trainingDataTS");
	 }
	    
	    
	 protected void mode2Implementation(Rengine re, int numberOfFutureForecastPoints)
	 {
	 }

	    
	 protected void forecastForFutureOnePointImplementation(Rengine re)
	 {
	 }  

}
