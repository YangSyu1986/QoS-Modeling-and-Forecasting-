package ComparedTimeSeriesMethods_R.ExponentionalSmoothingMethods;

import org.rosuda.JRI.Rengine;

import ComparedTimeSeriesMethods_R.forecastPackage;

public class HoltWintersMethod extends forecastPackage
{
	 protected void generateForecastingModel(Rengine re)
	 {
	    re.eval("model<-ets(trainingDataTS, model=\"ZZZ\",  damped=NULL)");
	 }

	   
	 protected void predictIncrementallyWithTheSameForecastingModel(Rengine re) 
	 {
	    re.eval("model$x<-trainingDataTS");
	 }
	    
	    
	 protected void mode2Implementation(Rengine re, int numberOfFutureForecastPoints)
	 {
	 }

	    
	 protected void forecastForFutureOnePointImplementation(Rengine re)
	 {
	 }  

}
