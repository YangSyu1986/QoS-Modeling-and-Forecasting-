/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package ComparedTimeSeriesMethods_R.ExponentionalSmoothingMethods;

import org.rosuda.JRI.Rengine;

import ComparedTimeSeriesMethods_R.R_ProcessBasis;
import ComparedTimeSeriesMethods_R.forecastPackage;

/**
 *
 * @author YangSyu
 */
public class BestExponentialSmoothing extends forecastPackage
{
    protected void generateForecastingModel(Rengine re)
    {
      re.eval("model<-ets(trainingDataTS)");
    }

   
    protected void predictIncrementallyWithTheSameForecastingModel(Rengine re) 
    {
      re.eval("model<-ets(trainingDataTS,model=model)");
    }
    
    
    protected void mode2Implementation(Rengine re, int numberOfFutureForecastPoints)
    {
    }

    
    protected void forecastForFutureOnePointImplementation(Rengine re)
    {
    }
}
