/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */


package ComparedTimeSeriesMethods_R.ARIMAModels;

import java.util.Enumeration;
import java.util.List;
import org.rosuda.JRI.REXP;
import org.rosuda.JRI.RVector;
import org.rosuda.JRI.Rengine;

import ComparedTimeSeriesMethods_R.R_ProcessBasis;
import ComparedTimeSeriesMethods_R.forecastPackage;
import Utilities.DatasetProcessingModules.ObservationsAtOneTimePoint;

/**
 *
 * @author YangSyu
 */
public class ARIMA extends forecastPackage
{
     
    protected void generateForecastingModel(Rengine re)
    {
      re.eval("model<-auto.arima(trainingDataTS)");
    }

   
    protected void predictIncrementallyWithTheSameForecastingModel(Rengine re) 
    {
      re.eval("model<-Arima(trainingDataTS,model=model)");
    }
    
    
    
    
    
    
    
    protected void mode2Implementation(Rengine re, int numberOfFutureForecastPoints)
    {
       re.eval("arimaModel<-auto.arima(trainingDataTS)");
       re.eval("forecasts<-forecast.Arima(arimaModel,h="+numberOfFutureForecastPoints+")");
    }

    
    protected void forecastForFutureOnePointImplementation(Rengine re)
    {
       re.eval("arimaModel<-auto.arima(trainingDataTS)");
       re.eval("forecasts<-forecast.Arima(arimaModel,h=1)");
    }
}
