/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package ComparedTimeSeriesMethods_R.ARIMAModels;

import org.rosuda.JRI.Rengine;

import ComparedTimeSeriesMethods_R.R_ProcessBasis;
import ComparedTimeSeriesMethods_R.forecastPackage;

/**
 *
 * @author YangSyu
 */
public class MA  extends forecastPackage
{
    protected void generateForecastingModel(Rengine re)
    {
      re.eval("model<-auto.arima(trainingDataTS, max.p=0,max.d=0 )");
    }

   
    protected void predictIncrementallyWithTheSameForecastingModel(Rengine re) 
    {
      re.eval("model<-Arima(trainingDataTS,model=model)");
    }

    @Override
    protected void mode2Implementation(Rengine re, int numberOfFutureForecastPoints) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    protected void forecastForFutureOnePointImplementation(Rengine re) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}
