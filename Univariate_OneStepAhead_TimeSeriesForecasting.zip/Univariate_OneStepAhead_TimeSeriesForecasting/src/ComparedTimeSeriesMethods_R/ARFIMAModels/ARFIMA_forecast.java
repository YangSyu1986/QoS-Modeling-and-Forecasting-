package ComparedTimeSeriesMethods_R.ARFIMAModels;

import org.rosuda.JRI.REXP;
import org.rosuda.JRI.Rengine;

import ComparedTimeSeriesMethods_R.forecastPackage;


public class ARFIMA_forecast extends forecastPackage
{//Model introduction: https://en.wikipedia.org/wiki/Autoregressive_fractionally_integrated_moving_average
 //In the paper that proposed using ARFIMA model: "Using fractional differencing to model LRD series may not provide superior results in short-term forecasts, but with longer forecast horizons, it can provide better predictions with less error"

	
	protected void generateForecastingModel(Rengine re)
    {
	  /**	
	  re.eval("result<-fracdiff(trainingDataTS)");
	  re.eval("d<-result$d");
	  System.out.println("fractional difference factor (d): " + re.eval("d").asDouble());
      */
	  re.eval("model<-arfima(trainingDataTS)");
    }

   
    protected void predictIncrementallyWithTheSameForecastingModel(Rengine re) 
    {
      re.eval("model$x<-trainingDataTS");
    }
    
    
    protected void produceOneForecast(REXP x, double[] forecastResult, int index)
	{
	  re.eval("forecast<-forecast.fracdiff(model,h=1)");
	  x = re.eval("summary(forecast)");
	  forecastResult[index] = x.asVector().at(0).asDouble();  	 
	}
    
    
    
    
    protected void mode2Implementation(Rengine re, int numberOfFutureForecastPoints)
    {
      
    }

    
    protected void forecastForFutureOnePointImplementation(Rengine re)
    {
      
    }
}
