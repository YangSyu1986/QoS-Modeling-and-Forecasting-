package ComparedTimeSeriesMethods_R.ModelSelection;

import java.util.ArrayList;
import java.util.List;

import org.rosuda.JRI.Rengine;

import ComparedTimeSeriesMethods_R.R_ProcessBasis;
import ComparedTimeSeriesMethods_R.forecastPackage;
import ComparedTimeSeriesMethods_R.RegressionMethods.MultipleLinearRegression;
import ComparedTimeSeriesMethods_R.RegressionMethods.MultipleNonLinearRegression;
import ComparedTimeSeriesMethods_R.RegressionMethods.NonLinearPolynomialRegression;
import ComparedTimeSeriesMethods_R.RegressionMethods.PolynomialRegression;
import ComparedTimeSeriesMethods_R.RegressionMethods.SimpleLinearRegression;
import ComparedTimeSeriesMethods_R.RegressionMethods.SimpleNonLinearRegression;
import ProposedTimeSeriesMethod_GP.Tools.ForecastingOutcomesProcessor;
import Utilities.CommonSetting.TimeSeriesIntervalsIndicesSet;
import Utilities.DataStructures.ForecastingOutcomeOfASegment;
import Utilities.DatasetProcessingModules.ObservationsAtOneTimePoint;
import Utilities.ForecastingAccuracyMeasures.DiverseErrorsOfASegment;
import Utilities.ForecastingAccuracyMeasures.DiverseMeasuringResultsOfASegment;
import Utilities.ForecastingCostMeasures.TimeCost;

/**
For internal model selection (selection between the models of the same approach, such as various regression models),
we consider AIC or BIC as our selection criterion, which are used by most other approaches (such as ARIMA models 
and ES approach) 
*/

public class ModelSelection 
{
	 String name;
	 
	
	 List<List<ObservationsAtOneTimePoint>> timeSeries;
	 int numberOfTimeseries;
	 int[][][] trainingDataIntervalsSet;
	 int[][][] testingDataIntervalsSet;
	  
	  
	 List<ForecastingOutcomeOfASegment[][]> outcomeOfDiverseMethods_ForecastingOutcomes;
	 List<DiverseErrorsOfASegment[][]> outcomeOfDiverseMethods_DiverseErrors; 
	 List<DiverseMeasuringResultsOfASegment[][]> outcomeOfDiverseMethods_AccuracyMeasures; 
	 List<TimeCost[][]> outcomeOfDiverseMethods_TimeCosts;
	  
	  
	 List<R_ProcessBasis> selectionCandidates = new ArrayList<R_ProcessBasis>();
		
		
	 public ModelSelection(String name,
			               List<List<ObservationsAtOneTimePoint>> timeSeries, int numberOfTimeseries,
			               TimeSeriesIntervalsIndicesSet timeSeriesIntervalsIndicesSet,
			                          
			               List<ForecastingOutcomeOfASegment[][]> outcomeOfDiverseMethods_ForecastingOutcomes,
			               List<DiverseErrorsOfASegment[][]> outcomeOfDiverseMethods_DiverseErrors, 
	                       List<DiverseMeasuringResultsOfASegment[][]> outcomeOfDiverseMethods_AccuracyMeasures, 
	                       List<TimeCost[][]> outcomeOfDiverseMethods_TimeCosts
			              )
	 {
		 this.name = name;
		 this.timeSeries = timeSeries;
		 this.numberOfTimeseries = numberOfTimeseries;
		 this.trainingDataIntervalsSet = timeSeriesIntervalsIndicesSet.getTrainingIntervalsIndicesSet();
		 this.testingDataIntervalsSet = timeSeriesIntervalsIndicesSet.getTestingIntervalsIndicesSet();
		 
		 this.outcomeOfDiverseMethods_ForecastingOutcomes = outcomeOfDiverseMethods_ForecastingOutcomes;
		 this.outcomeOfDiverseMethods_DiverseErrors = outcomeOfDiverseMethods_DiverseErrors;
		 this.outcomeOfDiverseMethods_AccuracyMeasures = outcomeOfDiverseMethods_AccuracyMeasures;
		 this.outcomeOfDiverseMethods_TimeCosts = outcomeOfDiverseMethods_TimeCosts;
	 }
	 
	 
	 public void addCandidates(R_ProcessBasis selectionCandidate)
	 {
		 this.selectionCandidates.add(selectionCandidate);
	 }
	 
	 
	
	public void runRgressionModelSelection()
	{    	
		ForecastingOutcomeOfASegment[][] results = new ForecastingOutcomeOfASegment[this.numberOfTimeseries][];
		  
		for(int i = 0; i < this.numberOfTimeseries; i++)
		{
			results[i] = new ForecastingOutcomeOfASegment[this.trainingDataIntervalsSet.length]; 
			 
			for(int j = 0; j < this.trainingDataIntervalsSet.length; j++)
			{
			  System.out.println(this.name + "    TS  " + i + "  Segment  " + j);	
			
			  
			  results[i][j] = new ForecastingOutcomeOfASegment(i, j, 0, this.name); 
		  
			  
			  double currentBestAICValue = Double.MAX_VALUE;
			  double accumulatedModelGenerationTime = 0;
			  
			  for(R_ProcessBasis selectionCandidate:this.selectionCandidates)
			  {
				  selectionCandidate.prepareREngine();
				  
				  
				  ForecastingOutcomeOfASegment tempResult = new ForecastingOutcomeOfASegment(i, j, 0, this.name); 
				  
				  selectionCandidate.predict_Mode1(timeSeries.get(i), this.trainingDataIntervalsSet[j], this.testingDataIntervalsSet[j], tempResult);	
				  
				  accumulatedModelGenerationTime = accumulatedModelGenerationTime + tempResult.getPredictorProductionTime();  
				  
				  if(selectionCandidate.getAICValue() < currentBestAICValue)
				  {
					  results[i][j] =  tempResult; 
					  currentBestAICValue = selectionCandidate.getAICValue();
				  }	  
				  
				  
				  selectionCandidate.cleanAllVariables();	 
			  }
			 
			  
			  results[i][j].setPredictorProductionTime(accumulatedModelGenerationTime);
			}
		}
		  
		 
		outcomeOfDiverseMethods_ForecastingOutcomes.add(results);
		 
		DiverseErrorsOfASegment[][] diverseErrorsOfASegment = ForecastingOutcomesProcessor.generateDiverseErrorsOfASegment(results);
		outcomeOfDiverseMethods_DiverseErrors.add(diverseErrorsOfASegment); 
			   
		DiverseMeasuringResultsOfASegment[][] diverseMeasuringResultsOfASegment = ForecastingOutcomesProcessor.generateDiverseMeasuringResultsOfASegment(diverseErrorsOfASegment);
		outcomeOfDiverseMethods_AccuracyMeasures.add(diverseMeasuringResultsOfASegment); 
			    
		TimeCost[][] timeCostOfASegment = ForecastingOutcomesProcessor.generateDiverseTimeCostOfASegment(results);
		outcomeOfDiverseMethods_TimeCosts.add(timeCostOfASegment);   
	}

}
