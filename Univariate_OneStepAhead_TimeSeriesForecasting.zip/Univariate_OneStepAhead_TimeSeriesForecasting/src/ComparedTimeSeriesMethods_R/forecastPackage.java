package ComparedTimeSeriesMethods_R;

import org.rosuda.JRI.REXP;
import org.rosuda.JRI.Rengine;

public abstract class forecastPackage extends R_ProcessBasis
{
	// R package "forecast"
	
	protected void produceOneForecast(REXP x, double[] forecastResult, int index)
	{
	  re.eval("forecast<-forecast(model,h=1)");
	  x = re.eval("summary(forecast)");
	  forecastResult[index]=x.asVector().at(0).asDouble();  
    
	     this.expForNonLinearModelResults(forecastResult, index);
	}
	
	
	protected void expForNonLinearModelResults(double[] forecastResult, int index)
	{
	  if(this instanceof ComparedTimeSeriesMethods_R.RegressionMethods.SimpleNonLinearRegression ||
	     this instanceof ComparedTimeSeriesMethods_R.RegressionMethods.NonLinearPolynomialRegression ||
	     this instanceof ComparedTimeSeriesMethods_R.RegressionMethods.MultipleNonLinearRegression    
	    )  
	  {	
	    forecastResult[index] = Math.exp(forecastResult[index]); 
	  }
	}

	
	protected void setAIC(Rengine re)
	{
		 //set the AIC value of the generated model
	  if(re.eval("AIC(model)") != null)
	  {
	    this.AICValue = re.eval("AIC(model)").asDouble();
	  }
	}
	
}
