/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package ComparedTimeSeriesMethods_R.RegressionMethods;

import org.rosuda.JRI.Rengine;

import ComparedTimeSeriesMethods_R.R_ProcessBasis;
import ComparedTimeSeriesMethods_R.forecastPackage;

/**
 *
 * @author YangSyu
 */
public class SimpleNonLinearRegression extends forecastPackage
{//forecasting formula: log(Yt)=intercept + coefficient*(log(t)), where intercept and coefficient values are determined by regression (with training data)
 //log-log model    the forecast results must go through "exp" action
    protected void generateForecastingModel(Rengine re)
    {
      re.eval("trainingDataTS<-log(trainingDataTS)"); 
      //re.eval("model<-tslm(trainingDataTS ~ log(trend))"); original version, not work now
      re.eval("model<-tslm(trainingDataTS ~ trend)");
    }

    protected void predictIncrementallyWithTheSameForecastingModel(Rengine re) 
    {
      //re.eval("model$data[nrow(model$data),1]<-trainingDataTS[length(trainingDataTS)]");  //this can be ignored, because past observations are not needed in regression approaches
      re.eval("model$data[nrow(model$data),2]<-length(trainingDataTS)");
      
    }
       
    
    
    
    
    protected void mode2Implementation(Rengine re, int numberOfFutureForecastPoints)
    {
    }

    protected void forecastForFutureOnePointImplementation(Rengine re) 
    {
    }
}

