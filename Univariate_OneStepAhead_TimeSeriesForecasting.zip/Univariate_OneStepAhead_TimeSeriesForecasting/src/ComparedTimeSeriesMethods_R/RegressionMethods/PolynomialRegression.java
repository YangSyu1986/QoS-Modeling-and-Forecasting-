/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package ComparedTimeSeriesMethods_R.RegressionMethods;

import org.rosuda.JRI.Rengine;

import ComparedTimeSeriesMethods_R.R_ProcessBasis;
import ComparedTimeSeriesMethods_R.forecastPackage;

/**
 *
 * @author YangSyu
 */
public class PolynomialRegression extends forecastPackage
{//forecasting formula: Yt = intercept + coefficient1*t + coefficient2*(t^2) + coefficient3*(t^3) + ....
 //where intercept and coefficient values are determined by regression (with training data)
 //the number of orders (degrees) of polynomial is automatically determined by using AIC 
 //the number of orders is between 2 and 5  
    protected void generateForecastingModel(Rengine re)
    {
      re.eval("polyfit <- function(i) trainingDataTS <- AIC(tslm(trainingDataTS ~ poly(trend,i,raw=TRUE)))");
      re.eval("numOfOrders<-as.integer(optimize(polyfit,interval = c(2,5))$minimum)");
//in  https://www.otexts.org/fpp/5/3    Akaike's Information Criterion section, the authors said "The model with the minimum value of the AIC is often the best model for forecasting"  
      //System.out.println("Automatically selected polynomial order number: "+re.eval("numOfOrders"));
      
      re.eval("model<-tslm(trainingDataTS ~ poly(trend, numOfOrders, raw=TRUE))"); 
//in https://www.otexts.org/fpp/5/2 trend section, the authors said that " it is not recommended that quadratic or higher order trends are used in forecasting. When they are extrapolated, the resulting forecasts are often very unrealistic."
          //System.out.println(re.eval("coefficients(model)"));//print intercept and trend values
    }

    protected void predictIncrementallyWithTheSameForecastingModel(Rengine re) 
    {
      re.eval("model$data[nrow(model$data),2]<-length(trainingDataTS)");  
         //System.out.println(re.eval("coefficients(model)"));
    }
       
    protected void mode2Implementation(Rengine re, int numberOfFutureForecastPoints)
    {
    }

    protected void forecastForFutureOnePointImplementation(Rengine re) 
    {
    }
}


