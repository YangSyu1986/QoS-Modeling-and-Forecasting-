/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package ComparedTimeSeriesMethods_R.RegressionMethods;

import org.rosuda.JRI.Rengine;

import ComparedTimeSeriesMethods_R.R_ProcessBasis;
import ComparedTimeSeriesMethods_R.forecastPackage;

/**
 *
 * @author YangSyu
 */
public class NonLinearPolynomialRegression extends forecastPackage
{//forecasting formula: log(Yt) = intercept + (coefficient1*log(t)) + (coefficient2*(log(t)^2)) + (coefficient3*(log(t)^3)) + ....
 //.....as polynomial regression
    protected void generateForecastingModel(Rengine re)
    {
      re.eval("trainingDataTS<-log(trainingDataTS)"); 
        
      re.eval("polyfit <- function(i) trainingDataTS <- AIC(tslm(trainingDataTS ~ poly(log(trend),i,raw=TRUE)))");
      re.eval("numOfOrders<-as.integer(optimize(polyfit,interval = c(2,5))$minimum)");
      //System.out.println("Automatically selected polynomial order number: "+re.eval("numOfOrders"));
      
     //re.eval("model<-tslm(trainingDataTS ~ poly(log(trend), numOfOrders, raw=TRUE))"); original version
      re.eval("model<-tslm(trainingDataTS ~ poly(trend, numOfOrders, raw=TRUE))"); 
    }

    protected void predictIncrementallyWithTheSameForecastingModel(Rengine re) 
    {
      re.eval("model$data[nrow(model$data),2]<-length(trainingDataTS)");  
    }
       
    protected void mode2Implementation(Rengine re, int numberOfFutureForecastPoints)
    {
    }

    protected void forecastForFutureOnePointImplementation(Rengine re) 
    {
    }
}



