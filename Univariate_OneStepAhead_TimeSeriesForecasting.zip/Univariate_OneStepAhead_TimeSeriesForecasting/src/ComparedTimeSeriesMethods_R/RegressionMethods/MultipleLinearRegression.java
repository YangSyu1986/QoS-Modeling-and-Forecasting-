/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package ComparedTimeSeriesMethods_R.RegressionMethods;

import org.rosuda.JRI.Rengine;

import ComparedTimeSeriesMethods_R.R_ProcessBasis;
import ComparedTimeSeriesMethods_R.forecastPackage;

/**
 *
 * @author YangSyu
 */
public class MultipleLinearRegression  extends forecastPackage
{//forecasting formula: Yt = intercept + coefficient1*trend + coefficient2*season2 + coefficient3*season3 + ....
 //if frequency (season= N): there are dummy variables season2, season3, ..., seasonN  (no season1)
    protected void generateForecastingModel(Rengine re)
    {
      re.eval("trainingDataTS<-ts(trainingData,frequency=24)"); 
      re.eval("modelCandidate1<-tslm(trainingDataTS ~ trend + season)");
      double AIC1=re.eval("AIC(modelCandidate1)").asDouble();

      re.eval("trainingDataTS<-ts(trainingData,frequency=168)"); 
      re.eval("modelCandidate2<-tslm(trainingDataTS ~ trend + season)"); 
      double AIC2=re.eval("AIC(modelCandidate2)").asDouble();

      
      if(AIC1 <= AIC2)
      {
        re.eval("model<-modelCandidate1");
        re.eval("season<- 24");
        //System.out.println("number of seasons = 24");
      }
      else
      {
        re.eval("model<-modelCandidate2");
        re.eval("season<- 168");
        //System.out.println("number of seasons = 168");
      }  
      
    }

    protected void predictIncrementallyWithTheSameForecastingModel(Rengine re) 
    {
      re.eval("model$data[nrow(model$data),1]<-trainingDataTS[length(trainingDataTS)]");
      re.eval("model$data[nrow(model$data),2]<-length(trainingDataTS)");  
 
     
      int seasonNumber=(int)(re.eval("season").asDouble());
      int lastSeasonNumber=(int)re.eval("model$data[nrow(model$data),3]").asDouble();
      
      if(lastSeasonNumber==seasonNumber)
      {
        re.eval("model$data[nrow(model$data),3]<- 1");
      }
      else
      {
        re.eval("model$data[nrow(model$data),3]<-"+(lastSeasonNumber+1));
      }  
    }
       
    protected void mode2Implementation(Rengine re, int numberOfFutureForecastPoints)
    {
    }

    protected void forecastForFutureOnePointImplementation(Rengine re) 
    {
    }
}


