/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package ComparedTimeSeriesMethods_R.RegressionMethods;

import org.rosuda.JRI.Rengine;

import ComparedTimeSeriesMethods_R.R_ProcessBasis;
import ComparedTimeSeriesMethods_R.forecastPackage;

/**
 *
 * @author YangSyu
 */
public class SimpleLinearRegression extends forecastPackage
{ //forecasting formula: Yt = intercept + coefficient*t, where intercept and coefficient values are determined by regression (with training data)
    protected void generateForecastingModel(Rengine re)
    {
      re.eval("model<-tslm(trainingDataTS ~ trend)"); 
          //System.out.println(re.eval("coefficients(model)"));//print intercept and trend values
    }

    protected void predictIncrementallyWithTheSameForecastingModel(Rengine re) 
    {
      //re.eval("model$data[nrow(model$data),1]<-trainingDataTS[length(trainingDataTS)]");//this can be ignored, because past observations are not needed in regression approaches
      re.eval("model$data[nrow(model$data),2]<-length(trainingDataTS)");  
         //System.out.println(re.eval("coefficients(model)"));
    }
       
    protected void mode2Implementation(Rengine re, int numberOfFutureForecastPoints)
    {
    }

    protected void forecastForFutureOnePointImplementation(Rengine re) 
    {
    }
}

