package RandomSearch;

import java.lang.management.ManagementFactory;
import java.util.List;
import java.util.Random;

import org.jgap.InvalidConfigurationException;
import org.jgap.gp.IGPProgram;
import org.jgap.gp.impl.GPGenotype;
import org.jgap.gp.impl.GPPopulation;

import ProposedTimeSeriesMethod_GP.Setting.GPEvaluationSetting;
import ProposedTimeSeriesMethod_GP.prediction.GPPredictionConfiguration;
import Utilities.CommonSetting.TimeSeriesIntervalsIndicesSet;
import Utilities.DataStructures.ForecastingOutcomeOfASegment;
import Utilities.DatasetProcessingModules.ObservationsAtOneTimePoint;
import Utilities.ForecastingAccuracyMeasures.DiverseErrorsOfASegment;

public class RandomSearchByGP 
{
   Random random;	
   
   List<List<ObservationsAtOneTimePoint>> timeSeriesSet;
   
   int[][][] trainingDataIntervalsIndicesSet;
   int[][][] validatingDataIntervalsIndicesSet; 
   int[][][] testingDataIntervalsIndicesSet;
   
   GPPredictionConfiguration configuration;
   GPEvaluationSetting gpEvaluationSetting;
	
   String timeseriesMethodName = "Ran.Sea.";
   double timeConverUnit = 1000000000.0;  
   
   public RandomSearchByGP(List<List<ObservationsAtOneTimePoint>> timeSeriesSet, TimeSeriesIntervalsIndicesSet timeSeriesIntervalsIndicesSet,
		                   GPPredictionConfiguration configuration, GPEvaluationSetting gpEvaluationSetting)
   {
	 this.random = new Random();
	 
	 this.timeSeriesSet = timeSeriesSet;
	 
	 this.trainingDataIntervalsIndicesSet = timeSeriesIntervalsIndicesSet.getTrainingIntervalsIndicesSet();
	 this.validatingDataIntervalsIndicesSet = timeSeriesIntervalsIndicesSet.getValidatingIntervalsIndicesSet();
	 this.testingDataIntervalsIndicesSet = timeSeriesIntervalsIndicesSet.getTestingIntervalsIndicesSet();
	 
	 this.configuration = configuration;
	 this.gpEvaluationSetting = gpEvaluationSetting;
   }
   
   public ForecastingOutcomeOfASegment[][] runRandomSearchByGP() throws InvalidConfigurationException
   {
	   System.out.println("--------------- Random Search By GP ------------------");
	   
	   
	   ForecastingOutcomeOfASegment[][] results = new ForecastingOutcomeOfASegment[this.configuration.getDiverseSetting().getNumberOfTimeSeries()][];
	   
	   for(int i = 0;i<this.configuration.getDiverseSetting().getNumberOfTimeSeries();i++)//for different time series
	   {
		 results[i] = new ForecastingOutcomeOfASegment[this.trainingDataIntervalsIndicesSet.length];  
		 
		 this.gpEvaluationSetting.getMainTrainingFitnessFunction().setEntireTimeseries(this.timeSeriesSet.get(i));
	     this.gpEvaluationSetting.getMainValidator().setEntireTimeseries(this.timeSeriesSet.get(i));
	     this.gpEvaluationSetting.getMaintTester().setEntireTimeseries(this.timeSeriesSet.get(i));
		   
	     
		 for(int j = 0;j<this.trainingDataIntervalsIndicesSet.length;j++)//for different segment of a time series
		 {
			this.gpEvaluationSetting.getMainTrainingFitnessFunction().setAvailableDataIntervals(this.trainingDataIntervalsIndicesSet[j]);
		    this.gpEvaluationSetting.getMainValidator().setAvailableDataIntervals(this.validatingDataIntervalsIndicesSet[j]);
		    this.gpEvaluationSetting.getMaintTester().setAvailableDataIntervals(this.testingDataIntervalsIndicesSet[j]);
		      
		    System.out.println(this.getClass().getSimpleName() + "  TS  "+i+"  Segment  " + j);
		    
		    
		        long predictorProductionTime_start = ManagementFactory.getThreadMXBean( ).getCurrentThreadCpuTime();//random search starting point, for measuring predictor production time
		      
		    GPGenotype gp = this.configuration.create();
		    GPPopulation generationPopulation = gp.getGPPopulation();//randomly generating the first/initial generation (population) of a GP evolution 
		    IGPProgram randomPredictor = null;//to contain the temporary/valid predictor found by a random search
		    
		    while(true)//repeat random search in the first/initial GP population until a valid predictor is obtained
		    {
		      randomPredictor = generationPopulation.getGPProgram(random.nextInt(generationPopulation.size()));//randomly pick up a predictor from the GP population
		       //set forecasting outcome and observations for the predictor found
		      results[i][j] = new ForecastingOutcomeOfASegment(i, j, 0, this.timeseriesMethodName);
			  results[i][j].setTrainingObservations(this.gpEvaluationSetting.getMainTrainingFitnessFunction().getAvailableObservations());
			  results[i][j].setTestingObservations(this.gpEvaluationSetting.getMaintTester().getAvailableObservations());
			  results[i][j].setTrainingPredictions(this.gpEvaluationSetting.getMainTrainingFitnessFunction().callEvaluateToHavePredictions(randomPredictor));
			  results[i][j].setTestingPredictions(this.gpEvaluationSetting.getMaintTester().callEvaluateToHavePredictions(randomPredictor)); 
	 
			  //calculating the percentage of valid values (valid predictions and observations)
			  DiverseErrorsOfASegment diverseErrorsOfASegment = new DiverseErrorsOfASegment();
			  diverseErrorsOfASegment.preprocessing(results[i][j]);
		      
			  //if the percentage of valid training/testing predictions produced by the predictor found is 100%, the random search is success and can be ended (get out of while loop)
			  if((diverseErrorsOfASegment.getPercentageOfValidTrainingPredictions() >= 1) && (diverseErrorsOfASegment.getPercentageOfValidTestingPredictions() >= 1))
		       {
		    	  break;
		       }
		    }
		        
		        long predictorProductionTime_end = ManagementFactory.getThreadMXBean( ).getCurrentThreadCpuTime();//random search ending point, for measuring predictor production time
		        double predictorProductionTime = ((predictorProductionTime_end - predictorProductionTime_start) / timeConverUnit);//calculating the time consumed by GP-based (initial generation-only) random search
		     
			    
		    results[i][j].setPredictorProductionTime(predictorProductionTime);
		    results[i][j].setTestingForecastsProductionTime(this.gpEvaluationSetting.getMaintTester().getTotalForecastProductionTime() / timeConverUnit);
		    
		    System.out.println("");
		 }
	   }
	   
	   return results;
   }
}
